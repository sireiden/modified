-- MySQL dump 10.15  Distrib 10.0.38-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: ascasa_ng_db
-- ------------------------------------------------------
-- Server version	10.0.38-MariaDB-0+deb8u1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Current Database: `ascasa_ng_db`
--


--
-- Table structure for table `address_book`
--

DROP TABLE IF EXISTS `address_book`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `address_book` (
  `address_book_id` int(11) NOT NULL AUTO_INCREMENT,
  `customers_id` int(11) NOT NULL,
  `entry_gender` char(1) COLLATE latin1_german1_ci NOT NULL,
  `entry_company` varchar(64) COLLATE latin1_german1_ci DEFAULT NULL,
  `entry_firstname` varchar(64) COLLATE latin1_german1_ci NOT NULL,
  `entry_lastname` varchar(64) COLLATE latin1_german1_ci NOT NULL,
  `entry_street_address` varchar(64) COLLATE latin1_german1_ci NOT NULL,
  `entry_suburb` varchar(32) COLLATE latin1_german1_ci DEFAULT NULL,
  `entry_postcode` varchar(10) COLLATE latin1_german1_ci NOT NULL,
  `entry_city` varchar(64) COLLATE latin1_german1_ci NOT NULL,
  `entry_state` varchar(64) COLLATE latin1_german1_ci DEFAULT NULL,
  `entry_country_id` int(11) NOT NULL DEFAULT '0',
  `entry_zone_id` int(11) NOT NULL DEFAULT '0',
  `address_date_added` datetime DEFAULT '0000-00-00 00:00:00',
  `address_last_modified` datetime DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`address_book_id`),
  KEY `idx_customers_id` (`customers_id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1 COLLATE=latin1_german1_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `address_book`
--

LOCK TABLES `address_book` WRITE;
/*!40000 ALTER TABLE `address_book` DISABLE KEYS */;
INSERT INTO `address_book` VALUES (1,1,'',NULL,'Fabian','Schwarzbauer','Otto-Hahn-Straße 13 b',NULL,'85521','Hohenbrunn-Riemerling',NULL,81,0,'2019-02-05 19:45:21','2019-02-05 19:45:21');
/*!40000 ALTER TABLE `address_book` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `address_format`
--

DROP TABLE IF EXISTS `address_format`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `address_format` (
  `address_format_id` int(11) NOT NULL AUTO_INCREMENT,
  `address_format` varchar(128) COLLATE latin1_german1_ci NOT NULL,
  `address_summary` varchar(48) COLLATE latin1_german1_ci NOT NULL,
  PRIMARY KEY (`address_format_id`)
) ENGINE=MyISAM AUTO_INCREMENT=9 DEFAULT CHARSET=latin1 COLLATE=latin1_german1_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `address_format`
--

LOCK TABLES `address_format` WRITE;
/*!40000 ALTER TABLE `address_format` DISABLE KEYS */;
INSERT INTO `address_format` VALUES (1,'$firstname $lastname$cr$streets$cr$city, $postcode$cr$statecomma$country','$city / $country'),(2,'$firstname $lastname$cr$streets$cr$city, $state    $postcode$cr$country','$city, $state / $country'),(3,'$firstname $lastname$cr$streets$cr$city$cr$postcode - $statecomma$country','$state / $country'),(4,'$firstname $lastname$cr$streets$cr$city ($postcode)$cr$country','$postcode / $country'),(5,'$firstname $lastname$cr$streets$cr$postcode $city$cr$country','$city / $country'),(6,'$firstname $lastname$cr$streets$cr$city $state $postcode$cr$country','$country / $city'),(7,'$firstname $lastname$cr$streets, $city$cr$postcode $state$cr$country','$country / $city'),(8,'$firstname $lastname$cr$streets$cr$city$cr$state$cr$postcode$cr$country','$postcode / $country');
/*!40000 ALTER TABLE `address_format` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `admin_access`
--

DROP TABLE IF EXISTS `admin_access`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `admin_access` (
  `customers_id` varchar(32) COLLATE latin1_german1_ci NOT NULL DEFAULT '0',
  `configuration` int(1) NOT NULL DEFAULT '0',
  `modules` int(1) NOT NULL DEFAULT '0',
  `countries` int(1) NOT NULL DEFAULT '0',
  `currencies` int(1) NOT NULL DEFAULT '0',
  `zones` int(1) NOT NULL DEFAULT '0',
  `geo_zones` int(1) NOT NULL DEFAULT '0',
  `tax_classes` int(1) NOT NULL DEFAULT '0',
  `tax_rates` int(1) NOT NULL DEFAULT '0',
  `accounting` int(1) NOT NULL DEFAULT '0',
  `backup` int(1) NOT NULL DEFAULT '0',
  `server_info` int(1) NOT NULL DEFAULT '0',
  `whos_online` int(1) NOT NULL DEFAULT '0',
  `languages` int(1) NOT NULL DEFAULT '0',
  `orders_status` int(1) NOT NULL DEFAULT '0',
  `shipping_status` int(1) NOT NULL DEFAULT '0',
  `module_export` int(1) NOT NULL DEFAULT '0',
  `customers` int(1) NOT NULL DEFAULT '0',
  `create_account` int(1) NOT NULL DEFAULT '0',
  `customers_status` int(1) NOT NULL DEFAULT '0',
  `customers_group` int(1) NOT NULL DEFAULT '0',
  `orders` int(1) NOT NULL DEFAULT '0',
  `campaigns` int(1) NOT NULL DEFAULT '0',
  `print_packingslip` int(1) NOT NULL DEFAULT '0',
  `print_order` int(1) NOT NULL DEFAULT '0',
  `popup_memo` int(1) NOT NULL DEFAULT '0',
  `coupon_admin` int(1) NOT NULL DEFAULT '0',
  `listproducts` int(1) NOT NULL DEFAULT '0',
  `listcategories` int(1) NOT NULL DEFAULT '0',
  `products_tags` int(1) NOT NULL DEFAULT '0',
  `gv_queue` int(1) NOT NULL DEFAULT '0',
  `gv_mail` int(1) NOT NULL DEFAULT '0',
  `gv_sent` int(1) NOT NULL DEFAULT '0',
  `gv_customers` int(1) NOT NULL DEFAULT '0',
  `validproducts` int(1) NOT NULL DEFAULT '0',
  `validcategories` int(1) NOT NULL DEFAULT '0',
  `mail` int(1) NOT NULL DEFAULT '0',
  `categories` int(1) NOT NULL DEFAULT '0',
  `new_attributes` int(1) NOT NULL DEFAULT '0',
  `products_attributes` int(1) NOT NULL DEFAULT '0',
  `manufacturers` int(1) NOT NULL DEFAULT '0',
  `reviews` int(1) NOT NULL DEFAULT '0',
  `specials` int(1) NOT NULL DEFAULT '0',
  `products_expected` int(1) NOT NULL DEFAULT '0',
  `stats_products_expected` int(1) NOT NULL DEFAULT '0',
  `stats_products_viewed` int(1) NOT NULL DEFAULT '0',
  `stats_products_purchased` int(1) NOT NULL DEFAULT '0',
  `stats_customers` int(1) NOT NULL DEFAULT '0',
  `stats_sales_report` int(1) NOT NULL DEFAULT '0',
  `stats_stock_warning` int(1) NOT NULL DEFAULT '0',
  `stats_campaigns` int(1) NOT NULL DEFAULT '0',
  `banner_manager` int(1) NOT NULL DEFAULT '0',
  `banner_statistics` int(1) NOT NULL DEFAULT '0',
  `module_newsletter` int(1) NOT NULL DEFAULT '0',
  `start` int(1) NOT NULL DEFAULT '0',
  `content_manager` int(1) NOT NULL DEFAULT '0',
  `content_preview` int(1) NOT NULL DEFAULT '0',
  `credits` int(1) NOT NULL DEFAULT '0',
  `orders_edit` int(1) NOT NULL DEFAULT '0',
  `csv_backend` int(1) NOT NULL DEFAULT '0',
  `products_vpe` int(1) NOT NULL DEFAULT '0',
  `cross_sell_groups` int(1) NOT NULL DEFAULT '0',
  `filemanager` int(1) NOT NULL DEFAULT '0',
  `econda` int(1) NOT NULL DEFAULT '0',
  `cleverreach` int(1) NOT NULL DEFAULT '0',
  `shop_offline` int(1) NOT NULL DEFAULT '0',
  `blz_update` int(1) NOT NULL DEFAULT '0',
  `removeoldpics` int(1) NOT NULL DEFAULT '0',
  `janolaw` int(1) NOT NULL DEFAULT '0',
  `haendlerbund` int(1) NOT NULL DEFAULT '0',
  `safeterms` int(1) NOT NULL DEFAULT '0',
  `check_update` int(1) NOT NULL DEFAULT '0',
  `easymarketing` int(1) NOT NULL DEFAULT '0',
  `it_recht_kanzlei` int(1) NOT NULL DEFAULT '0',
  `payone_config` int(1) NOT NULL DEFAULT '0',
  `payone_logs` int(1) NOT NULL DEFAULT '0',
  `protectedshops` int(1) NOT NULL DEFAULT '0',
  `parcel_carriers` int(1) NOT NULL DEFAULT '0',
  `supermailer` int(1) NOT NULL DEFAULT '0',
  `shopgate` int(1) NOT NULL DEFAULT '0',
  `newsfeed` int(1) NOT NULL DEFAULT '0',
  `logs` int(1) NOT NULL DEFAULT '0',
  `shipcloud` int(1) NOT NULL DEFAULT '0',
  `trustedshops` int(1) NOT NULL DEFAULT '0',
  `blacklist_logs` int(1) NOT NULL DEFAULT '0',
  `paypal_info` int(1) NOT NULL DEFAULT '0',
  `paypal_module` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`customers_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_german1_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `admin_access`
--

LOCK TABLES `admin_access` WRITE;
/*!40000 ALTER TABLE `admin_access` DISABLE KEYS */;
INSERT INTO `admin_access` VALUES ('1',1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1),('groups',8,8,7,7,7,7,7,7,2,5,5,5,7,8,8,8,2,2,2,2,2,8,2,2,2,6,6,6,3,6,6,6,6,6,6,2,3,3,3,3,3,3,3,4,4,4,4,4,4,4,5,5,5,1,5,5,1,2,5,8,8,3,9,9,8,5,5,9,9,9,1,9,9,9,9,9,5,9,9,1,5,9,9,5,9,9);
/*!40000 ALTER TABLE `admin_access` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `banktransfer`
--

DROP TABLE IF EXISTS `banktransfer`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `banktransfer` (
  `orders_id` int(11) NOT NULL DEFAULT '0',
  `banktransfer_owner` varchar(64) COLLATE latin1_german1_ci DEFAULT NULL,
  `banktransfer_number` varchar(24) COLLATE latin1_german1_ci DEFAULT NULL,
  `banktransfer_bankname` varchar(255) COLLATE latin1_german1_ci DEFAULT NULL,
  `banktransfer_blz` varchar(8) COLLATE latin1_german1_ci DEFAULT NULL,
  `banktransfer_iban` varchar(34) COLLATE latin1_german1_ci DEFAULT NULL,
  `banktransfer_bic` varchar(11) COLLATE latin1_german1_ci DEFAULT NULL,
  `banktransfer_status` int(11) DEFAULT NULL,
  `banktransfer_prz` char(2) COLLATE latin1_german1_ci DEFAULT NULL,
  `banktransfer_fax` char(2) COLLATE latin1_german1_ci DEFAULT NULL,
  `banktransfer_owner_email` varchar(255) COLLATE latin1_german1_ci DEFAULT NULL,
  KEY `idx_orders_id` (`orders_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_german1_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `banktransfer`
--

LOCK TABLES `banktransfer` WRITE;
/*!40000 ALTER TABLE `banktransfer` DISABLE KEYS */;
/*!40000 ALTER TABLE `banktransfer` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `banktransfer_blz`
--

DROP TABLE IF EXISTS `banktransfer_blz`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `banktransfer_blz` (
  `blz` int(10) NOT NULL DEFAULT '0',
  `bankname` varchar(255) COLLATE latin1_german1_ci NOT NULL DEFAULT '',
  `prz` char(2) COLLATE latin1_german1_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`blz`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_german1_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `banktransfer_blz`
--

LOCK TABLES `banktransfer_blz` WRITE;
/*!40000 ALTER TABLE `banktransfer_blz` DISABLE KEYS */;
INSERT INTO `banktransfer_blz` VALUES (10000000,'Bundesbank','09'),(10010010,'Postbank','24'),(10010111,'SEB','13'),(10010424,'Aareal Bank','09'),(10011001,'N26 Bank','09'),(10019610,'Dexia Kommunalbank Deutschland','09'),(10020200,'BHF-BANK','60'),(10020500,'Bank für Sozialwirtschaft','09'),(10020510,'Bank für Sozialwirtschaft','09'),(10020520,'Bank für Sozialwirtschaft','09'),(10020890,'UniCredit Bank - HypoVereinsbank','99'),(10030200,'Berlin Hyp','09'),(10030400,'ABK Allgemeine Beamten Bank','09'),(10030500,'Bankhaus Löbbecke','09'),(10030600,'North Channel Bank','88'),(10030700,'Eurocity Bank','16'),(10031000,'EIS Einlagensicherungsbank','09'),(10033300,'Santander Consumer Bank','09'),(10040000,'Commerzbank, Filiale Berlin 1','13'),(10040005,'Commerzbank, Filiale Berlin 3','13'),(10040010,'Commerzbank, CC SP','09'),(10040048,'Commerzbank GF-B48','13'),(10040060,'Commerzbank Gf 160','09'),(10040061,'Commerzbank Gf 161','09'),(10040062,'Commerzbank CC','09'),(10040063,'Commerzbank CC','09'),(10040085,'Commerzbank, Gf Web-K','13'),(10045050,'Commerzbank Service-BZ','13'),(10050000,'Landesbank Berlin - Berliner Sparkasse','B8'),(10050005,'Landesbank Berlin - E 1 -','C6'),(10050006,'Landesbank Berlin - E 2 -','D1'),(10050007,'Landesbank Berlin - E 3 -','D4'),(10050008,'Landesbank Berlin - E 4 -','E2'),(10050020,'LBB S-Kreditpartner, Berlin','B8'),(10050500,'LBS Ost Berlin','09'),(10050999,'DekaBank','09'),(10060198,'Pax-Bank','06'),(10061006,'Bank für Kirche und Diakonie - KD-Bank Gf Sonder-BLZ','09'),(10070000,'Deutsche Bank Fil Berlin','63'),(10070024,'Deutsche Bank Privat und Geschäftskunden F 700','63'),(10070100,'Deutsche Bank Fil Berlin II','63'),(10070124,'Deutsche Bank Privat und Geschäftskd Berlin II','63'),(10070848,'Berliner Bank Niederlassung der Deutsche Bank PGK','63'),(10077777,'norisbank','63'),(10080000,'Commerzbank vormals Dresdner Bank Filiale Berlin I','76'),(10080005,'Commerzbank vormals Dresdner Bank Zw A','76'),(10080006,'Commerzbank vormals Dresdner Bank Zw B','76'),(10080055,'Commerzbank vormals Dresdner Bank Zw 55','76'),(10080057,'Commerzbank vormals Dresdner Bank Gf ZW 57','76'),(10080085,'Commerzbank vormals Dresdner Bank Gf PCC DCC-ITGK 3','09'),(10080086,'Commerzbank vormals Dresdner Bank, PCC DCC-ITGK 4','09'),(10080087,'Commerzbank vormals Dresdner Bank, PCC DCC-ITGK 5','09'),(10080088,'Commerzbank vormals Dresdner Bank IBLZ','76'),(10080089,'Commerzbank vormals Dresdner Bank, PCC DCC-ITGK 6','09'),(10080900,'Commerzbank vormals Dresdner Bank Filiale Berlin III','76'),(10089260,'Commerzbank vormals Dresdner Bank ITGK','09'),(10089999,'Commerzbank vormals Dresdner Bank ITGK 2','09'),(10090000,'Berliner Volksbank','06'),(10090300,'Bank für Schiffahrt (BFS) Fil d Ostfr VB Leer','09'),(10090603,'apoBank','A4'),(10090900,'PSD Bank Berlin-Brandenburg','91'),(10110300,'Privatbank Berlin von 1929','09'),(10110400,'Investitionsbank Berlin','09'),(10110600,'quirin bank','17'),(10120100,'Weberbank','94'),(10120600,'Santander Consumer Bank','09'),(10120800,'VON ESSEN Bank','09'),(10130600,'Isbank Fil Berlin','06'),(10130800,'BIW Bank','01'),(10220500,'Bank of Scotland Ndl Berlin','00'),(10220600,'Sydbank Filiale Berlin','19'),(10310600,'Tradegate Wertpapierhandelsbank Berlin','09'),(11010100,'solarisBank','09'),(12016836,'KfW Kreditanstalt für Wiederaufbau','09'),(12030000,'Deutsche Kreditbank Berlin','00'),(12030900,'Merck Finck Privatbankiers','10'),(12040000,'Commerzbank Filiale Berlin 2','13'),(12050555,'ZVA Norddeutsche Landesbank Gf SA','09'),(12060000,'DZ BANK','09'),(12070000,'Deutsche Bank Ld Brandenburg','63'),(12070024,'Deutsche Bank Privat und Geschäftskunden','63'),(12070070,'Deutsche Bank (Gf intern)','09'),(12070088,'Deutsche Bank (Gf intern)','09'),(12080000,'Commerzbank vormals Dresdner Bank Filiale Berlin II','76'),(12090640,'apoBank','A4'),(12096597,'Sparda-Bank Berlin','A8'),(13000000,'Bundesbank','09'),(13010111,'SEB','13'),(13040000,'Commerzbank','13'),(13050000,'Ostseesparkasse Rostock','20'),(13051042,'Sparkasse Vorpommern auf Rügen','C0'),(13061008,'Volksbank Wolgast','32'),(13061028,'Volksbank Raiffeisenbank ehem VB Greifswald','32'),(13061078,'Volks- und Raiffeisenbank','32'),(13061088,'Raiffeisenbank Wismar -alt-','32'),(13061128,'Raiffeisenbank','32'),(13070000,'Deutsche Bank','63'),(13070024,'Deutsche Bank Privat und Geschäftskunden','63'),(13080000,'Commerzbank vormals Dresdner Bank','76'),(13090000,'Rostocker Volks- und Raiffeisenbank','32'),(13091054,'Pommersche Volksbank','32'),(13091084,'Volksbank Wismar -alt-','06'),(14040000,'Commerzbank','13'),(14051000,'Sparkasse Mecklenburg-Nordwest','20'),(14051362,'Sparkasse Parchim-Lübz','20'),(14051462,'Sparkasse Schwerin -alt-','C0'),(14052000,'Sparkasse Mecklenburg-Schwerin','20'),(14061308,'Volks- und Raiffeisenbank','32'),(14061438,'Raiffeisen-Volksbank -alt-','32'),(14080000,'Commerzbank vormals Dresdner Bank','76'),(14080011,'Commerzbank vormals Dresdner Bank Zw W','76'),(14091464,'VR-Bank','32'),(15000000,'Bundesbank','09'),(15040068,'Commerzbank','13'),(15050100,'Müritz-Sparkasse','20'),(15050200,'Sparkasse Neubrandenburg-Demmin','20'),(15050400,'Sparkasse Uecker-Randow','20'),(15050500,'Sparkasse Vorpommern','20'),(15051732,'Sparkasse Mecklenburg-Strelitz','C0'),(15061618,'Raiffeisenbank Mecklenburger Seenplatte','32'),(15061638,'Volksbank Raiffeisenbank','32'),(15061698,'Raiffeisenbank Malchin','32'),(15080000,'Commerzbank vormals Dresdner Bank','76'),(15091674,'Volksbank Demmin','06'),(15091704,'VR-Bank Uckermark-Randow','06'),(16010111,'SEB','13'),(16010300,'Investitionsbank des Landes Brandenburg','09'),(16020086,'UniCredit Bank - HypoVereinsbank','99'),(16040000,'Commerzbank','13'),(16050000,'Mittelbrandenburgische Sparkasse in Potsdam','20'),(16050101,'Sparkasse Prignitz','20'),(16050202,'Sparkasse Ostprignitz-Ruppin','20'),(16050500,'LBS Ostdeutsche Landesbausparkasse','09'),(16060122,'Volks- und Raiffeisenbank Prignitz','32'),(16061938,'Raiffeisenbank Ostprignitz-Ruppin','32'),(16062008,'VR-Bank Fläming','28'),(16062073,'Brandenburger Bank','32'),(16080000,'Commerzbank vormals Dresdner Bank','76'),(16091994,'Volksbank Rathenow','32'),(17020086,'UniCredit Bank - HypoVereinsbank','99'),(17040000,'Commerzbank','13'),(17052000,'Sparkasse Barnim','20'),(17052302,'Stadtsparkasse Schwedt','C0'),(17054040,'Sparkasse Märkisch-Oderland','20'),(17055050,'Sparkasse Oder-Spree','20'),(17056060,'Sparkasse Uckermark','20'),(17062428,'Raiffeisenbank-Volksbank Oder-Spree','32'),(17080000,'Commerzbank vormals Dresdner Bank','76'),(17092404,'VR Bank Fürstenwalde Seelow Wriezen','32'),(18020086,'UniCredit Bank - HypoVereinsbank','99'),(18040000,'Commerzbank','13'),(18050000,'Sparkasse Spree-Neiße','20'),(18051000,'Sparkasse Elbe-Elster','20'),(18055000,'Sparkasse Niederlausitz','20'),(18062678,'VR Bank Lausitz','32'),(18062758,'VR Bank Forst -alt-','32'),(18080000,'Commerzbank vormals Dresdner Bank','76'),(18092684,'Spreewaldbank','32'),(18092744,'Volksbank Spree-Neiße','32'),(20000000,'Bundesbank','09'),(20010020,'Postbank (Giro)','24'),(20010111,'SEB','13'),(20010424,'Aareal Bank','09'),(20020200,'SEB Merchant Bank Hamburg','09'),(20020500,'Jyske Bank Fil Hamburg','09'),(20020900,'Signal Iduna Bauspar','09'),(20030000,'UniCredit Bank - HypoVereinsbank','68'),(20030133,'Varengold Bank','10'),(20030300,'DONNER & REUSCHEL','09'),(20030400,'Marcard, Stein & Co Bankiers','C3'),(20030600,'Sydbank Fil Hamburg','19'),(20030700,'Merck Finck Privatbankiers','10'),(20040000,'Commerzbank','13'),(20040005,'Commerzbank, Filiale Hamburg 2','13'),(20040020,'Commerzbank, CC SP','09'),(20040040,'Commerzbank GF RME','13'),(20040048,'Commerzbank GF-H48','13'),(20040050,'Commerzbank GF COC','13'),(20040060,'Commerzbank Gf 260','09'),(20040061,'Commerzbank Gf 261','09'),(20040062,'Commerzbank CC','09'),(20040063,'Commerzbank CC','09'),(20041111,'comdirect bank','13'),(20041133,'comdirect bank','13'),(20041144,'comdirect bank','13'),(20041155,'comdirect bank','13'),(20050000,'HSH Nordbank Hamburg','C5'),(20050550,'Hamburger Sparkasse','00'),(20060000,'DZ BANK','09'),(20069111,'Norderstedter Bank','32'),(20069125,'Kaltenkirchener Bank','33'),(20069130,'Raiffeisenbank','32'),(20069144,'Raiffeisenbank','33'),(20069177,'Raiffeisenbank Südstormarn Mölln','32'),(20069232,'Raiffeisenbank','33'),(20069641,'Raiffeisenbank Owschlag','33'),(20069780,'Volksbank Ahlerstedt','28'),(20069782,'Volksbank Geest','28'),(20069786,'Volksbank Kehdingen Zndl. der Ostfriesischen Volksbank','28'),(20069800,'Spar- und Kreditbank','28'),(20069812,'Volksbank Fredenbeck','28'),(20069815,'Volksbank','28'),(20069861,'Raiffeisenbank','33'),(20069882,'Raiffeisenbank Travemünde -alt-','33'),(20069965,'Volksbank Winsener Marsch','28'),(20069989,'Volksbank Wulfsen','28'),(20070000,'Deutsche Bank','63'),(20070024,'Deutsche Bank Privat und Geschäftskunden','63'),(20080000,'Commerzbank vormals Dresdner Bank','76'),(20080055,'Commerzbank vormals Dresdner Bank Zw 55','76'),(20080057,'Commerzbank vormals Dresdner Bank Gf ZW 57','76'),(20080085,'Commerzbank vormals Dresdner Bank Gf PCC DCC-ITGK 2','09'),(20080086,'Commerzbank vormals Dresdner Bank, PCC DCC-ITGK 3','09'),(20080087,'Commerzbank vormals Dresdner Bank, PCC DCC-ITGK 4','09'),(20080088,'Commerzbank vormals Dresdner Bank, PCC DCC-ITGK 5','09'),(20080089,'Commerzbank vormals Dresdner Bank, PCC DCC-ITGK 6','09'),(20080091,'Commerzbank vormals Dresdner Bank, PCC DCC-ITGK 7','09'),(20080092,'Commerzbank vormals Dresdner Bank, PCC DCC-ITGK 8','09'),(20080093,'Commerzbank vormals Dresdner Bank, PCC DCC-ITGK 9','09'),(20080094,'Commerzbank vormals Dresdner Bank, PCC DCC-ITGK 10','09'),(20080095,'Commerzbank vormals Dresdner Bank, PCC DCC-ITGK 11','09'),(20089200,'Commerzbank vormals Dresdner Bank ITGK','09'),(20090400,'Deutsche Genossenschafts-Hypothekenbank','09'),(20090500,'Augsburger Aktienbank (netbank)','81'),(20090602,'apoBank','A4'),(20090700,'Edekabank','50'),(20090745,'EBANK Gf Cash','50'),(20090900,'PSD Bank Nord','91'),(20110022,'Postbank (Spar)','09'),(20110700,'Bank of Tokyo-Mitsubishi UFJ, The -','09'),(20110800,'Bank of China Fil Hamburg','09'),(20120000,'Joh. Berenberg, Gossler & Co','00'),(20120100,'M.M.Warburg & CO','09'),(20120200,'BHF-BANK','60'),(20120400,'Deutscher Ring Bausparkasse','E0'),(20120520,'Bank für Sozialwirtschaft','09'),(20120600,'Goyer & Göppel','09'),(20120700,'Hanseatic Bank','16'),(20130400,'GRENKE BANK','00'),(20130600,'Barclaycard Barclays Bank','09'),(20133300,'Santander Consumer Bank','09'),(20190003,'Hamburger Volksbank','10'),(20190109,'Volksbank Stormarn','48'),(20190206,'Volksbank Hamburg Ost-West -alt-','10'),(20190301,'Vierländer Volksbank','10'),(20190800,'MKB Mittelstandskreditbank','28'),(20210200,'Bank Melli Iran','19'),(20210300,'Bank Saderat Iran','09'),(20220100,'DNB Bank ASA - Filiale Deutschland','09'),(20220400,'Warburg, M.M. - Hypothekenbank','09'),(20220800,'SAXO PAYMENTS','09'),(20230300,'Schröder, Otto M. - Bank','09'),(20230600,'Isbank Fil Hamburg','06'),(20230800,'Max Heinr. Sutor','09'),(20310300,'Europäisch-Iranische Handelsbank','09'),(20320500,'Danske Bank','09'),(20690500,'Sparda-Bank Hamburg','D5'),(20730001,'UniCredit Bank - HVB Settlement EAC01','09'),(20730002,'UniCredit Bank - HVB Settlement EAC02','09'),(20730003,'UniCredit Bank - HVB Settlement EAC03','09'),(20730004,'UniCredit Bank - HVB Settlement EAC04','09'),(20730005,'UniCredit Bank - HVB Settlement EAC05','09'),(20730006,'UniCredit Bank - HVB Settlement EAC06','09'),(20730007,'UniCredit Bank - HVB Settlement EAC07','09'),(20730008,'UniCredit Bank - HVB Settlement EAC08','09'),(20730009,'UniCredit Bank - HVB Settlement EAC09','09'),(20730010,'UniCredit Bank - HVB Settlement EAC10','09'),(20730011,'UniCredit Bank - HVB Settlement EAC11','09'),(20730012,'UniCredit Bank - HVB Settlement EAC12','09'),(20730013,'UniCredit Bank - HVB Settlement EAC13','09'),(20730014,'UniCredit Bank - HVB Settlement EAC14','09'),(20730015,'UniCredit Bank - HVB Settlement EAC15','09'),(20730016,'UniCredit Bank - HVB Settlement EAC16','09'),(20730017,'UniCredit Bank - HVB Settlement EAC17','09'),(20730018,'UniCredit Bank - HVB Settlement EAC18','09'),(20730019,'UniCredit Bank - HVB Settlement EAC19','09'),(20730020,'UniCredit Bank - HVB Settlement EAC20','09'),(20730021,'UniCredit Bank - HVB Settlement EAC21','09'),(20730022,'UniCredit Bank - HVB Settlement EAC22','09'),(20730023,'UniCredit Bank - HVB Settlement EAC23','99'),(20730024,'UniCredit Bank - HVB Settlement EAC24','09'),(20730025,'UniCredit Bank - HVB Settlement EAC25','09'),(20730026,'UniCredit Bank - HVB Settlement EAC26','09'),(20730027,'UniCredit Bank - HVB Settlement EAC27','09'),(20730028,'UniCredit Bank - HVB Settlement EAC28','09'),(20730029,'UniCredit Bank - HVB Settlement EAC29','09'),(20730030,'UniCredit Bank - HVB Settlement EAC30','09'),(20730031,'UniCredit Bank - HVB Settlement EAC31','09'),(20730032,'UniCredit Bank - HVB Settlement EAC32','09'),(20730033,'UniCredit Bank - HVB Settlement EAC33','09'),(20730034,'UniCredit Bank - HVB Settlement EAC34','09'),(20730035,'UniCredit Bank - HVB Settlement EAC35','09'),(20730036,'UniCredit Bank - HVB Settlement EAC36','09'),(20730037,'UniCredit Bank - HVB Settlement EAC37','09'),(20730038,'UniCredit Bank - HVB Settlement EAC38','09'),(20730039,'UniCredit Bank - HVB Settlement EAC39','09'),(20730040,'UniCredit Bank - HVB Settlement EAC40','09'),(20750000,'Sparkasse Harburg-Buxtehude','00'),(21000000,'Bundesbank eh Kiel','09'),(21010111,'SEB','13'),(21020600,'Sydbank Filiale Kiel','19'),(21040010,'Commerzbank','13'),(21042076,'Commerzbank','13'),(21050000,'HSH Nordbank Hamburg, Kiel','C5'),(21050170,'Förde Sparkasse','74'),(21051275,'Bordesholmer Sparkasse','A2'),(21051580,'Sparkasse Kreis Plön -alt-','00'),(21052090,'Sparkasse Eckernförde -alt-','00'),(21070020,'Deutsche Bank','63'),(21070024,'Deutsche Bank Privat und Geschäftskunden','63'),(21080050,'Commerzbank vormals Dresdner Bank','76'),(21089201,'Commerzbank vormals Dresdner Bank ITGK','09'),(21090007,'Kieler Volksbank','10'),(21090619,'apoBank','A4'),(21090900,'PSD Bank Kiel','91'),(21092023,'Eckernförder Bank Volksbank-Raiffeisenbank','48'),(21210111,'SEB','13'),(21240040,'Commerzbank','13'),(21241540,'Commerzbank','13'),(21261089,'Raiffeisenbank -alt-','33'),(21261227,'Raiffbk Kl-Kummerfeld -alt-','33'),(21270020,'Deutsche Bank','63'),(21270024,'Deutsche Bank Privat und Geschäftskunden','63'),(21280002,'Commerzbank vormals Dresdner Bank','76'),(21290016,'VR Bank Neumünster','48'),(21340010,'Commerzbank','13'),(21352240,'Sparkasse Holstein','A7'),(21390008,'VR Bank Ostholstein Nord-Plön','32'),(21392218,'Volksbank Eutin Raiffeisenbank','33'),(21440045,'Commerzbank','13'),(21450000,'Sparkasse Mittelholstein Rendsburg','C2'),(21451205,'Sparkasse Büdelsdorf -alt-','00'),(21452030,'Sparkasse Hohenwestedt -alt-','A2'),(21463603,'Volksbank-Raiffeisenbank im Kreis Rendsburg','32'),(21464671,'Raiffeisenbank','33'),(21480003,'Commerzbank vormals Dresdner Bank','76'),(21510600,'Sydbank Filiale Flensburg','19'),(21520100,'Union-Bank Flensburg','06'),(21540060,'Commerzbank','13'),(21565316,'Raiffeisenbank','33'),(21570011,'Deutsche Bank','63'),(21570024,'Deutsche Bank Privat und Geschäftskunden','63'),(21580000,'Commerzbank vormals Dresdner Bank','76'),(21661719,'VR Bank Flensburg-Schleswig','32'),(21690020,'Schleswiger Volksbank, Volksbank Raiffeisenbank','32'),(21740043,'Commerzbank','13'),(21741674,'Commerzbank','13'),(21741825,'Commerzbank','13'),(21750000,'Nord-Ostsee Sparkasse','C8'),(21751230,'Spar- und Leihkasse zu Bredstedt -alt-','00'),(21762550,'Husumer Volksbank','32'),(21763542,'VR Bank','32'),(21770011,'Deutsche Bank','63'),(21770024,'Deutsche Bank Privat und Geschäftskunden','63'),(21791805,'Sylter Bank','33'),(21791906,'Föhr-Amrumer Bank','32'),(21840078,'Commerzbank','13'),(21841328,'Commerzbank','13'),(21852310,'Sparkasse Hennstedt-Wesselburen','A2'),(21860418,'Raiffeisenbank Heide','32'),(21890022,'Dithmarscher Volks- und Raiffeisenbank','32'),(22140028,'Commerzbank','13'),(22141028,'Commerzbank','13'),(22141428,'Commerzbank','13'),(22141628,'Commerzbank','13'),(22150000,'Sparkasse Elmshorn','A2'),(22151730,'Stadtsparkasse Wedel','D6'),(22163114,'Raiffeisenbank Elbmarsch','33'),(22180000,'Commerzbank vormals Dresdner Bank','76'),(22181400,'Commerzbank vormals Dresdner Bank','76'),(22190030,'Volksbank Elmshorn -alt-','48'),(22191405,'Volksbank Pinneberg-Elmshorn','48'),(22240073,'Commerzbank','13'),(22250020,'Sparkasse Westholstein','A2'),(22280000,'Commerzbank vormals Dresdner Bank','76'),(22290031,'Volksbank Raiffeisenbank Itzehoe','10'),(23000000,'Bundesbank eh Lübeck','09'),(23010111,'SEB','13'),(23040022,'Commerzbank','13'),(23050000,'HSH Nordbank Hamburg','C5'),(23050101,'Sparkasse zu Lübeck','00'),(23051030,'Sparkasse Südholstein','A2'),(23052750,'Kreissparkasse Herzogtum Lauenburg','A2'),(23061220,'Raiffeisenbank Leezen','32'),(23062124,'Raiffeisenbank','33'),(23063129,'Raiffeisenbank','33'),(23064107,'Raiffeisenbank','32'),(23070700,'Deutsche Bank Privat und Geschäftskunden','63'),(23070710,'Deutsche Bank','63'),(23080040,'Commerzbank vormals Dresdner Bank','76'),(23089201,'Commerzbank vormals Dresdner Bank ITGK','09'),(23090142,'Volksbank Lübeck','10'),(23092620,'apoBank','A4'),(24040000,'Commerzbank','13'),(24050110,'Sparkasse Lüneburg','00'),(24060300,'Volksbank Lüneburger Heide','28'),(24061392,'Volksbank Bleckede-Dahlenburg -alt-','28'),(24070024,'Deutsche Bank Privat und Geschäftskunden','63'),(24070075,'Deutsche Bank','63'),(24080000,'Commerzbank vormals Dresdner Bank','76'),(24090041,'Volksbank Lüneburg -alt-','28'),(24121000,'Ritterschaftliches Kreditinstitut Stade','09'),(24140041,'Commerzbank','13'),(24150001,'Stadtsparkasse Cuxhaven','00'),(24151005,'Sparkasse Stade-Altes Land','00'),(24151116,'Kreissparkasse Stade','00'),(24151235,'Sparkasse Rotenburg-Bremervörde','00'),(24161594,'Zevener Volksbank','28'),(24162898,'Spar- u Darlehnskasse Börde Lamstedt-Hechthausen','28'),(24180000,'Commerzbank vormals Dresdner Bank','76'),(24180001,'Commerzbank vormals Dresdner Bank','76'),(24191015,'Volksbank Stade-Cuxhaven','28'),(25000000,'Bundesbank','09'),(25010030,'Postbank','24'),(25010111,'SEB','13'),(25010424,'Aareal Bank','09'),(25010600,'Deutsche Hypothekenbank','01'),(25010900,'Calenberger Kreditverein','28'),(25020200,'BHF-BANK','60'),(25020600,'Santander Consumer Bank','41'),(25040060,'Commerzbank CC','09'),(25040061,'Commerzbank CC','09'),(25040066,'Commerzbank','13'),(25050000,'Norddeutsche Landesbank Girozentrale','27'),(25050055,'ZVA Norddeutsche Landesbank SH','09'),(25050066,'ZVA Norddeutsche Landesbank Gf MV','09'),(25050180,'Sparkasse Hannover','A3'),(25050299,'Sparkasse Hannover -alt-','A3'),(25055500,'LBS-Norddeutsche Landesbausparkasse','26'),(25060000,'DZ BANK','09'),(25060180,'Bankhaus Hallbaum','09'),(25069168,'Volks- und Raiffeisenbank Leinebergland','28'),(25069262,'Raiffeisen-Volksbank Neustadt','28'),(25069270,'Volksbank Aller-Oker','28'),(25069370,'Volksbank Vechelde-Wendeburg -alt-','28'),(25069503,'Volksbank Diepholz-Barnstorf','28'),(25070024,'Deutsche Bank Privat und Geschäftskunden','63'),(25070066,'Deutsche Bank','63'),(25070070,'Deutsche Bank','63'),(25070077,'Deutsche Bank','63'),(25070084,'Deutsche Bank','63'),(25070086,'Deutsche Bank','63'),(25080020,'Commerzbank vormals Dresdner Bank','76'),(25080085,'Commerzbank vormals Dresdner Bank, PCC DCC-ITGK 2','09'),(25089220,'Commerzbank vormals Dresdner Bank ITGK','09'),(25090300,'Bank für Schiffahrt (BFS) Fil d Ostfr VB Leer','28'),(25090500,'Sparda-Bank Hannover','81'),(25090608,'apoBank','A4'),(25090900,'PSD Bank','91'),(25120510,'Bank für Sozialwirtschaft','09'),(25151270,'Stadtsparkasse Barsinghausen','00'),(25151371,'Stadtsparkasse Burgdorf','00'),(25152375,'Kreissparkasse Fallingbostel in Walsrode','00'),(25152490,'Stadtsparkasse Wunstorf','00'),(25190001,'Hannoversche Volksbank','28'),(25190088,'Hannoversche Volksbank GS nur für GAA','28'),(25193331,'Volksbank','28'),(25250001,'Kreissparkasse Peine','00'),(25260010,'Volksbank Peine','28'),(25410111,'SEB','13'),(25410200,'BHW Bausparkasse','09'),(25440047,'Commerzbank','13'),(25450001,'Stadtsparkasse Hameln -alt-','00'),(25450110,'Sparkasse Hameln-Weserbergland','00'),(25451345,'Stadtsparkasse Bad Pyrmont','00'),(25462160,'Volksbank Hameln-Stadthagen','28'),(25462680,'Volksbank im Wesertal','28'),(25470024,'Deutsche Bank Privat und Geschäftskunden','63'),(25470073,'Deutsche Bank','63'),(25471024,'Deutsche Bank Privat und Geschäftskunden','63'),(25471073,'Deutsche Bank','63'),(25480021,'Commerzbank vormals Dresdner Bank','76'),(25491273,'Volksbank Aerzen -alt-','28'),(25491744,'Volksbank Bad Münder','28'),(25541426,'Commerzbank','13'),(25551480,'Sparkasse Schaumburg','00'),(25591413,'Volksbank in Schaumburg','28'),(25621327,'Oldenburgische Landesbank AG','61'),(25641302,'Commerzbank','13'),(25650106,'Sparkasse Nienburg','00'),(25651325,'Kreissparkasse Grafschaft Diepholz','00'),(25662540,'Volksbank','28'),(25663584,'Volksbank Aller-Weser','28'),(25690009,'Volksbank Nienburg','28'),(25691633,'Volksbank Sulingen','28'),(25740061,'Commerzbank','13'),(25750001,'Sparkasse Celle','00'),(25761894,'Volksbank Wittingen-Klötze','28'),(25770024,'Deutsche Bank Privat und Geschäftskunden','63'),(25770069,'Deutsche Bank','63'),(25780022,'Commerzbank vormals Dresdner Bank','76'),(25791516,'Volksbank Hankensbüttel-Wahrenholz','28'),(25791635,'Volksbank Südheide','28'),(25840048,'Commerzbank','13'),(25841403,'Commerzbank','13'),(25841708,'Commerzbank','13'),(25850110,'Sparkasse Uelzen Lüchow-Dannenberg','00'),(25851335,'Sparkasse Uelzen Lüchow-Dannenberg -alt-','00'),(25851660,'Kreissparkasse Soltau','00'),(25861395,'Volksbank Dannenberg -alt-','28'),(25861990,'Volksbank Clenze-Hitzacker','28'),(25862292,'Volksbank Uelzen-Salzwedel','28'),(25863489,'Volksbank Osterburg-Lüchow-Dannenberg','28'),(25891483,'Volksbank Osterburg-Lüchow-Dannenberg -alt-','28'),(25891636,'Volksbank Lüneburger Heide -alt-','28'),(25910111,'SEB','13'),(25940033,'Commerzbank','13'),(25950001,'Stadtsparkasse Hildesheim -alt-','B1'),(25950130,'Sparkasse Hildesheim','B1'),(25970024,'Deutsche Bank Privat und Geschäftskunden','63'),(25970074,'Deutsche Bank','63'),(25971024,'Deutsche Bank Privat und Geschäftskunden','63'),(25971071,'Deutsche Bank','63'),(25980027,'Commerzbank vormals Dresdner Bank','76'),(25990011,'Volksbank Hildesheim','28'),(25991528,'Volksbank Hildesheimer Börde','28'),(26000000,'Bundesbank','09'),(26010111,'SEB','13'),(26040030,'Commerzbank','13'),(26050001,'Sparkasse Göttingen','00'),(26051260,'Sparkasse Duderstadt','00'),(26051450,'Kreis- und Stadtsparkasse Münden','00'),(26061291,'Volksbank Mitte','48'),(26061556,'Volksbank','28'),(26062433,'VR-Bank in Südniedersachsen','32'),(26070024,'Deutsche Bank Privat und Geschäftskunden','63'),(26070072,'Deutsche Bank','63'),(26080024,'Commerzbank vormals Dresdner Bank','76'),(26090050,'Volksbank Göttingen','28'),(26240039,'Commerzbank','13'),(26250001,'Kreis-Sparkasse Northeim','00'),(26251425,'Sparkasse Einbeck','00'),(26261396,'Volksbank Dassel -alt-','28'),(26261492,'Volksbank Einbeck','28'),(26261693,'Volksbank Solling','28'),(26271424,'Deutsche Bank Privat und Geschäftskunden','63'),(26271471,'Deutsche Bank','63'),(26280020,'Commerzbank vormals Dresdner Bank','76'),(26281420,'Commerzbank vormals Dresdner Bank','76'),(26340056,'Commerzbank','13'),(26341072,'Commerzbank','13'),(26350001,'Stadtsparkasse Osterode','00'),(26351015,'Sparkasse Osterode am Harz','00'),(26351445,'Stadtsparkasse Bad Sachsa','00'),(26500000,'Bundesbank','09'),(26510111,'SEB','13'),(26520017,'Oldenburgische Landesbank AG','61'),(26521703,'Oldenburgische Landesbank AG','61'),(26522319,'Oldenburgische Landesbank AG','61'),(26540070,'Commerzbank','13'),(26550105,'Sparkasse Osnabrück','00'),(26551540,'Kreissparkasse Bersenbrück','00'),(26552286,'Kreissparkasse Melle','00'),(26560625,'apoBank','A4'),(26562490,'Volksbank Bad Laer-Borgloh-Hilter-Melle','28'),(26562694,'Volksbank Wittlage -alt-','28'),(26563960,'Volksbank Bramgau-Wittlage','28'),(26565928,'Volksbank GMHütte-Hagen-Bissendorf','28'),(26566939,'Volksbank Osnabrücker Nordland','28'),(26567943,'VR-Bank im Altkreis Bersenbrück','28'),(26570024,'Deutsche Bank Privat und Geschäftskunden','63'),(26570090,'Deutsche Bank','63'),(26580070,'Commerzbank vormals Dresdner Bank','76'),(26589210,'Commerzbank vormals Dresdner Bank ITGK','09'),(26590025,'Volksbank Osnabrück','28'),(26620010,'Oldenburgische Landesbank AG','61'),(26621413,'Oldenburgische Landesbank AG','61'),(26640049,'Commerzbank','13'),(26650001,'Sparkasse Emsland','00'),(26660060,'Volksbank Lingen','28'),(26661380,'Volksbank Haselünne','28'),(26661494,'Emsländische Volksbank Meppen','28'),(26661912,'Volksbank Süd-Emsland -alt-','28'),(26662932,'Volksbank','28'),(26691213,'Volksbank Haren Fil d Ostfriesischen VB','28'),(26720028,'Oldenburgische Landesbank AG','61'),(26740044,'Commerzbank','13'),(26750001,'Kreissparkasse Grafschaft Bentheim zu Nordhorn','00'),(26760005,'Raiffeisen- und Volksbank Nordhorn -alt-','28'),(26770024,'Deutsche Bank Privat und Geschäftskunden','63'),(26770095,'Deutsche Bank','63'),(26840032,'Commerzbank','13'),(26850001,'Sparkasse Goslar/Harz','00'),(26851410,'Kreissparkasse Clausthal-Zellerfeld','00'),(26851620,'Sparkasse Salzgitter','22'),(26870024,'Deutsche Bank Privat und Geschäftskunden','63'),(26870032,'Deutsche Bank','63'),(26880063,'Commerzbank vormals Dresdner Bank','76'),(26890019,'Volksbank Nordharz','28'),(26891484,'Volksbank im Harz','28'),(26941053,'Commerzbank Wolfsburg','13'),(26951311,'Sparkasse Gifhorn-Wolfsburg','00'),(26971024,'Deutsche Bank Privat und Geschäftskunden','63'),(26971038,'Deutsche Bank','63'),(26981062,'Commerzbank vormals Dresdner Bank','76'),(26989221,'Commerzbank vormals Dresdner Bank ITGK','09'),(26991066,'Volksbank Braunschweig Wolfsburg','50'),(27010111,'SEB','13'),(27010200,'VON ESSEN Bank','09'),(27020000,'Volkswagen Bank','D8'),(27020001,'Audi Bank Zndl d Volkswagen Bank','D8'),(27020003,'Skoda Bank','D8'),(27020004,'AutoEuropa Bank','D8'),(27020800,'Seat Bank Zndl d Volkswagen Bank','D8'),(27032500,'Bankhaus C. L. Seeliger','09'),(27040080,'Commerzbank','13'),(27062290,'Volksbank Börßum-Hornburg','28'),(27070024,'Deutsche Bank Privat und Geschäftskunden','63'),(27070030,'Deutsche Bank','63'),(27070031,'Deutsche Bank','63'),(27070034,'Deutsche Bank','63'),(27070041,'Deutsche Bank','63'),(27070042,'Deutsche Bank','63'),(27070043,'Deutsche Bank','63'),(27070079,'Deutsche Bank','63'),(27072524,'Deutsche Bank Privat und Geschäftskunden','63'),(27072537,'Deutsche Bank','63'),(27072724,'Deutsche Bank Privat und Geschäftskunden','63'),(27072736,'Deutsche Bank','63'),(27080060,'Commerzbank vormals Dresdner Bank','76'),(27089221,'Commerzbank vormals Dresdner Bank ITGK','09'),(27090618,'apoBank','A4'),(27090900,'PSD Bank','91'),(27092555,'Volksbank','28'),(27131300,'Bankhaus Rautenschlein','32'),(27190082,'Volksbank Helmstedt -alt-','28'),(27240004,'Commerzbank','13'),(27290087,'Volksbank Weserbergland','47'),(27893215,'Vereinigte Volksbank -alt-','32'),(27893359,'Volksbank Braunlage','48'),(27893760,'Volksbank','28'),(28000000,'Bundesbank','09'),(28010111,'SEB','13'),(28020050,'Oldenburgische Landesbank AG','61'),(28021002,'Oldenburgische Landesbank AG','61'),(28021301,'Oldenburgische Landesbank AG','61'),(28021504,'Oldenburgische Landesbank AG','61'),(28021623,'Oldenburgische Landesbank AG','61'),(28021705,'Oldenburgische Landesbank AG','61'),(28021906,'Oldenburgische Landesbank AG','61'),(28022015,'Oldenburgische Landesbank AG','61'),(28022412,'Oldenburgische Landesbank AG','61'),(28022511,'Oldenburgische Landesbank AG','61'),(28022620,'Oldenburgische Landesbank AG','61'),(28022822,'Oldenburgische Landesbank AG','61'),(28023224,'Oldenburgische Landesbank AG','61'),(28023325,'Oldenburgische Landesbank AG','61'),(28030300,'Oldenburgische Landesbank (vormals W. Fortmann & Söhne)','09'),(28040046,'Commerzbank','13'),(28042865,'Commerzbank','13'),(28050100,'Landessparkasse zu Oldenburg','00'),(28060228,'Raiffeisenbank Oldenburg','28'),(28061410,'Raiffeisenbank Wesermarsch-Süd','28'),(28061501,'Volksbank Cloppenburg','28'),(28061679,'Volksbank Dammer Berge','28'),(28061822,'Volksbank Oldenburg','28'),(28062165,'Raiffeisenbank Rastede','28'),(28062249,'Vereinigte Volksbank','28'),(28062560,'Volksbank Lohne-Mühlen','28'),(28062740,'Volksbank Bookholzberg-Lemwerder -alt-','28'),(28062913,'Volksbank Bösel','28'),(28063253,'Volksbank Westerstede','28'),(28063526,'Volksbank Essen-Cappeln','28'),(28063607,'Volksbank Bakum','28'),(28064179,'Volksbank Vechta','28'),(28064241,'Raiffeisen-Volksbank Varel-Nordenham','28'),(28065061,'Volksbank Löningen','28'),(28065108,'VR-Bank Dinklage-Steinfeld','28'),(28065286,'Raiffeisenbank Scharrel','28'),(28066103,'Volksbank Visbek','28'),(28066214,'Volksbank Wildeshauser Geest','28'),(28066620,'Spar- und Darlehnskasse Friesoythe','28'),(28067068,'Volksbank Neuenkirchen-Vörden','28'),(28067170,'Volksbank Delmenhorst Schierbrok','28'),(28067257,'Volksbank Lastrup','28'),(28068218,'Raiffeisenbank Butjadingen-Abbehausen','28'),(28069052,'Raiffeisenbank Strücklingen-Idafehn','28'),(28069092,'VR Bank Oldenburg Land West','28'),(28069109,'Volksbank Emstek','28'),(28069128,'Raiffeisenbank Garrel','28'),(28069138,'VR Bank Oldenburg Land West','28'),(28069293,'Volksbank Obergrafschaft -alt-','28'),(28069381,'Hümmlinger Volksbank','28'),(28069706,'Volksbank Nordhümmling','28'),(28069755,'Raiffeisenbank Oldersum','28'),(28069773,'Raiffeisenbank Wiesedermeer-Wiesede-Marcardsm','28'),(28069878,'Raiffeisenbank Emsland-Mitte','28'),(28069926,'Volksbank Niedergrafschaft','28'),(28069930,'Volksbank Langen-Gersten -alt-','28'),(28069935,'Raiffeisenbank Lorup','28'),(28069956,'Grafschafter Volksbank','28'),(28069991,'Volksbank Emstal','28'),(28069994,'Volksbank Süd-Emsland','28'),(28070024,'Deutsche Bank Privat und Geschäftskunden','63'),(28070057,'Deutsche Bank','63'),(28090633,'apoBank','A4'),(28220026,'Oldenburgische Landesbank AG','61'),(28222208,'Oldenburgische Landesbank AG','61'),(28222621,'Oldenburgische Landesbank AG','61'),(28240023,'Commerzbank','13'),(28250110,'Sparkasse Wilhelmshaven','00'),(28252760,'Kreissparkasse Wittmund','00'),(28262254,'Volksbank Jever','10'),(28262673,'Raiffeisen-Volksbank Varel-Nordenham','28'),(28270024,'Deutsche Bank Privat und Geschäftskunden','63'),(28270056,'Deutsche Bank','63'),(28280012,'Commerzbank vormals Dresdner Bank','76'),(28290063,'Volksbank Wilhelmshaven','00'),(28291551,'Volksbank Esens','28'),(28320014,'Oldenburgische Landesbank AG','61'),(28321816,'Oldenburgische Landesbank AG','61'),(28350000,'Sparkasse Aurich-Norden','00'),(28361592,'Raiffeisen-Volksbank Fresena','28'),(28420007,'Oldenburgische Landesbank AG','61'),(28421030,'Oldenburgische Landesbank AG','61'),(28440037,'Commerzbank','13'),(28450000,'Sparkasse Emden','00'),(28470024,'Deutsche Bank Privat und Geschäftskunden','63'),(28470091,'Deutsche Bank','63'),(28520009,'Oldenburgische Landesbank AG','61'),(28521518,'Oldenburgische Landesbank AG','61'),(28540034,'Commerzbank','13'),(28550000,'Sparkasse LeerWittmund','00'),(28562297,'Raiffeisen-Volksbank','28'),(28562716,'Raiffeisenbank Flachsmeer','28'),(28562863,'Raiffeisenbank Moormerland','28'),(28563749,'Raiffeisenbank','28'),(28570024,'Deutsche Bank Privat und Geschäftskunden','63'),(28570092,'Deutsche Bank','63'),(28590075,'Ostfriesische Volksbank Leer','28'),(28591579,'Volksbank Papenburg Fil d. Ostfries. VB Leer','28'),(28591654,'Volksbank Westrhauderfehn','28'),(29000000,'Bundesbank eh Bremen','09'),(29010111,'SEB','13'),(29010400,'Deutsche Schiffsbank','09'),(29020000,'Bankhaus Neelmeyer','45'),(29020100,'Bremer Kreditbank','18'),(29020200,'Greensill Bank','09'),(29030400,'Bankhaus Carl F. Plump & CO','09'),(29040060,'Commerzbank CC','09'),(29040061,'Commerzbank CC','09'),(29040090,'Commerzbank','13'),(29050000,'Bremer Landesbank','29'),(29050101,'Sparkasse Bremen','00'),(29070024,'Deutsche Bank Privat und Geschäftskunden','63'),(29070050,'Deutsche Bank','63'),(29070051,'Deutsche Bank','63'),(29070052,'Deutsche Bank','63'),(29070058,'Deutsche Bank','63'),(29070059,'Deutsche Bank','63'),(29080010,'Commerzbank vormals Bremer Bank (Dresdner Bank)','76'),(29089210,'Commerzbank vormals Bremer Bank (Dresdner Bank) ITGK','09'),(29090605,'apoBank','A4'),(29090900,'PSD Bank Nord','91'),(29121731,'Oldenburgische Landesbank AG','61'),(29151700,'Kreissparkasse Syke','00'),(29152300,'Kreissparkasse Osterholz','00'),(29152550,'Zweckverbandssparkasse Scheeßel','00'),(29152670,'Kreissparkasse Verden','00'),(29162394,'Volksbank','28'),(29162453,'Volksbank Schwanewede','28'),(29162697,'Volksbank Aller-Weser','28'),(29165545,'Volksbank Oyten','28'),(29165681,'Volksbank Sottrum','28'),(29166568,'Volksbank','28'),(29167624,'Volksbank Syke','28'),(29172624,'Deutsche Bank Privat und Geschäftskunden','63'),(29172655,'Deutsche Bank','63'),(29190024,'Bremische Volksbank','28'),(29190330,'Volksbank Bremen-Nord','28'),(29210111,'SEB','13'),(29240024,'Commerzbank','13'),(29250000,'Weser-Elbe Sparkasse','10'),(29250150,'Kreissparkasse Wesermünde-Hadeln -alt-','10'),(29262722,'Volksbank Geeste-Nord','28'),(29265747,'Volksbank Bremerhaven-Cuxland','28'),(29280011,'Commerzbank vormals Dresdner Bank','76'),(29290034,'Volksbank Bremerhaven-Wesermünde -alt-','28'),(30000000,'Bundesbank','09'),(30010111,'SEB','13'),(30010400,'IKB Deutsche Industriebank','09'),(30010444,'IKB Privatkunden - IKB Deutsche Industriebank','09'),(30010700,'The Bank of Tokyo-Mitsubishi UFJ','09'),(30015500,'easybank Niederlassung Deutschland','01'),(30019000,'ipagoo - German Branch','09'),(30020500,'BHF-BANK','60'),(30020700,'Mizuho Bank Filiale Düsseldorf','09'),(30020900,'TARGOBANK','57'),(30022000,'NRW.BANK','08'),(30025500,'Portigon','08'),(30030100,'S Broker Wiesbaden','56'),(30030500,'Bank11direkt','05'),(30030600,'ETRIS Bank','06'),(30030880,'HSBC Trinkaus & Burkhardt','56'),(30030889,'HSBC Trinkaus VAC','00'),(30030900,'Merck Finck Privatbankiers','00'),(30040000,'Commerzbank','13'),(30040005,'Commerzbank, Filiale Düsseldorf 2','13'),(30040048,'Commerzbank GF-D48','13'),(30040060,'Commerzbank Gf 660','09'),(30040061,'Commerzbank Gf 661','09'),(30040062,'Commerzbank CC','09'),(30040063,'Commerzbank CC','09'),(30050000,'Landesbank Hessen-Thüringen Girozentrale NL. Düsseldorf','08'),(30050110,'Stadtsparkasse Düsseldorf','00'),(30060010,'DZ BANK','44'),(30060601,'apoBank','A4'),(30060992,'PSD Bank Rhein-Ruhr','91'),(30070010,'Deutsche Bank','63'),(30070024,'Deutsche Bank Privat und Geschäftskunden','63'),(30080000,'Commerzbank vormals Dresdner Bank','76'),(30080005,'Commerzbank vormals Dresdner Bank Zw 05','76'),(30080022,'Commerzbank vormals Dresdner Bank Ztv 22','76'),(30080038,'Commerzbank vormals Dresdner Bank Zw 38','76'),(30080041,'Commerzbank vormals Dresdner Bank Zw 41','76'),(30080053,'Commerzbank vormals Dresdner Bank Zw 53','76'),(30080055,'Commerzbank vormals Dresdner Bank Zw 55','76'),(30080057,'Commerzbank vormals Dresdner Bank Gf ZW 57','76'),(30080061,'Commerzbank vormals Dresdner Bank Zw 61','76'),(30080074,'Commerzbank vormals Dresdner Bank Zw 74','76'),(30080080,'Commerzbank vormals Dresdner Bank, PCC DCC-ITGK 3','09'),(30080081,'Commerzbank vormals Dresdner Bank, PCC DCC-ITGK 4','09'),(30080082,'Commerzbank vormals Dresdner Bank, PCC DCC-ITGK 5','09'),(30080083,'Commerzbank vormals Dresdner Bank, PCC DCC-ITGK 6','09'),(30080084,'Commerzbank vormals Dresdner Bank, PCC DCC-ITGK 7','09'),(30080085,'Commerzbank vormals Dresdner Bank, PCC DCC-ITGK 8','09'),(30080086,'Commerzbank vormals Dresdner Bank, PCC DCC-ITGK 9','09'),(30080087,'Commerzbank vormals Dresdner Bank, PCC DCC-ITGK 10','09'),(30080088,'Commerzbank vormals Dresdner Bank, PCC DCC-ITGK 11','09'),(30080089,'Commerzbank vormals Dresdner Bank, PCC DCC-ITGK 12','09'),(30080095,'Commerzbank vormals Dresdner Bank Zw 95','76'),(30089300,'Commerzbank vormals Dresdner Bank ITGK I','09'),(30089302,'Commerzbank vormals Dresdner Bank ITGK II','09'),(30110300,'Sumitomo Mitsui Banking Corporation','09'),(30120500,'Bremer Kreditbank','18'),(30130100,'Demir-Halk Bank (Nederland)','09'),(30130200,'GarantiBank International','09'),(30130600,'Isbank Fil Düsseldorf','06'),(30130800,'Düsseldorfer Hypothekenbank','09'),(30150001,'Helaba Düsseldorf Gf Verrechnung FI-Dus','09'),(30150200,'Kreissparkasse Düsseldorf','00'),(30160213,'Volksbank Düsseldorf Neuss','06'),(30220190,'UniCredit Bank - HypoVereinsbank','99'),(30330800,'BIW Bank für Investments und Wertpapiere','01'),(30351220,'Stadt-Sparkasse Haan','00'),(30520000,'RCI Banque Niederlassung Deutschland','09'),(30520037,'RCI Banque Direkt','28'),(30524400,'KBC Bank Ndl Deutschland','18'),(30530000,'Bankhaus Werhahn','09'),(30530500,'Bank11 für Privatkunden und Handel, Neuss','28'),(30550000,'Sparkasse Neuss','00'),(30551240,'Stadtsparkasse Kaarst-Büttgen -alt-','00'),(30560090,'Volksbank Neuss -alt-','06'),(30560548,'VR Bank','06'),(31010111,'SEB','13'),(31010833,'Santander Consumer Bank','09'),(31040015,'Commerzbank','13'),(31040060,'Commerzbank CC','09'),(31040061,'Commerzbank CC','09'),(31050000,'Stadtsparkasse Mönchengladbach','00'),(31060181,'Gladbacher Bank von 1922','06'),(31060517,'Volksbank Mönchengladbach','06'),(31062154,'Volksbank Brüggen-Nettetal','06'),(31062553,'Volksbank Schwalmtal','06'),(31070001,'Deutsche Bank','63'),(31070024,'Deutsche Bank Privat und Geschäftskunden','63'),(31080015,'Commerzbank vormals Dresdner Bank','76'),(31080061,'Commerzbank vormals Dresdner Bank Zw 61','76'),(31251220,'Kreissparkasse Heinsberg in Erkelenz','00'),(31261282,'Volksbank Erkelenz','06'),(31263359,'Raiffeisenbank Erkelenz','06'),(31460290,'Volksbank Viersen','06'),(31470004,'Deutsche Bank','63'),(31470024,'Deutsche Bank Privat und Geschäftskunden','63'),(32040024,'Commerzbank','13'),(32050000,'Sparkasse Krefeld','00'),(32051996,'Sparkasse der Stadt Straelen -alt-','00'),(32060362,'Volksbank Krefeld','06'),(32061384,'Volksbank an der Niers','06'),(32061414,'Volksbank Kempen-Grefrath','06'),(32070024,'Deutsche Bank Privat und Geschäftskunden','63'),(32070080,'Deutsche Bank','63'),(32080010,'Commerzbank vormals Dresdner Bank','76'),(32250050,'Verbandssparkasse Goch','00'),(32440023,'Commerzbank','13'),(32450000,'Sparkasse Rhein-Maas','00'),(32460422,'Volksbank Kleverland','06'),(32470024,'Deutsche Bank Privat und Geschäftskunden','63'),(32470077,'Deutsche Bank','63'),(33010111,'SEB','13'),(33020000,'akf bank','09'),(33020190,'UniCredit Bank - HypoVereinsbank','99'),(33030000,'GEFA BANK','06'),(33040001,'Commerzbank','13'),(33040310,'Commerzbank Zw 117','13'),(33050000,'Stadtsparkasse Wuppertal','00'),(33060098,'Credit- und Volksbank Wuppertal','06'),(33060592,'Sparda-Bank West','51'),(33060616,'apoBank','A4'),(33070024,'Deutsche Bank Privat und Geschäftskunden','63'),(33070090,'Deutsche Bank','63'),(33080001,'Commerzbank vormals Dresdner Bank, PCC DCC-ITGK 1','09'),(33080030,'Commerzbank vormals Dresdner Bank','76'),(33080085,'Commerzbank vormals Dresdner Bank, PCC DCC-ITGK 2','09'),(33080086,'Commerzbank vormals Dresdner Bank, PCC DCC-ITGK 3','09'),(33080087,'Commerzbank vormals Dresdner Bank, PCC DCC-ITGK 4','09'),(33080088,'Commerzbank vormals Dresdner Bank, PCC DCC-ITGK 5','09'),(33440035,'Commerzbank','13'),(33450000,'Sparkasse Hilden-Ratingen-Velbert','00'),(33451220,'Sparkasse Heiligenhaus -alt-','00'),(34040049,'Commerzbank','13'),(34050000,'Stadtsparkasse Remscheid','00'),(34051350,'Sparkasse Radevormwald-Hückeswagen','00'),(34051570,'Stadtsparkasse Wermelskirchen','00'),(34060094,'Volksbank Remscheid-Solingen Remscheid-Lennep','00'),(34070024,'Deutsche Bank Privat und Geschäftskunden','63'),(34070093,'Deutsche Bank','63'),(34080031,'Commerzbank vormals Dresdner Bank','76'),(34240050,'Commerzbank','13'),(34250000,'Stadt-Sparkasse Solingen','00'),(34270024,'Deutsche Bank Privat und Geschäftskunden','63'),(34270094,'Deutsche Bank','63'),(34280032,'Commerzbank vormals Dresdner Bank','76'),(35010111,'SEB','13'),(35040038,'Commerzbank','13'),(35040085,'Commerzbank, Gf Web-K','13'),(35050000,'Sparkasse Duisburg','00'),(35060190,'Bank für Kirche und Diakonie - KD-Bank','06'),(35060386,'Volksbank Rhein-Ruhr','40'),(35060632,'apoBank','A4'),(35070024,'Deutsche Bank Privat und Geschäftskunden','63'),(35070030,'Deutsche Bank','63'),(35080070,'Commerzbank vormals Dresdner Bank','76'),(35080085,'Commerzbank vormals Dresdner Bank, PCC DCC-ITGK 1','09'),(35080086,'Commerzbank vormals Dresdner Bank, PCC DCC-ITGK 2','09'),(35080087,'Commerzbank vormals Dresdner Bank, PCC DCC-ITGK 3','09'),(35080088,'Commerzbank vormals Dresdner Bank, PCC DCC-ITGK 4','09'),(35080089,'Commerzbank vormals Dresdner Bank, PCC DCC-ITGK 5','09'),(35090300,'Bank für Schiffahrt (BFS) Fil d Ostfr VB Leer','09'),(35211012,'SEB','13'),(35251000,'Sparkasse Dinslaken-Voerde-Hünxe -alt-','00'),(35261248,'Volksbank Dinslaken','06'),(35450000,'Sparkasse am Niederrhein','00'),(35451460,'Sparkasse Neukirchen-Vluyn -alt-','00'),(35451775,'Sparkasse Rheinberg -alt-','00'),(35461106,'Volksbank Niederrhein','06'),(35640064,'Commerzbank','13'),(35650000,'Niederrheinische Sparkasse RheinLippe','00'),(35660599,'Volksbank Rhein-Lippe','06'),(35850000,'Stadtsparkasse Emmerich-Rees -alt-','00'),(35860245,'Volksbank Emmerich-Rees','06'),(36000000,'Bundesbank','09'),(36010043,'Postbank','24'),(36010111,'SEB','13'),(36010200,'VON ESSEN Bank','09'),(36010424,'Aareal Bank','09'),(36010600,'NIBC Bank Deutschland','06'),(36010699,'NIBC Bank Deutschland Asset Backed Securities','06'),(36020030,'National-Bank Essen','10'),(36020186,'UniCredit Bank - HypoVereinsbank','99'),(36033300,'Santander Consumer Bank','09'),(36036000,'VALOVIS Bank','09'),(36040039,'Commerzbank','13'),(36040060,'Commerzbank CC','09'),(36040061,'Commerzbank CC','09'),(36040085,'Commerzbank, Gf Web-K','13'),(36050105,'Sparkasse Essen','78'),(36060192,'Pax-Bank','06'),(36060295,'Bank im Bistum Essen','06'),(36060488,'GENO BANK ESSEN','34'),(36060591,'Sparda-Bank West','51'),(36060610,'apoBank','A4'),(36070024,'Deutsche Bank Privat und Geschäftskunden','63'),(36070050,'Deutsche Bank','63'),(36080080,'Commerzbank vormals Dresdner Bank','76'),(36080085,'Commerzbank vormals Dresdner Bank, PCC DCC-ITGK  2','09'),(36089321,'Commerzbank vormals Dresdner Bank ITGK','09'),(36210111,'SEB','13'),(36240045,'Commerzbank','13'),(36250000,'Sparkasse Mülheim an der Ruhr','06'),(36270024,'Deutsche Bank Privat und Geschäftskunden','63'),(36270048,'Deutsche Bank','63'),(36280071,'Commerzbank vormals Dresdner Bank','76'),(36540046,'Commerzbank','13'),(36550000,'Stadtsparkasse Oberhausen','00'),(36570024,'Deutsche Bank Privat und Geschäftskunden','63'),(36570049,'Deutsche Bank','63'),(36580072,'Commerzbank vormals Dresdner Bank','76'),(37000000,'Bundesbank','09'),(37010050,'Postbank','24'),(37010111,'SEB','13'),(37010600,'BNP Paribas Niederlassung Deutschland','09'),(37010699,'BNP Paribas Niederlassung Deutschland','09'),(37011000,'Deutsche Postbank Easytrade','24'),(37013030,'Deutsche Post Zahlungsdienste','01'),(37020090,'UniCredit Bank - HypoVereinsbank','99'),(37020200,'AXA Bank','09'),(37020400,'TOYOTA Kreditbank','09'),(37020500,'Bank für Sozialwirtschaft','09'),(37020600,'Santander Consumer Bank MG','09'),(37020900,'Ford Bank Ndl. der FCE Bank','09'),(37021100,'Mazda Bank Niederlassung der FCE Bank','09'),(37021300,'Jaguar Financial Services Ndl der FCE Bank','09'),(37021400,'Land Rover Financial Services Ndl der FCE Bank','09'),(37030200,'Oppenheim, Sal - jr & Cie','09'),(37030700,'abcbank','19'),(37030800,'Isbank Fil Köln','06'),(37040037,'Commerzbank, CC SP','09'),(37040044,'Commerzbank','13'),(37040048,'Commerzbank GF-K48','13'),(37040060,'Commerzbank CC','09'),(37040061,'Commerzbank CC','09'),(37050198,'Sparkasse KölnBonn','00'),(37050299,'Kreissparkasse Köln','B5'),(37060120,'Pax-Bank Gf MHD','06'),(37060193,'Pax-Bank','06'),(37060590,'Sparda-Bank West','51'),(37060615,'apoBank','A4'),(37060993,'PSD Bank Köln','91'),(37062124,'Bensberger Bank','06'),(37062365,'Raiffeisenbank Frechen-Hürth','06'),(37062600,'VR Bank Bergisch Gladbach','06'),(37063367,'Raiffeisenbank Fischenich-Kendenich','06'),(37069101,'Spar- und Darlehnskasse Aegidienberg','06'),(37069103,'Raiffeisenbank Aldenhoven','06'),(37069125,'Raiffeisenbank Kürten-Odenthal','06'),(37069153,'Spar- und Darlehnskasse Brachelen -alt-','06'),(37069164,'Volksbank Meerbusch','06'),(37069252,'Volksbank Erft','06'),(37069302,'Raiffeisenbank','06'),(37069303,'Volksbank Gemünd-Kall -alt-','06'),(37069306,'Raiffeisenbank Grevenbroich','06'),(37069322,'Raiffeisenbank Gymnich','06'),(37069330,'Volksbank Haaren','06'),(37069331,'Raiffeisenbank von 1895 Zw Horrem -alt-','06'),(37069342,'Volksbank Heimbach','06'),(37069354,'Raiffeisenbank Selfkant Zw -alt-','06'),(37069355,'Spar- und Darlehnskasse Hoengen','06'),(37069381,'VR-Bank Rur-Wurm -alt-','06'),(37069401,'Raiffeisenbank Junkersdorf','06'),(37069405,'Raiffeisenbank Kaarst','06'),(37069412,'Volksbank Heinsberg','06'),(37069427,'Volksbank Dünnwald-Holweide','06'),(37069429,'Volksbank Köln-Nord','06'),(37069472,'Raiffeisenbk Erftstadt -alt-','06'),(37069520,'VR-Bank Rhein-Sieg','06'),(37069521,'Raiffeisenbank Rhein-Berg -alt-','06'),(37069524,'Raiffeisenbank Much-Ruppichteroth','06'),(37069577,'Raiffeisenbank Odenthal -alt-','06'),(37069627,'Raiffeisenbank Voreifel','06'),(37069639,'Rosbacher Raiffeisenbank','06'),(37069642,'Raiffeisenbank','06'),(37069707,'Raiffeisenbank Sankt Augustin','06'),(37069720,'VR-Bank Nordeifel','06'),(37069805,'Volksbank Wachtberg','06'),(37069833,'Raiffeisenbk Wesseling -alt-','06'),(37069840,'Volksbank Wipperfürth-Lindlar','06'),(37069991,'Brühler Bank','06'),(37070000,'Deutsche Bank - Kontoservice für Kunden Sal. Oppenheim','63'),(37070024,'Deutsche Bank Privat und Geschäftskunden','63'),(37070060,'Deutsche Bank','63'),(37080040,'Commerzbank vormals Dresdner Bank','76'),(37080085,'Commerzbank vormals Dresdner Bank Gf PCC DCC-ITGK 1','09'),(37080086,'Commerzbank vormals Dresdner Bank, PCC DCC-ITGK 4','09'),(37080087,'Commerzbank vormals Dresdner Bank, PCC DCC-ITGK 5','09'),(37080088,'Commerzbank vormals Dresdner Bank, PCC DCC-ITGK 6','09'),(37080089,'Commerzbank vormals Dresdner Bank, PCC DCC-ITGK 7','09'),(37080090,'Commerzbank vormals Dresdner Bank, PCC DCC-ITGK 8','09'),(37080091,'Commerzbank vormals Dresdner Bank, PCC DCC-ITGK 9','09'),(37080092,'Commerzbank vormals Dresdner Bank, PCC DCC-ITGK 10','09'),(37080093,'Commerzbank vormals Dresdner Bank, PCC DCC-ITGK 11','09'),(37080094,'Commerzbank vormals Dresdner Bank, PCC DCC-ITGK 12','09'),(37080095,'Commerzbank vormals Dresdner Bank, PCC DCC-ITGK 13','09'),(37080096,'Commerzbank vormals Dresdner Bank Zw 96','76'),(37080097,'Commerzbank vormals Dresdner Bank Zw 97','76'),(37080098,'Commerzbank vormals Dresdner Bank, PCC DCC-ITGK 14','09'),(37080099,'Commerzbank vormals Dresdner Bank Zw 99','76'),(37089340,'Commerzbank vormals Dresdner Bank ITGK I','09'),(37089342,'Commerzbank vormals Dresdner Bank ITGK II','09'),(37160087,'Kölner Bank','06'),(37161289,'VR-Bank Rhein-Erft','06'),(37540050,'Commerzbank','13'),(37551020,'Stadt-Sparkasse Leichlingen','00'),(37551440,'Sparkasse Leverkusen','00'),(37551780,'Stadt-Sparkasse Langenfeld','00'),(37560092,'Volksbank Rhein-Wupper','06'),(37570024,'Deutsche Bank Privat und Geschäftskunden','63'),(37570064,'Deutsche Bank','63'),(38010053,'Postbank Zentrale','09'),(38010111,'SEB','13'),(38010700,'DSL Bank','09'),(38010900,'KfW Ndl Bonn','09'),(38010999,'KfW Ausbildungsförderung Bonn','06'),(38011000,'VÖB-ZVD Processing','09'),(38011001,'VÖB-ZVD Processing','09'),(38011002,'VÖB-ZVD Processing','09'),(38011003,'VÖB-ZVD Processing','09'),(38011004,'VÖB-ZVD Processing','09'),(38011005,'VÖB-ZVD Processing','09'),(38011006,'VÖB-ZVD Processing','09'),(38011007,'VÖB-ZVD Processing','09'),(38011008,'VÖB-ZVD Processing','09'),(38020090,'UniCredit Bank - HypoVereinsbank','99'),(38040007,'Commerzbank','13'),(38050000,'Sparkasse Bonn -alt-','00'),(38051290,'Stadtsparkasse Bad Honnef','00'),(38060186,'Volksbank Bonn Rhein-Sieg','06'),(38070024,'Deutsche Bank Privat und Geschäftskunden','63'),(38070059,'Deutsche Bank','63'),(38070724,'Deutsche Bank Privat und Geschäftskunden F 950','63'),(38077724,'Deutsche Bank Privat und Geschäftskunden F 950','63'),(38080055,'Commerzbank vormals Dresdner Bank','76'),(38160220,'VR-Bank Bonn','06'),(38250110,'Kreissparkasse Euskirchen','00'),(38260082,'Volksbank Euskirchen','06'),(38440016,'Commerzbank','13'),(38450000,'Sparkasse Gummersbach-Bergneustadt','00'),(38452490,'Sparkasse der Homburgischen Gemeinden','00'),(38462135,'Volksbank Oberberg','06'),(38470024,'Deutsche Bank Privat und Geschäftskunden','63'),(38470091,'Deutsche Bank','63'),(38621500,'Steyler Bank','38'),(38650000,'Kreissparkasse Siegburg','00'),(38651390,'Sparkasse Hennef','00'),(39010111,'SEB','13'),(39020000,'Aachener Bausparkasse','09'),(39040013,'Commerzbank','13'),(39050000,'Sparkasse Aachen','00'),(39060180,'Aachener Bank','06'),(39060630,'apoBank','A4'),(39061981,'Heinsberger Volksbank -alt-','06'),(39070020,'Deutsche Bank','63'),(39070024,'Deutsche Bank Privat und Geschäftskunden','63'),(39080005,'Commerzbank vormals Dresdner Bank','76'),(39080098,'Commerzbank vormals Dresdner Bank Zw 98','76'),(39080099,'Commerzbank vormals Dresdner Bank Zw 99','76'),(39160191,'Pax-Bank','06'),(39161490,'Volksbank Aachen Süd','06'),(39162980,'VR-Bank','06'),(39362254,'Raiffeisen-Bank Eschweiler','06'),(39540052,'Commerzbank','13'),(39550110,'Sparkasse Düren','00'),(39560201,'Volksbank Düren','06'),(39570024,'Deutsche Bank Privat und Geschäftskunden','63'),(39570061,'Deutsche Bank','63'),(39580041,'Commerzbank vormals Dresdner Bank','76'),(40010111,'SEB','13'),(40022000,'NRW.BANK','08'),(40030000,'Münsterländische Bank Thie & Co','61'),(40040028,'Commerzbank','13'),(40050000,'Landesbank Hessen-Thüringen Girozentrale NL. Düsseldorf','08'),(40050150,'Sparkasse Münsterland Ost','00'),(40055555,'LBS Westdeutsche Landesbausparkasse','09'),(40060000,'DZ BANK','44'),(40060265,'DKM Darlehnskasse Münster','34'),(40060300,'WL BANK Westfälische Landschaft Bodenkreditbank','34'),(40060560,'Sparda-Bank Münster','85'),(40060614,'apoBank','A4'),(40061238,'Volksbank Greven','34'),(40069226,'Volksbank Lette-Darup-Rorup','34'),(40069266,'Volksbank Marsberg','34'),(40069283,'Volksbank Schlangen','34'),(40069348,'Volksbank Medebach -alt-','34'),(40069362,'Volksbank','34'),(40069363,'Volksbank Schermbeck','34'),(40069371,'Volksbank Thülen','34'),(40069408,'Volksbank Baumberge','34'),(40069462,'Volksbank Sprakel -alt-','34'),(40069477,'Volksbank Wulfen -alt-','34'),(40069546,'Volksbank Senden','34'),(40069600,'Volksbank Amelsbüren','34'),(40069601,'Volksbank Ascheberg-Herbern','34'),(40069606,'Volksbank Erle','34'),(40069622,'Volksbank Seppenrade','34'),(40069709,'Volksbank Lembeck-Rhade','34'),(40069716,'Volksbank Südkirchen-Capelle-Nordkirchen','34'),(40070024,'Deutsche Bank Privat und Geschäftskunden','63'),(40070080,'Deutsche Bank','63'),(40080040,'Commerzbank vormals Dresdner Bank','76'),(40080085,'Commerzbank vormals Dresdner Bank, PCC DCC-ITGK 1','09'),(40090900,'PSD Bank Westfalen-Lippe','91'),(40150001,'Helaba Düsseldorf Gf Verrechnung FI-Münster','09'),(40153768,'Verbundsparkasse Emsdetten Ochtrup','01'),(40154006,'Sparkasse Gronau','00'),(40154476,'Stadtsparkasse Lengerich','00'),(40154530,'Sparkasse Westmünsterland','00'),(40154702,'Stadtsparkasse Stadtlohn','00'),(40160050,'Vereinigte Volksbank Münster','34'),(40163720,'Volksbank Nordmünsterland -alt-','34'),(40164024,'Volksbank Gronau-Ahaus','34'),(40164256,'Volksbank Laer-Horstmar-Leer','34'),(40164352,'Volksbank Nottuln','34'),(40164528,'Volksbank Lüdinghausen-Olfen','34'),(40164618,'Volksbank','34'),(40164901,'Volksbank Gescher','34'),(40165366,'Volksbank Selm-Bork','34'),(40166439,'Volksbank Lengerich/Lotte -alt-','34'),(40166800,'Volksbank Buldern -alt-','34'),(40340030,'Commerzbank','13'),(40350005,'Stadtsparkasse Rheine','00'),(40351060,'Kreissparkasse Steinfurt','00'),(40351220,'Sparkasse Steinfurt -alt-','00'),(40361627,'Volksbank Westerkappeln-Wersen','34'),(40361906,'VR-Bank Kreis Steinfurt','34'),(40363433,'Volksbank Hörstel -alt-','34'),(40370024,'Deutsche Bank Privat und Geschäftskunden','63'),(40370079,'Deutsche Bank','63'),(41010111,'SEB','13'),(41040018,'Commerzbank','13'),(41041000,'ZTB der Commerzbank','13'),(41050095,'Sparkasse Hamm','00'),(41051605,'Stadtsparkasse Werne -alt-','00'),(41051845,'Sparkasse Bergkamen-Bönen','00'),(41060120,'Volksbank Hamm -alt-','34'),(41061011,'Spar- und Darlehnskasse Bockum-Hövel','34'),(41061903,'BAG Bankaktiengesellschaft','34'),(41062215,'Volksbank Bönen','34'),(41070024,'Deutsche Bank Privat und Geschäftskunden','63'),(41070049,'Deutsche Bank','63'),(41240048,'Commerzbank','13'),(41250035,'Sparkasse Beckum-Wadersloh','00'),(41260006,'Volksbank Beckum -alt-','34'),(41261324,'Volksbank Enniger-Ostenfelde-Westkirchen','34'),(41261419,'Volksbank Oelde-Ennigerloh-Neubeckum -alt-','34'),(41262501,'Volksbank','34'),(41262621,'Vereinigte Volksbank Telgte -alt-','34'),(41280043,'Commerzbank vormals Dresdner Bank','76'),(41440018,'Commerzbank','13'),(41450075,'Sparkasse Soest','00'),(41451750,'Sparkasse Werl','00'),(41460116,'Volksbank Hellweg','34'),(41462295,'Volksbank Wickede (Ruhr)','34'),(41650001,'Sparkasse Lippstadt','00'),(41651770,'Sparkasse Hochsauerland','00'),(41651815,'Sparkasse Erwitte-Anröchte','00'),(41651965,'Sparkasse Geseke','00'),(41652560,'Sparkasse Warstein-Rüthen -alt-','00'),(41660124,'Volksbank Beckum-Lippstadt','34'),(41661206,'Volksbank Anröchte','34'),(41661504,'Volksbank Benninghausen -alt-','34'),(41661719,'Volksbank Brilon -alt-','34'),(41662465,'Volksbank Störmede','34'),(41662557,'Volksbank Warstein-Belecke -alt-','34'),(41663335,'Volksbank Hörste','34'),(41670024,'Deutsche Bank Privat und Geschäftskunden','63'),(41670027,'Deutsche Bank','63'),(41670028,'Deutsche Bank','63'),(41670029,'Deutsche Bank','63'),(41670030,'Deutsche Bank','63'),(42010111,'SEB','13'),(42030600,'Isbank Fil Gelsenkirchen','06'),(42040040,'Commerzbank','13'),(42050001,'Sparkasse Gelsenkirchen','25'),(42070024,'Deutsche Bank Privat und Geschäftskunden','63'),(42070062,'Deutsche Bank','63'),(42080082,'Commerzbank vormals Dresdner Bank','76'),(42260001,'Volksbank Ruhr Mitte','34'),(42450040,'Stadtsparkasse Gladbeck','00'),(42451220,'Sparkasse Bottrop','00'),(42461435,'Volksbank Kirchhellen','34'),(42610112,'SEB','13'),(42640048,'Commerzbank','13'),(42650150,'Sparkasse Vest Recklinghausen','00'),(42651315,'Stadtsparkasse Haltern am See','00'),(42661008,'Volksbank Marl-Recklinghausen','34'),(42661330,'Volksbank Haltern','34'),(42661717,'Volksbank Waltrop','34'),(42662320,'Volksbank Dorsten','34'),(42680081,'Commerzbank vormals Dresdner Bank','76'),(42840005,'Commerzbank','13'),(42850035,'Stadtsparkasse Bocholt','00'),(42860003,'Volksbank Bocholt','34'),(42861239,'Spar- und Darlehnskasse','34'),(42861387,'VR-Bank Westmünsterland','34'),(42861515,'Volksbank Gemen','34'),(42861608,'Volksbank Heiden','34'),(42861814,'Volksbank Rhede','34'),(42862451,'Volksbank Raesfeld','34'),(42870024,'Deutsche Bank Privat und Geschäftskunden','63'),(42870077,'Deutsche Bank','63'),(43000000,'Bundesbank','09'),(43010111,'SEB','13'),(43040036,'Commerzbank','13'),(43050001,'Sparkasse Bochum','00'),(43051040,'Sparkasse Hattingen','00'),(43060129,'Volksbank Bochum Witten','34'),(43060967,'GLS Gemeinschaftsbank','34'),(43070024,'Deutsche Bank Privat und Geschäftskunden','63'),(43070061,'Deutsche Bank','63'),(43080083,'Commerzbank vormals Dresdner Bank','76'),(43250030,'Herner Sparkasse','00'),(44000000,'Bundesbank','09'),(44010046,'Postbank','24'),(44010111,'SEB','13'),(44020090,'UniCredit Bank - HypoVereinsbank','99'),(44040037,'Commerzbank','13'),(44040060,'Commerzbank CC','09'),(44040061,'Commerzbank CC','09'),(44040085,'Commerzbank, Gf Web-K','13'),(44050000,'Landesbank Hessen-Thüringen Girozentrale NL. Düsseldorf','08'),(44050199,'Sparkasse Dortmund','06'),(44060122,'Volksbank Dortmund-Nordwest','34'),(44060604,'apoBank','A4'),(44064406,'Bank für Kirche und Diakonie - KD-Bank Gf Sonder-BLZ','09'),(44070024,'Deutsche Bank Privat und Geschäftskunden','63'),(44070050,'Deutsche Bank','63'),(44080050,'Commerzbank vormals Dresdner Bank','76'),(44080055,'Commerzbank vormals Dresdner Bank Zw 55','76'),(44080057,'Commerzbank vormals Dresdner Bank Gf ZW 57','76'),(44080085,'Commerzbank vormals Dresdner Bank, PCC DCC-ITGK 2','09'),(44089320,'Commerzbank vormals Dresdner Bank ITGK','09'),(44090920,'PSD Bank Dortmund -alt-','91'),(44152370,'Sparkasse an der Lippe','00'),(44152490,'Stadtsparkasse Schwerte','00'),(44160014,'Dortmunder Volksbank','34'),(44340037,'Commerzbank','13'),(44350060,'Sparkasse UnnaKamen','00'),(44351380,'Sparkasse Kamen -alt-','00'),(44351740,'Sparkasse Fröndenberg','00'),(44361342,'Volksbank Kamen-Werne','34'),(44540022,'Commerzbank','13'),(44550045,'Sparkasse der Stadt Iserlohn','00'),(44551210,'Sparkasse Märkisches Sauerland Hemer-Menden','00'),(44570004,'Deutsche Bank','63'),(44570024,'Deutsche Bank Privat und Geschäftskunden','63'),(44580070,'Commerzbank vormals Dresdner Bank','76'),(44580085,'Commerzbank vormals Dresdner Bank, PCC DCC-ITGK 1','09'),(44750065,'Sparkasse Menden -alt-','00'),(44761312,'Mendener Bank','34'),(44761534,'Volksbank im Märkischen Kreis','34'),(45000000,'Bundesbank','09'),(45040042,'Commerzbank','13'),(45050001,'Sparkasse HagenHerdecke','09'),(45051485,'Stadtsparkasse Herdecke','00'),(45060009,'Märkische Bank','34'),(45061524,'Volksbank Hohenlimburg','34'),(45070002,'Deutsche Bank','63'),(45070024,'Deutsche Bank Privat und Geschäftskunden','63'),(45080060,'Commerzbank vormals Dresdner Bank','76'),(45240056,'Commerzbank','13'),(45250035,'Sparkasse Witten','00'),(45251480,'Stadtsparkasse Wetter','00'),(45251515,'Stadtsparkasse Sprockhövel','00'),(45260041,'Volksbank Witten -alt-','34'),(45260475,'Spar- u Kreditbank d Bundes Fr ev Gemeinden','34'),(45261547,'Volksbank Sprockhövel','34'),(45450050,'Stadtsparkasse Gevelsberg','00'),(45451060,'Sparkasse Ennepetal-Breckerfeld','00'),(45451555,'Städtische Sparkasse zu Schwelm','09'),(45660029,'Volksbank Altena -alt-','34'),(45840026,'Commerzbank','13'),(45841031,'Commerzbank','13'),(45850005,'Sparkasse Lüdenscheid','00'),(45851020,'Vereinigte Sparkasse im Märkischen Kreis','00'),(45851665,'Sparkasse Kierspe-Meinerzhagen','00'),(45860033,'Volksbank Lüdenscheid -alt-','34'),(45861434,'Volksbank Kierspe','34'),(45861617,'Volksbank Meinerzhagen -alt-','34'),(46010111,'SEB','13'),(46040033,'Commerzbank','13'),(46050001,'Sparkasse Siegen','00'),(46051240,'Sparkasse Burbach-Neunkirchen','00'),(46051733,'Stadtsparkasse Freudenberg -alt-','00'),(46051875,'Stadtsparkasse Hilchenbach','00'),(46052855,'Stadtsparkasse Schmallenberg','00'),(46053480,'Sparkasse Wittgenstein','00'),(46060040,'Volksbank Siegerland','34'),(46061724,'VR-Bank Freudenberg-Niederfischbach','34'),(46062817,'Volksbank Bigge-Lenne','34'),(46063405,'Volksbank Wittgenstein','34'),(46070024,'Deutsche Bank Privat und Geschäftskunden','63'),(46070090,'Deutsche Bank','63'),(46080010,'Commerzbank vormals Dresdner Bank','76'),(46240016,'Commerzbank','13'),(46250049,'Sparkasse Olpe-Drolshagen-Wenden','00'),(46251590,'Sparkasse Finnentrop','00'),(46251630,'Sparkasse Attendorn-Lennestadt-Kirchhundem','00'),(46260023,'Volksbank Olpe -alt-','34'),(46261607,'Volksbank Grevenbrück -alt','34'),(46261822,'Volksbank Olpe-Wenden-Drolshagen','34'),(46262456,'Volksbank Bigge-Lenne -alt-','34'),(46441003,'Commerzbank','13'),(46451012,'Sparkasse Meschede','00'),(46451250,'Sparkasse Bestwig -alt-','00'),(46461126,'Volksbank Sauerland -alt-','34'),(46462271,'Spar- und Darlehnskasse Oeventrop','34'),(46464453,'Volksbank Reiste-Eslohe','34'),(46640018,'Commerzbank','13'),(46650005,'Sparkasse Arnsberg-Sundern','00'),(46660022,'Volksbank Sauerland','34'),(46670007,'Deutsche Bank','63'),(46670024,'Deutsche Bank Privat und Geschäftskunden','63'),(47000000,'Deutsche Bundesbank Filiale Dortmund (Bargeldzentrum)','09'),(47240047,'Commerzbank','13'),(47250101,'Sparkasse Paderborn -alt-','00'),(47251550,'Sparkasse Höxter','00'),(47251740,'Stadtsparkasse Delbrück','00'),(47260121,'Volksbank Paderborn-Höxter-Detmold','34'),(47260234,'Volksbank Elsen-Wewer-Borchen','34'),(47260307,'Bank für Kirche und Caritas','34'),(47261429,'Volksbank Haaren -alt-','34'),(47261603,'Volksbank Brilon-Büren-Salzkotten','34'),(47262626,'Volksbank Westenholz','34'),(47262703,'Volksbank Delbrück-Hövelhof','34'),(47263472,'Volksbank Westerloh-Westerwiehe -alt-','34'),(47264367,'Vereinigte Volksbank','34'),(47265383,'Volksbank Wewelsburg-Ahden','34'),(47267216,'Volksbank Borgentreich -alt-','34'),(47270024,'Deutsche Bank Privat und Geschäftskunden','63'),(47270029,'Deutsche Bank','63'),(47460028,'Volksbank Warburger Land -alt-','34'),(47640051,'Commerzbank','13'),(47650130,'Sparkasse Paderborn-Detmold','00'),(47651225,'Stadtsparkasse Blomberg','00'),(47670023,'Deutsche Bank','63'),(47670024,'Deutsche Bank Privat und Geschäftskunden','63'),(47691200,'Volksbank Ostlippe','34'),(47840065,'Commerzbank','13'),(47840080,'Commerzbank Zw 80','09'),(47850065,'Sparkasse Gütersloh-Rietberg','A7'),(47852760,'Sparkasse Rietberg -alt-','00'),(47853355,'Stadtsparkasse Versmold','00'),(47853520,'Kreissparkasse Wiedenbrück','00'),(47860125,'Volksbank Bielefeld-Gütersloh','34'),(47861317,'Volksbank im Ostmünsterland','34'),(47861518,'Volksbank Harsewinkel -alt-','34'),(47861806,'Volksbank Kaunitz','34'),(47862261,'Volksbank Marienfeld -alt-','34'),(47862447,'Volksbank Rietberg','34'),(47863373,'Volksbank Versmold','34'),(47880031,'Commerzbank vormals Dresdner Bank','76'),(48000000,'Bundesbank','09'),(48010111,'SEB','13'),(48020086,'UniCredit Bank - HypoVereinsbank','99'),(48020151,'Bankhaus Lampe','32'),(48021900,'Bankverein Werther Zw Ndl der VB Paderborn-Höxter-Detmold','34'),(48040035,'Commerzbank','13'),(48040060,'Commerzbank CC','09'),(48040061,'Commerzbank CC','09'),(48050161,'Sparkasse Bielefeld','00'),(48051580,'Kreissparkasse Halle','00'),(48060036,'Bielefelder Volksbank -alt-','34'),(48062051,'Volksbank Halle/Westf','34'),(48062466,'Spar-u Darlehnskasse Schloß Holte-Stukenbrock -alt-','34'),(48070020,'Deutsche Bank','63'),(48070024,'Deutsche Bank Privat und Geschäftskunden','63'),(48070040,'Deutsche Bank','63'),(48070042,'Deutsche Bank','63'),(48070043,'Deutsche Bank','63'),(48070044,'Deutsche Bank','63'),(48070045,'Deutsche Bank','63'),(48070050,'Deutsche Bank','63'),(48070052,'Deutsche Bank','63'),(48080020,'Commerzbank vormals Dresdner Bank','76'),(48089350,'Commerzbank vormals Dresdner Bank ITGK','09'),(48250110,'Sparkasse Lemgo','00'),(48262248,'Volksbank Nordlippe -alt-','34'),(48291490,'Volksbank Bad Salzuflen','34'),(49040043,'Commerzbank','13'),(49050101,'Sparkasse Minden-Lübbecke','00'),(49051065,'Stadtsparkasse Rahden','00'),(49051285,'Stadtsparkasse Bad Oeynhausen','00'),(49051990,'Stadtsparkasse Porta Westfalica','00'),(49060127,'Volksbank Mindener Land','34'),(49060392,'Volksbank Minden','34'),(49061298,'Volksbank Bad Oeynhausen -alt-','34'),(49061470,'Volksbank Stemweder Berg -alt-','34'),(49061510,'Volksbank Eisbergen -alt-','34'),(49070024,'Deutsche Bank Privat und Geschäftskunden','63'),(49070028,'Deutsche Bank','63'),(49080025,'Commerzbank vormals Dresdner Bank','76'),(49092650,'Volksbank Lübbecker Land','34'),(49240096,'Commerzbank','13'),(49262364,'Volksbank Schnathorst','34'),(49440043,'Commerzbank','13'),(49450120,'Sparkasse Herford','00'),(49461323,'Volksbank Enger-Spenge -alt-','34'),(49490070,'Volksbank Bad Oeynhausen-Herford','34'),(50000000,'Bundesbank','09'),(50010060,'Postbank','24'),(50010111,'SEB','13'),(50010200,'AKBANK','09'),(50010424,'Aareal Bank','09'),(50010517,'ING-DiBa','C1'),(50010700,'Degussa Bank','B7'),(50010900,'Bank of America','09'),(50010910,'Bank of America, Filiale Frankfurt','09'),(50012800,'ALTE LEIPZIGER Bauspar','28'),(50020000,'Sberbank Europe Zndl Deutschland','28'),(50020200,'BHF-BANK','60'),(50020300,'Bremer Kreditbank','18'),(50020400,'KfW Kreditanstalt für Wiederaufbau Frankfurt','09'),(50020500,'Landwirtschaftliche Rentenbank','09'),(50020700,'Credit Europe Bank Ndl. Deutschland','09'),(50020800,'Intesa Sanpaolo Frankfurt','09'),(50021000,'ING Bank','60'),(50021100,'FIL Fondsbank','60'),(50021120,'FIL Fondsbank','60'),(50023400,'Bank of Beirut Ndl Frankfurt','09'),(50025000,'Opel Bank','10'),(50030000,'PSA Bank Deutschland','09'),(50030010,'PSA Bank Deutschland','09'),(50030100,'HKB Bank Frankfurt','00'),(50030500,'BNP PARIBAS Securities Services','09'),(50030600,'Deutsche WertpapierService Bank','09'),(50030700,'DenizBank (Wien) Zw Frankfurt','09'),(50031000,'Triodos Bank Deutschland','06'),(50033300,'Santander Consumer Bank','09'),(50038800,'Agricultural Bank of China, Frankfurt Branch','09'),(50040000,'Commerzbank','13'),(50040005,'Commerzbank, Filiale Frankfurt 2','13'),(50040033,'Commerzbank Gf BRS','09'),(50040038,'Commerzbank, MBP','13'),(50040040,'Commerzbank Gf ZRK','13'),(50040048,'Commerzbank GF-F48','13'),(50040050,'Commerzbank, CC SP','09'),(50040051,'Commerzbank Center Dresdner Bank Frankfurt','13'),(50040052,'Commerzbank Service - BZ Frankfurt','13'),(50040060,'Commerzbank Gf 460','09'),(50040061,'Commerzbank Gf 461','09'),(50040062,'Commerzbank CC','09'),(50040063,'Commerzbank CC','09'),(50040075,'Commerzbank Gf ZCM','13'),(50040084,'Commerzbank, GF Web-K CMTS2','13'),(50040085,'Commerzbank, Gf Web-K','13'),(50040086,'Commerzbank, GF Web-K CMTS','13'),(50040087,'Commerzbank, Gf Web-K CMTS3','13'),(50040088,'Commerzbank, INT 1','13'),(50040099,'Commerzbank INT','13'),(50042500,'Commerzbank Zw 425 - keine Auslandsbanken','13'),(50044444,'Commerzbank Vermögensverwaltung','13'),(50047010,'Commerzbank Service - BZ','13'),(50050000,'Landesbank Hessen-Thür Girozentrale','00'),(50050201,'Frankfurter Sparkasse','96'),(50050222,'Frankfurter Sparkasse GF 1822direkt','19'),(50050999,'DekaBank Frankfurt','00'),(50060000,'DZ Bank','09'),(50060400,'DZ BANK','09'),(50060411,'First Cash DZ BANK Frankfurt','09'),(50060412,'DZ BANK Gf vK','09'),(50060413,'DZ BANK Gf VK 2','09'),(50060414,'DZ BANK für Bausparkasse Schwäbisch Hall','09'),(50060415,'DZ BANK für Bausparkasse Schwäbisch Hall','09'),(50060416,'DZ BANK Gf VK 5','09'),(50060417,'DZ BANK Gf VK 6','09'),(50060474,'DZ BANK, Deutsche Zentral-Genossenschaftsbank','09'),(50061741,'Raiffeisenbank Oberursel','32'),(50069126,'VR Bank Alzey-Land-Schwabenheim','32'),(50069146,'Volksbank Grebenhain','32'),(50069187,'Volksbank Egelsbach -alt-','32'),(50069241,'Raiffeisenkasse Erbes-Büdesheim und Umgebung','32'),(50069345,'Raiffeisenbank','32'),(50069455,'Hüttenberger Bank','32'),(50069477,'Raiffeisenbank Kirtorf','32'),(50069693,'Raiffeisenbank Bad Homburg Ndl d FrankfurterVB','32'),(50069842,'Raiffeisen Volksbank','32'),(50069976,'Volksbank Wißmar','32'),(50070010,'Deutsche Bank Filiale','63'),(50070024,'Deutsche Bank Privat und Geschäftskunden','63'),(50073019,'Deutsche Bank','63'),(50073024,'Deutsche Bank Privat und Geschäftskunden','63'),(50073081,'Deutsche Bank Europe','63'),(50080000,'Commerzbank vormals Dresdner Bank','76'),(50080015,'Commerzbank vormals Dresdner Bank Zw 15','76'),(50080025,'Commerzbank vormals Dresdner Bank Zw 25','76'),(50080035,'Commerzbank vormals Dresdner Bank Zw 35','76'),(50080055,'Commerzbank vormals Dresdner Bank Zw 55','76'),(50080057,'Commerzbank vormals Dresdner Bank Gf ZW 57','76'),(50080060,'Commerzbank vormals Dresdner Bank Gf DrKW','76'),(50080061,'Commerzbank vormals Dresdner Bank Gf DrKWSL','76'),(50080077,'Commerzbank, GF Wüstenrot BSPK','09'),(50080079,'Commerzbank vormals Dresdner Bank ESOP','76'),(50080080,'Commerzbank vormals Dresdner Bank Bs 80','76'),(50080082,'Commerzbank vormals Dresdner Bank Gf AVB','76'),(50080086,'Commerzbank vormals Dresdner Bank ITGK 3','09'),(50080087,'Commerzbank vormals Dresdner Bank, PCC DCC-ITGK 4','09'),(50080088,'Commerzbank vormals Dresdner Bank, PCC DCC-ITGK 5','09'),(50080089,'Commerzbank vormals Dresdner Bank, PCC DCC-ITGK 6','09'),(50080091,'Commerzbank vormals Dresdner Bank, PCC DCC-ITGK 7','09'),(50080092,'Commerzbank vormals Dresdner Bank Finance and Controlling','76'),(50080099,'Commerzbank vormals Dresdner Bank Zw 99','76'),(50080300,'Commerzbank vormals Dresdner Bank Private Banking Inland','76'),(50083007,'Commerzbank vormals Dresdner Bank','76'),(50083838,'Commerzbank vormals Dresdner Bank in Frankfurt MBP','76'),(50089400,'Commerzbank vormals Dresdner Bank ITGK','09'),(50090200,'VR DISKONTBANK','00'),(50090500,'Sparda-Bank Hessen','73'),(50090607,'apoBank','A4'),(50090900,'PSD Bank Hessen-Thüringen','91'),(50092100,'Spar- u Kreditbank ev-freikirchl Gemeinden','06'),(50092200,'Volksbank Main-Taunus -alt-','06'),(50092900,'Volksbank Usinger Land Ndl d Frankfurter VB','06'),(50093000,'Rüsselsheimer Volksbank','06'),(50093010,'Rüsselsheimer Volksbank GAA','06'),(50093400,'Volksbank Kelsterbach Ndl d Frankfurter VB','06'),(50110200,'Industrial and Commercial Bank of China','09'),(50110300,'DVB Bank','10'),(50110400,'AKA Ausfuhrkredit GmbH','09'),(50110500,'NATIXIS Zweigniederlassung Deutschland','09'),(50110636,'Standard Chartered Bank Germany Branch','09'),(50110700,'Frankfurter Bankgesellschaft (Deutschland)','09'),(50110800,'J.P. Morgan','09'),(50110801,'J.P. Morgan, Internal Reference','94'),(50110855,'J.P. Morgan','09'),(50110900,'Bank of America N.A. Military Bank','09'),(50120000,'MAINFIRST BANK','09'),(50120100,'ICICI Bank UK, Germany Branch','09'),(50120383,'Bethmann Bank','D9'),(50120500,'Credit Suisse (Deutschland)','66'),(50120600,'Bank of Communications Frankfurt branch','09'),(50120900,'VakifBank International Wien Zndl Frankfurt','06'),(50123400,'VTB Bank (Austria), Zndl','28'),(50127000,'PKO Bank Polski Niederlassung Deutschland','09'),(50130000,'National Bank of Pakistan Zndl Frankfurt','09'),(50130200,'Oppenheim, Sal - jr & Cie','09'),(50130400,'Merck Finck Privatbankiers','10'),(50130600,'UBS Europe','09'),(50131000,'Vietnam Joint Stock Commercial Bank for Industry and Trade','E1'),(50190000,'Frankfurter Volksbank','06'),(50190300,'Volksbank Höchst a.M., ZwNdl. der Frankfurter VB -alt-','06'),(50190400,'Volksbank Griesheim','06'),(50210111,'SEB TZN Clearing','13'),(50210112,'SEB TZN MB Frankfurt','09'),(50210200,'Rabobank International Frankfurt Branch','18'),(50210212,'RaboDirect','18'),(50210295,'Rabobank International Frankfurt Branch','09'),(50210300,'Commerzbank (ehem. Hypothekenbank Frankfurt)','09'),(50210600,'equinet Bank','91'),(50210800,'ProCredit Bank, Frankfurt am Main','06'),(50210900,'Citigroup Global Markets Deutschland','06'),(50220085,'UBS Europe','09'),(50220500,'Bank of Scotland','00'),(50220900,'Hauck & Aufhäuser Privatbankiers','00'),(50230000,'ABC International Bank Frankfurt am Main','00'),(50230100,'Morgan Stanley Bank Internaional','09'),(50230600,'Isbank','06'),(50230700,'Metzler, B. - seel Sohn & Co','00'),(50230800,'Ikano Bank','09'),(50230888,'Ikano Bank','09'),(50234500,'KT Bank','09'),(50250200,'Deutsche Leasing Finance','09'),(50310400,'Barclays Bank Frankfurt','46'),(50310455,'Reiseschecks - Barclays Bank Frankfurt','46'),(50310900,'China Construction Bank Ndl Frankfurt','09'),(50320000,'VTB Bank (Deutschland)','00'),(50320191,'UniCredit Bank - HypoVereinsbank','99'),(50320500,'Banco Santander Filiale Frankfurt','09'),(50320600,'Attijariwafa bank Europa ZNdl. Frankfurt','09'),(50320900,'Pictet & Cie (Europe) Ndl Deutschland','09'),(50324000,'ABN AMRO Bank, Frankfurt Branch','31'),(50324040,'ABN AMRO Bank, MoneYou','31'),(50330000,'State Bank of India','06'),(50330200,'MHB-Bank','06'),(50330300,'The Bank of New York Mellon','09'),(50330500,'BANQUE CHAABI DU MAROC Agentur Frankfurt Ndl. Deutschland','09'),(50330600,'Bank Sepah-Iran','09'),(50334400,'The Bank of New York Mellon NL Frankfurt','09'),(50400000,'Bundesbank Zentrale','09'),(50510111,'SEB','13'),(50520190,'UniCredit Bank - HypoVereinsbank','99'),(50522222,'FIDOR Bank Zndl Frankfurt am Main','09'),(50530000,'Cronbank','06'),(50540028,'Commerzbank','13'),(50550020,'Städtische Sparkasse Offenbach a.M.','06'),(50560102,'Raiffeisenbank Offenbach/M.-Bieber','32'),(50561315,'Vereinigte Volksbank Maingau','32'),(50570018,'Deutsche Bank','63'),(50570024,'Deutsche Bank Privat und Geschäftskunden','63'),(50580005,'Commerzbank vormals Dresdner Bank','76'),(50580085,'Commerzbank vormals Dresdner Bank, PCC DCC-ITGK 1','09'),(50590000,'Offenbacher Volksbank -alt-','06'),(50592200,'Volksbank Dreieich','32'),(50640015,'Commerzbank','13'),(50650023,'SPARKASSE HANAU','00'),(50652124,'Sparkasse Langen-Seligenstadt','00'),(50661639,'VR Bank Main-Kinzig-Büdingen','32'),(50661816,'Volksbank Heldenbergen Ndl d Frankfurter VB','06'),(50662299,'Raiffeisenbank Bruchköbel -alt-','32'),(50662669,'Raiffeisenbank Maintal Ndl d Frankfurter VB','32'),(50663699,'Raiffeisenbank','32'),(50670009,'Deutsche Bank','63'),(50670024,'Deutsche Bank Privat und Geschäftskunden','63'),(50680002,'Commerzbank vormals Dresdner Bank','76'),(50680085,'Commerzbank vormals Dresdner Bank, PCC DCC-ITGK 1','09'),(50690000,'Volksbank Raiffeisenbank Hanau Ndl d Frankf VB','32'),(50691300,'DZB BANK','09'),(50692100,'Volksbank Seligenstadt','06'),(50740048,'Commerzbank','13'),(50750094,'Kreissparkasse Gelnhausen','01'),(50761333,'Volksbank -alt-','06'),(50761613,'Volksbank Büdingen -alt-','32'),(50763319,'Raiffeisenbank Vogelsberg -alt-','32'),(50780006,'Commerzbank vormals Dresdner Bank','76'),(50790000,'VR Bank Bad Orb-Gelnhausen','32'),(50793300,'Birsteiner Volksbank -alt-','06'),(50794300,'VR Bank Wächtersbach/Bad Soden-Salmünster -alt','32'),(50810900,'Deutsche Bausparkasse Badenia (ehem. DBS Bausparkasse)','09'),(50820292,'UniCredit Bank - HypoVereinsbank','99'),(50835800,'MCE Bank','09'),(50840005,'Commerzbank','13'),(50850049,'Landesbank Hessen-Thür Girozentrale','00'),(50850150,'Stadt- und Kreis-Sparkasse Darmstadt','06'),(50851952,'Sparkasse Odenwaldkreis','00'),(50852553,'Kreissparkasse Groß-Gerau','00'),(50852651,'Sparkasse Dieburg','00'),(50861393,'Spar- und Darlehnskasse Zell -alt-','32'),(50861501,'Raiffeisenbank Nördliche Bergstraße','32'),(50862311,'Volksbank Gräfenhausen -alt-','32'),(50862408,'Vereinigte Volksbank Griesheim-Weiterstadt -alt-','32'),(50862703,'Volksbank Gersprenztal-Otzberg','32'),(50862835,'Raiffeisenbank Schaafheim','32'),(50862903,'Volksbank Mainspitze','32'),(50863513,'Vereinigte Volksbank Raiffeisenbank','32'),(50864322,'Volksbank Modau','32'),(50864808,'Volksbank Seeheim-Jugenheim -alt-','32'),(50865224,'VB Mörfelden-Walldorf Ndl d Frankfurter VB','32'),(50865503,'Volksbank','32'),(50870005,'Deutsche Bank','63'),(50870024,'Deutsche Bank Privat und Geschäftskunden','63'),(50880050,'Commerzbank vormals Dresdner Bank','76'),(50880085,'Commerzbank vormals Dresdner Bank, PCC DCC-ITGK 1','09'),(50880086,'Commerzbank vormals Dresdner Bank, PCC DCC-ITGK 2','09'),(50890000,'Volksbank Darmstadt - Südhessen','06'),(50890634,'apoBank','A4'),(50950068,'Sparkasse Bensheim','00'),(50951469,'Sparkasse Starkenburg','01'),(50961206,'Raiffeisenbank Ried','32'),(50961312,'Raiffeisenbank Groß-Rohrheim','32'),(50961592,'Volksbank Weschnitztal','32'),(50961685,'Volksbank Überwald-Gorxheimertal','32'),(50970004,'Deutsche Bank','63'),(50970024,'Deutsche Bank Privat und Geschäftskunden','63'),(51010111,'SEB','13'),(51010400,'Aareal Bank','09'),(51010800,'Aareal Bank Zw L','09'),(51020000,'BHF-BANK','60'),(51020186,'UniCredit Bank - HypoVereinsbank','99'),(51040038,'Commerzbank','13'),(51050015,'Nassauische Sparkasse','A2'),(51051000,'S Broker Wiesbaden','56'),(51070021,'Deutsche Bank','63'),(51070024,'Deutsche Bank Privat und Geschäftskunden','63'),(51080060,'Commerzbank vormals Dresdner Bank','76'),(51080085,'Commerzbank vormals Dresdner Bank, PCC DCC-ITGK 1','09'),(51080086,'Commerzbank vormals Dresdner Bank, PCC DCC-ITGK2','09'),(51089410,'Commerzbank vormals Dresdner Bank ITGK','09'),(51090000,'Wiesbadener Volksbank','06'),(51090636,'apoBank','A4'),(51091500,'Rheingauer Volksbank','06'),(51091700,'vr bank Untertaunus','06'),(51091711,'vr bank Untertaunus','06'),(51140029,'Commerzbank','13'),(51150018,'Kreissparkasse Limburg','00'),(51151919,'Kreissparkasse Weilburg','00'),(51161606,'Volksbank Langendernbach','32'),(51170010,'Deutsche Bank','63'),(51170024,'Deutsche Bank Privat und Geschäftskunden','63'),(51180041,'Commerzbank vormals Dresdner Bank','76'),(51190000,'Vereinigte Volksbank Limburg -alt-','06'),(51191200,'Volksbank Goldner Grund -alt-','06'),(51191800,'Volksbank Schupbach','06'),(51192200,'Volks- und Raiffeisenbank Weilmünster -alt-','32'),(51210600,'BNP Paribas Niederlassung Deutschland','09'),(51210699,'BNP Paribas Niederlassung Deutschland','09'),(51210700,'NIBC Bank Zndl Frankfurt am Main','06'),(51210800,'Societe Generale','09'),(51210801,'SOCIETE GENERALE','09'),(51211000,'NATIXIS Pfandbriefbank','09'),(51220200,'SEB Merchant Banking','09'),(51220211,'SEB Frankfurt SAP','09'),(51220400,'Bank Saderat Iran','09'),(51220700,'ZIRAAT BANK International','09'),(51220800,'Banco do Brasil','09'),(51220900,'Morgan Stanley Bank','09'),(51220910,'Morgan Stanley Bank','50'),(51230500,'Standard Chartered Bank Germany Branch, Frankfurt','09'),(51230502,'Standard Chartered Bank Germany Branch','09'),(51230555,'Ikano Bank','09'),(51230600,'Europe ARAB Bank','09'),(51230800,'Wirecard Bank','09'),(51230801,'Wirecard Bank','09'),(51230802,'Wirecard Bank','09'),(51230805,'Wirecard Bank','09'),(51250000,'Taunus-Sparkasse','06'),(51300000,'Bundesbank eh Gießen','09'),(51310111,'SEB','13'),(51340013,'Commerzbank','13'),(51343224,'Commerzbank','13'),(51350025,'Sparkasse Gießen','10'),(51351526,'Sparkasse Grünberg','00'),(51352227,'Sparkasse Laubach-Hungen','00'),(51361021,'Volksbank Heuchelheim','32'),(51370008,'Deutsche Bank','63'),(51370024,'Deutsche Bank Privat und Geschäftskunden','63'),(51380040,'Commerzbank vormals Dresdner Bank','76'),(51380085,'Commerzbank vormals Dresdner Bank, PCC DCC-ITGK 1','09'),(51390000,'Volksbank Mittelhessen','06'),(51410600,'Bank of America Merrill Lynch International Zndl Frankfurt','09'),(51410700,'Bank of China','09'),(51410800,'OnVista Bank','09'),(51420200,'Misr Bank-Europe','11'),(51420300,'Bank Julius Bär Europe','17'),(51420600,'Svenska Handelsbanken Deutschland','09'),(51430300,'Nordea Bank, Niederlassung Frankfurt','09'),(51430321,'Nordea Bank Finland','09'),(51430345,'Nordea Bank AB, Niederlassung Frankfurt','00'),(51430400,'Goldman Sachs','09'),(51540037,'Commerzbank','13'),(51550035,'Sparkasse Wetzlar','00'),(51570008,'Deutsche Bank','63'),(51570024,'Deutsche Bank Privat und Geschäftskunden','63'),(51580044,'Commerzbank vormals Dresdner Bank','76'),(51591300,'Volksbank Brandoberndorf','06'),(51640043,'Commerzbank','13'),(51650045,'Sparkasse Dillenburg','00'),(51690000,'Volksbank Dill','06'),(51691500,'Volksbank Herborn-Eschenburg','06'),(51752267,'Sparkasse Battenberg','00'),(51762434,'VR Bank Biedenkopf-Gladenbach','06'),(51850079,'Sparkasse Oberhessen','06'),(51861325,'BVB Volksbank Ndl d Frankfurter Volksbank','06'),(51861403,'Volksbank Butzbach','32'),(51861616,'Landbank Horlofftal','32'),(51861806,'Volksbank Ober-Mörlen','32'),(51961023,'Volksbank Ulrichstein','32'),(51961515,'Spar- und Darlehnskasse Stockhausen','32'),(51961801,'Volksbank Feldatal','32'),(51990000,'Volksbank Lauterbach-Schlitz','06'),(52010111,'SEB','13'),(52040021,'Commerzbank','13'),(52050000,'Landeskreditkasse Kassel','00'),(52050353,'Kasseler Sparkasse','05'),(52051373,'Stadtsparkasse Borken (Hessen)','00'),(52051555,'Stadtsparkasse Felsberg','00'),(52051877,'Stadtsparkasse Grebenstein','00'),(52052154,'Kreissparkasse Schwalm-Eder','00'),(52053458,'Stadtsparkasse Schwalmstadt','00'),(52060000,'DZ BANK','09'),(52060208,'Kurhessische Landbank','32'),(52060400,'Evangelische Bank Gf','32'),(52060410,'Evangelische Bank','32'),(52061303,'Raiffeisenbank Borken','32'),(52062200,'VR-Bank Chattengau','32'),(52062601,'VR-Bank Schwalm-Eder','32'),(52063369,'VR-Bank Spangenberg-Morschen','32'),(52063550,'Raiffeisenbank','32'),(52064156,'Raiffeisenbank','32'),(52065220,'Raiffeisenbank -alt-','32'),(52069013,'Raiffeisenbank Burghaun','32'),(52069029,'Spar-u. Kredit-Bank','32'),(52069065,'Raiffeisenbank Langenschwarz -alt-','32'),(52069103,'Raiffeisenbank Trendelburg -alt-','32'),(52069149,'Raiffeisenbank Volkmarsen','32'),(52069519,'Frankenberger Bank Raiffeisenbank','32'),(52070012,'Deutsche Bank','63'),(52070024,'Deutsche Bank Privat und Geschäftskunden','63'),(52071212,'Deutsche Bank','63'),(52071224,'Deutsche Bank Privat und Geschäftskunden','63'),(52080080,'Commerzbank vormals Dresdner Bank','76'),(52080085,'Commerzbank vormals Dresdner Bank, PCC DCC-ITGK1','09'),(52090000,'Kasseler Bank','06'),(52090611,'apoBank','A4'),(52240006,'Commerzbank','13'),(52250030,'Sparkasse Werra-Meißner','00'),(52260385,'VR-Bank Werra-Meißner','32'),(52270012,'Deutsche Bank','63'),(52270024,'Deutsche Bank Privat und Geschäftskunden','63'),(52350005,'Sparkasse Waldeck-Frankenberg','00'),(52360059,'Waldecker Bank','32'),(52410300,'ReiseBank','09'),(52410310,'ReiseBank Gf2','09'),(52410400,'KEB Hana Bank (Deutschland)','19'),(52411000,'ReiseBank Gf3 vormals Cash Express','09'),(52411010,'ReiseBank Gf4 vormals Cash Express','09'),(52420000,'Credit Agricole CIB Deutschland','09'),(52420300,'SHINHAN BANK EUROPE','09'),(52420600,'Piraeus Bank Frankfurt Branch','30'),(52420700,'SECB Swiss Euro Clearing Bank','09'),(52430000,'Credit Mutuel - BECM - Ndl Deutschland','00'),(53040012,'Commerzbank','13'),(53050180,'Sparkasse Fulda','01'),(53051396,'Kreissparkasse Schlüchtern','01'),(53060180,'VR Genossenschaftsbank Fulda','32'),(53061230,'VR-Bank NordRhön','32'),(53061313,'VR Bank Schlüchtern-Birstein','32'),(53062035,'Raiffeisenbank','32'),(53062350,'Raiffeisenbank Biebergrund-Petersberg','32'),(53064023,'Raiffeisenbank','32'),(53070007,'Deutsche Bank','63'),(53070024,'Deutsche Bank Privat und Geschäftskunden','63'),(53080030,'Commerzbank vormals Dresdner Bank','76'),(53093200,'VR Bank HessenLand','32'),(53093255,'AgrarBank','32'),(53240048,'Commerzbank','13'),(53250000,'Sparkasse Bad Hersfeld-Rotenburg','A6'),(53260145,'Raiffeisenbank Asbach-Sorga','32'),(53261202,'Bankverein Bebra -alt-','32'),(53261342,'Raiffeisenbank Werratal-Landeck','32'),(53262073,'Raiffeisenbank Haunetal -alt-','32'),(53262455,'Raiffeisenbank Ronshausen-Marksuhl','32'),(53270012,'Deutsche Bank','63'),(53270024,'Deutsche Bank Privat und Geschäftskunden','63'),(53280081,'Commerzbank vormals Dresdner Bank','76'),(53290000,'VR-Bankverein Bad Hersfeld-Rotenburg','06'),(53340024,'Commerzbank','13'),(53350000,'Sparkasse Marburg-Biedenkopf','06'),(53361724,'Raiffeisenbank','32'),(53370008,'Deutsche Bank','63'),(53370024,'Deutsche Bank Privat und Geschäftskunden','63'),(53380042,'Commerzbank vormals Dresdner Bank','76'),(53381843,'Commerzbank vormals Dresdner Bank','76'),(53390635,'apoBank','A4'),(54020090,'UniCredit Bank - HypoVereinsbank','99'),(54030011,'Service Credit Union Overseas Headquarters','09'),(54040042,'Commerzbank','13'),(54050110,'Stadtsparkasse Kaiserslautern','00'),(54050220,'Kreissparkasse Kaiserslautern','00'),(54051550,'Kreissparkasse Kusel','00'),(54051660,'Stadtsparkasse Landstuhl -alt-','B2'),(54051990,'Sparkasse Donnersberg','00'),(54061650,'VR-Bank Westpfalz -alt-','32'),(54062027,'Raiffeisenbank Donnersberg -alt-','32'),(54070024,'Deutsche Bank Privat und Geschäftskunden','63'),(54070092,'Deutsche Bank','63'),(54080021,'Commerzbank vormals Dresdner Bank','76'),(54090000,'Volksbank Kaiserslautern','06'),(54091700,'Volksbank Lauterecken','06'),(54091800,'VR Bank Nordwestpfalz -alt-','06'),(54092400,'Volksbank Glan-Münchweiler','06'),(54210111,'SEB','13'),(54220091,'UniCredit Bank - HypoVereinsbank','99'),(54240032,'Commerzbank','13'),(54250010,'Sparkasse Südwestpfalz','00'),(54261700,'VR-Bank Südwestpfalz Pirmasens-Zweibrücken','32'),(54270024,'Deutsche Bank Privat und Geschäftskunden','63'),(54270096,'Deutsche Bank','63'),(54280023,'Commerzbank vormals Dresdner Bank','76'),(54290000,'VR-Bank Pirmasens -alt-','06'),(54291200,'Raiffeisen- u Volksbank Dahn','32'),(54500000,'Bundesbank','09'),(54510067,'Postbank','24'),(54520194,'UniCredit Bank - HypoVereinsbank','99'),(54540033,'Commerzbank','13'),(54550010,'Sparkasse Vorderpfalz','00'),(54550120,'Kreissparkasse Rhein-Pfalz','00'),(54561310,'RV Bank Rhein-Haardt','32'),(54570024,'Deutsche Bank Privat und Geschäftskunden','63'),(54570094,'Deutsche Bank','63'),(54580020,'Commerzbank vormals Dresdner Bank','76'),(54620093,'UniCredit Bank - HypoVereinsbank','99'),(54640035,'Commerzbank','13'),(54651240,'Sparkasse Rhein-Haardt','00'),(54661800,'Raiffeisenbank Freinsheim','32'),(54663270,'Raiffeisenbank Friedelsheim-Rödersheim','32'),(54670024,'Deutsche Bank Privat und Geschäftskunden','63'),(54670095,'Deutsche Bank','63'),(54680022,'Commerzbank vormals Dresdner Bank','76'),(54690623,'apoBank','A4'),(54691200,'VR Bank Mittelhaardt','06'),(54750010,'Kreis- und Stadtsparkasse Speyer','00'),(54790000,'Volksbank Kur- und Rheinpfalz','06'),(54850010,'Sparkasse Südliche Weinstraße in Landau','00'),(54851440,'Sparkasse Germersheim-Kandel','00'),(54861190,'Raiffeisenbank Oberhaardt-Gäu -alt-','32'),(54862390,'Raiffeisenbank -alt-','32'),(54862500,'VR Bank Südpfalz','32'),(54891300,'VR Bank Südliche Weinstraße-Wasgau','06'),(55000000,'Bundesbank','09'),(55010111,'SEB','13'),(55010400,'Aareal Bank GF - BK01 -','01'),(55010424,'Aareal Bank','09'),(55010625,'Aareal Bank Clearing Wiesbaden','09'),(55010800,'Investitions- und Strukturbank RP','09'),(55020000,'BHF-BANK','60'),(55020100,'Bausparkasse Mainz','09'),(55020486,'UniCredit Bank - HypoVereinsbank','99'),(55020500,'Bank für Sozialwirtschaft','09'),(55020555,'Bank für Sozialwirtschaft','09'),(55020600,'Westdeutsche Immobilienbank','09'),(55020700,'Süd-West-Kreditbank Finanzierung','16'),(55030500,'TARGO Commercial Finance','09'),(55030533,'TARGOBANK Direkt','06'),(55033300,'Santander Consumer Bank','09'),(55040022,'Commerzbank','13'),(55040060,'Commerzbank CC','09'),(55040061,'Commerzbank CC','09'),(55050000,'ZV Landesbank Baden-Württemberg','59'),(55050120,'Sparkasse Mainz','00'),(55060321,'VR-Bank Mainz -alt-','32'),(55060417,'VR-Bank Mainz -alt-','32'),(55060611,'Genobank Mainz','32'),(55060831,'apoBank','A4'),(55061303,'Budenheimer Volksbank','32'),(55061507,'VR-Bank Mainz -alt-','32'),(55061907,'Volksbank Rhein-Selz -alt-','32'),(55070024,'Deutsche Bank Privat und Geschäftskunden','63'),(55070040,'Deutsche Bank','63'),(55080044,'Commerzbank, TF MZ 1','76'),(55080065,'Commerzbank vormals Dresdner Bank','76'),(55080085,'Commerzbank vormals Dresdner Bank, PCC DCC-ITGK 1','09'),(55080086,'Commerzbank vormals Dresdner Bank, PCC DCC-ITGK 2','09'),(55080088,'Commerzbank, TF MZ 2','76'),(55090500,'Sparda-Bank Südwest','90'),(55091200,'Volksbank Alzey-Worms','06'),(55150098,'Clearingkonto LRP-SI','09'),(55160195,'Pax-Bank','06'),(55190000,'Mainzer Volksbank','00'),(55190028,'Mainzer Volksbank -alt-','00'),(55190050,'Mainzer Volksbank -alt-','00'),(55190064,'Mainzer Volksbank -alt-','00'),(55190065,'Mainzer Volksbank -alt-','00'),(55190068,'Mainzer Volksbank -alt-','00'),(55190088,'Mainzer Volksbank -alt-','00'),(55190094,'Mainzer Volksbank -alt-','00'),(55340041,'Commerzbank','13'),(55350010,'Sparkasse Worms-Alzey-Ried','03'),(55361202,'VR Bank','32'),(55362071,'Volksbank Bechtheim -alt-','32'),(55390000,'Volksbank Worms-Wonnegau -alt-','06'),(56020086,'UniCredit Bank - HypoVereinsbank','99'),(56050180,'Sparkasse Rhein-Nahe','00'),(56051790,'Kreissparkasse Rhein-Hunsrück','00'),(56061151,'Raiffeisenbank Kastellaun','38'),(56061472,'Volksbank Hunsrück-Nahe','38'),(56062227,'Volksbank Rheinböllen','40'),(56070024,'Deutsche Bank Privat und Geschäftskunden','63'),(56070040,'Deutsche Bank','63'),(56090000,'Volksbank Rhein-Nahe-Hunsrück','38'),(56240050,'Commerzbank','13'),(56250030,'Kreissparkasse Birkenfeld','B2'),(56261735,'Raiffeisenbank Nahe','38'),(56270024,'Deutsche Bank Privat und Geschäftskunden','63'),(56270044,'Deutsche Bank','63'),(56290000,'Volksbank-Raiffeisenbank Naheland -alt-','06'),(57000000,'Bundesbank','09'),(57010111,'SEB','13'),(57020086,'UniCredit Bank - HypoVereinsbank','99'),(57020301,'MKB Mittelrheinische Bank','09'),(57020500,'Oyak Anker Bank','D7'),(57020600,'Debeka Bausparkasse','09'),(57040044,'Commerzbank','13'),(57050120,'Sparkasse Koblenz','00'),(57051001,'Kreissparkasse Westerwald -alt-','00'),(57051870,'Kreissparkasse Cochem-Zell -alt-','00'),(57060000,'DZ BANK','44'),(57060612,'apoBank','A4'),(57062675,'Raiffeisenbank','38'),(57064221,'Volksbank Mülheim-Kärlich','38'),(57069067,'Raiffeisenbank Lutzerather Höhe -alt-','38'),(57069081,'Raiffeisenbank Moselkrampen','38'),(57069144,'Raiffeisenbank Eifeltor','38'),(57069238,'Raiffeisenbank Neustadt','38'),(57069257,'Raiffeisenbank Untermosel','38'),(57069315,'Raiffeisenbank Straßenhaus -alt-','38'),(57069361,'Raiffeisenbank Welling','38'),(57069727,'Raiffeisenbank Irrel','38'),(57069806,'VR-Bank Hunsrück-Mosel','38'),(57070024,'Deutsche Bank Privat und Geschäftskunden','63'),(57070045,'Deutsche Bank','63'),(57080070,'Commerzbank vormals Dresdner Bank','76'),(57090000,'Volksbank Koblenz Mittelrhein','64'),(57090900,'PSD Bank Koblenz','91'),(57091000,'Volksbank Montabaur-Höhr-Grenzhausen','06'),(57091100,'Volksbank Höhr-Grenzhausen -alt-','06'),(57092800,'Volksbank Rhein-Lahn-Limburg','06'),(57263015,'Raiffeisenbank Unterwesterwald','38'),(57351030,'Sparkasse Westerwald-Sieg','00'),(57361476,'Volksbank Gebhardshain','38'),(57363243,'Raiffeisenbank Niederfischbach -alt-','38'),(57391200,'Volksbank Daaden','06'),(57391500,'Volksbank Hamm, Sieg','06'),(57391800,'Westerwald Bank','06'),(57450120,'Sparkasse Neuwied','00'),(57460117,'Volks- und Raiffeisenbank Neuwied-Linz','38'),(57461759,'Raiffeisenbank Mittelrhein -alt-','09'),(57470024,'Deutsche Bank Privat und Geschäftskunden','63'),(57470047,'Deutsche Bank','63'),(57650010,'Kreissparkasse Mayen','00'),(57661253,'Raiffeisenbank','38'),(57662263,'VR Bank Rhein-Mosel','38'),(57751310,'Kreissparkasse Ahrweiler','00'),(57761591,'Volksbank RheinAhrEifel','34'),(57762265,'Raiffeisenbank Grafschaft-Wachtberg','38'),(58510111,'SEB','13'),(58520086,'UniCredit Bank - HypoVereinsbank','99'),(58540035,'Commerzbank','13'),(58550130,'Sparkasse Trier','00'),(58560103,'Volksbank Trier','38'),(58560294,'Pax-Bank','06'),(58561250,'Volksbank Hermeskeil -alt-','38'),(58561626,'Volksbank Saarburg -alt-','38'),(58561771,'Raiffeisenbank Mehring-Leiwen','38'),(58564788,'Volksbank Hochwald-Saarburg -alt-','38'),(58570024,'Deutsche Bank Privat und Geschäftskunden','63'),(58570048,'Deutsche Bank','63'),(58580074,'Commerzbank vormals Dresdner Bank','76'),(58590900,'PSD Bank Trier Ndl der PSD Bank Köln','91'),(58650030,'Kreissparkasse Bitburg-Prüm','00'),(58651240,'Kreissparkasse Vulkaneifel','00'),(58660101,'Volksbank Eifel','38'),(58661901,'Raiffeisenbank Westeifel','38'),(58662653,'Raiffeisenbank östl Südeifel -alt-','38'),(58668818,'Raiffeisenbank Neuerburg-Land -alt-','38'),(58691500,'Volksbank Eifel Mitte -alt-','38'),(58751230,'Sparkasse Mittelmosel-Eifel Mosel Hunsrück','00'),(58760954,'Vereinigte Volksbank Raiffeisenbank','38'),(58761343,'Raiffeisenbank Zeller Land','38'),(58771224,'Deutsche Bank Privat und Geschäftskunden','63'),(58771242,'Deutsche Bank','63'),(59000000,'Bundesbank','09'),(59010011,'ZVC Postbank Gf FK 11','09'),(59010012,'ZVC Postbank Gf FK 12','09'),(59010013,'ZVC Postbank Gf FK 13','09'),(59010014,'ZVC Postbank Gf FK 14','09'),(59010015,'ZVC Postbank Gf FK 15','09'),(59010016,'ZVC Postbank Gf FK 16','09'),(59010017,'ZVC Postbank Gf FK 17','09'),(59010018,'ZVC Postbank Gf FK 18','09'),(59010019,'ZVC Postbank Gf FK 19','09'),(59010020,'ZVC Postbank GF FK 20','09'),(59010021,'ZVC Postbank GF FK 21','09'),(59010022,'ZVC Postbank GF FK 22','09'),(59010023,'ZVC Postbank GF FK 23','09'),(59010024,'ZVC Postbank GF FK 24','09'),(59010025,'ZVC Postbank GF FK 25','09'),(59010026,'ZVC Postbank GF FK 26','09'),(59010027,'ZVC Postbank Gf FK 27','09'),(59010028,'ZVC Postbank Gf FK 28','09'),(59010029,'ZVC Postbank Gf FK 29','09'),(59010031,'ZVC Postbank Gf FK 31','09'),(59010032,'ZVC Postbank Gf FK 32','09'),(59010033,'ZVC Postbank Gf FK 33','09'),(59010034,'ZVC Postbank Gf FK 34','09'),(59010035,'ZVC Postbank Gf FK 35','09'),(59010036,'ZVC Postbank Gf FK 36','09'),(59010037,'ZVC Postbank Gf FK 37','09'),(59010038,'ZVC Postbank Gf FK 38','09'),(59010039,'ZVC Postbank Gf FK 39','09'),(59010040,'ZVC Postbank Gf FK 40','09'),(59010041,'ZVC Postbank Gf FK 41','09'),(59010042,'ZVC Postbank Gf FK 42','09'),(59010044,'ZVC Postbank Gf FK 44','09'),(59010045,'ZVC Postbank Gf FK 45','09'),(59010047,'ZVC Postbank Gf FK 47','09'),(59010048,'ZVC Postbank Gf FK 48','09'),(59010049,'ZVC Postbank Gf FK 49','09'),(59010066,'Postbank','24'),(59010111,'SEB','13'),(59010400,'Saarl Investitionskreditbank','32'),(59020090,'UniCredit Bank - HypoVereinsbank','99'),(59040000,'Commerzbank','13'),(59050000,'Landesbank Saar','27'),(59050101,'Sparkasse Saarbrücken','E3'),(59051090,'Stadtsparkasse Völklingen -alt-','21'),(59070000,'Deutsche Bank Saarbruecken','63'),(59070070,'Deutsche Bank Privat und Geschäftskunden','63'),(59080090,'Commerzbank vormals Dresdner Bank','76'),(59090626,'apoBank','A4'),(59090900,'PSD Bank RheinNeckarSaar','91'),(59092000,'Vereinigte Volksbank Dillingen Dudweiler Sulzbach/Saar','06'),(59099550,'Volksbank Nahe-Schaumberg -alt-','06'),(59190000,'Bank 1 Saar','06'),(59190200,'Volksbank Westliche Saar plus','06'),(59251020,'Kreissparkasse St. Wendel','00'),(59252046,'Sparkasse Neunkirchen','C9'),(59291000,'Unsere Volksbank St. Wendeler Land','06'),(59291200,'Volks- und Raiffeisenbank Saarpfalz','06'),(59320087,'UniCredit Bank - HypoVereinsbank','99'),(59350110,'Kreissparkasse Saarlouis','00'),(59351040,'Sparkasse Merzig-Wadern','00'),(59390100,'Volksbank Saarlouis -alt-','06'),(59391200,'Volksbank Überherrn','06'),(59392000,'Volksbank Dillingen -alt-','06'),(59392200,'Volksbank Untere Saar','06'),(59393000,'levoBank','06'),(59450010,'Kreissparkasse Saarpfalz','00'),(59491300,'VR Bank Saarpfalz -alt-','06'),(60000000,'Bundesbank','09'),(60010070,'Postbank','24'),(60010111,'SEB','13'),(60010424,'Aareal Bank','09'),(60010700,'Landeskreditbank Baden-Württemberg Förderbank -alt-','09'),(60020030,'Baden-Württembergische Bank','65'),(60020100,'Schwäbische Bank','09'),(60020290,'UniCredit Bank - HypoVereinsbank','99'),(60020300,'VON ESSEN Bank','09'),(60030000,'Mercedes-Benz Bank','A3'),(60030100,'Bankhaus Bauer, Stuttgart','10'),(60030200,'Bankhaus Ellwanger & Geiger','10'),(60030600,'CreditPlus Bank','09'),(60030666,'CreditPlus Bank','09'),(60030700,'AKTIVBANK','09'),(60030900,'Isbank Fil Stuttgart','06'),(60031000,'TRUMPF Financial Services','00'),(60033000,'Wüstenrot Bausparkasse','09'),(60035810,'IBM Deutschland Kreditbank','06'),(60040060,'Commerzbank CC','09'),(60040061,'Commerzbank CC','09'),(60040071,'Commerzbank','13'),(60050000,'Landesbank Baden-Württemberg','09'),(60050009,'ZV Landesbank Baden-Württemberg ISE','09'),(60050101,'Landesbank Baden-Württemberg/Baden-Württembergische Bank','01'),(60060000,'DZ BANK','09'),(60060202,'DZ PRIVATBANK Ndl. Stuttgart','09'),(60060396,'Volksbank am Württemberg','10'),(60062775,'Echterdinger Bank','10'),(60062909,'Volksbank Strohgäu','10'),(60069017,'Raiffeisenbank Dellmensingen -alt-','10'),(60069066,'Raiffeisenbank Niedere Alb','10'),(60069075,'Raiffeisenbank Bühlertal','10'),(60069147,'Raiffeisenbank Sondelfingen','10'),(60069158,'Raiffeisenbank Steinheim','10'),(60069206,'Raiffeisenbank','10'),(60069224,'Genossenschaftsbank Weil im Schönbuch','10'),(60069235,'Raiffeisenbank Zndl VB Nordschwarzwald -alt-','10'),(60069239,'Bopfinger Bank Sechta-Ries','10'),(60069242,'Raiffeisenbank Gruibingen','10'),(60069245,'Raiffeisenbank Bühlertal','10'),(60069251,'Raiffeisenbank Donau-Iller -alt-','10'),(60069302,'Raiffeisenbank Erlenmoos','10'),(60069303,'Raiffeisenbank Bad Schussenried','10'),(60069308,'Raiffeisenbank -alt-','10'),(60069315,'Volksbank Freiberg und Umgebung -alt-','10'),(60069336,'Raiffeisenbank Maitis','10'),(60069343,'Raiffeisenbank Rißtal -alt-','10'),(60069346,'Raiffeisenbank Ehingen-Hochsträß','10'),(60069350,'Raiffeisenbank Reute-Gaisbeuren','10'),(60069355,'Ehninger Bank','10'),(60069378,'Volksbank Dettenhausen','10'),(60069387,'Dettinger Bank','10'),(60069417,'Raiffeisenbank Kirchheim-Walheim -alt-','10'),(60069419,'Uhlbacher Bank -alt-','10'),(60069420,'Raiffeisenbank Mittelbiberach -alt-','10'),(60069431,'Raiffeisenbank Oberessendorf -alt-','10'),(60069442,'Raiffeisenbank Frankenhardt-Stimpfach','10'),(60069455,'Raiffeisenbank Vordersteinenberg','10'),(60069457,'Raiffeisenbank Ottenbach','10'),(60069461,'Raiffeisenbank Rottumtal','10'),(60069462,'Winterbacher Bank','10'),(60069463,'Raiffeisenbank Geislingen-Rosenfeld','10'),(60069476,'Raiffeisenbank Heidenheimer Alb -alt-','10'),(60069485,'Raiffeisenbank Oberer Wald -alt-','10'),(60069505,'Volksbank Murgtal -alt-','10'),(60069517,'Scharnhauser Bank','10'),(60069527,'Volksbank Brenztal','10'),(60069538,'Löchgauer Bank -alt-','10'),(60069544,'Raiffeisenbank Westhausen','10'),(60069545,'Nufringer Bank -Raiffeisen-','10'),(60069553,'Raiffeisenbank Aichhalden-Hardt-Sulgen','10'),(60069564,'Raiffeisenbank Vordere Alb','10'),(60069595,'Raiffeisenbank Schrozberg-Rot am See','10'),(60069639,'Raiffeisenbank Ingersheim -alt-','10'),(60069648,'Raiffeisenbank -alt-','10'),(60069669,'Erligheimer Bank -alt-','10'),(60069673,'Abtsgmünder Bank -Raiffeisen-','10'),(60069680,'Raiffeisenbank Bretzfeld-Neuenstein','10'),(60069685,'Raiffeisenbank Wangen','10'),(60069705,'Raiffeisenbank Schlat -alt-','10'),(60069706,'Raiffeisenbank','10'),(60069710,'Raiffeisenbank Gammesfeld','09'),(60069714,'Raiffeisenbank Kocher-Jagst','10'),(60069724,'Raiffeisenbank Heroldstatt -alt-','10'),(60069727,'Raiffeisenbank','10'),(60069738,'Volksbank Freiberg und Umgebung -alt-','10'),(60069766,'Volks- und Raiffeisenbank Boll -alt-','10'),(60069795,'Volksbank Freiberg und Umgebung -alt-','10'),(60069798,'Raiffeisenbank Horb','10'),(60069817,'Raiffeisenbank','10'),(60069832,'Raiffeisenbank Urbach','10'),(60069842,'Darmsheimer Bank','10'),(60069858,'Enztalbank -alt-','10'),(60069860,'Federseebank','10'),(60069876,'Raiffeisenbank Oberes Gäu Ergenzingen','10'),(60069896,'Volksbank Freiberg und Umgebung -alt-','10'),(60069904,'VR-Bank Alb -alt-','10'),(60069905,'Volksbank Remseck','10'),(60069911,'Raiffeisenbank','10'),(60069926,'Volksbank Glatten-Wittendorf -alt-','10'),(60069927,'Berkheimer Bank','10'),(60069931,'Raiffeisenbank','10'),(60069950,'Raiffeisenbank Tüngental','10'),(60069976,'Raiffeisenbank Böllingertal','10'),(60069980,'Raiffeisenbank Maselheim-Äpfingen -alt-','10'),(60070024,'Deutsche Bank Privat und Geschäftskunden','63'),(60070070,'Deutsche Bank','63'),(60080000,'Commerzbank vormals Dresdner Bank','76'),(60080055,'Commerzbank vormals Dresdner Bank Zw 55','76'),(60080057,'Commerzbank vormals Dresdner Bank Gf Zw 57','76'),(60080085,'Commerzbank vormals Dresdner Bank ITGK 2','09'),(60080086,'Commerzbank vormals Dresdner Bank Gf PCC-ITGK 3','09'),(60080087,'Commerzbank vormals Dresdner Bank, PCC DC-ITGK 4','09'),(60080088,'Commerzbank vormals Dresdner Bank, PCC DC-ITGK 5','09'),(60089450,'Commerzbank vormals Dresdner Bank ITGK','09'),(60090100,'Volksbank Stuttgart','10'),(60090133,'Volksbank Stuttgart GAA','10'),(60090300,'Volksbank Zuffenhausen m Zndl Stammheimer VB','10'),(60090609,'apoBank','A4'),(60090700,'Südwestbank','10'),(60090800,'Sparda-Bank Baden-Württemberg','87'),(60090900,'PSD Bank RheinNeckarSaar','91'),(60120200,'BHF-BANK','60'),(60120500,'Bank für Sozialwirtschaft','09'),(60130100,'FFS Bank','00'),(60133300,'Santander Consumer Bank','09'),(60241074,'Commerzbank','13'),(60250010,'Kreissparkasse Waiblingen','01'),(60261329,'Fellbacher Bank','10'),(60261622,'VR-Bank Weinstadt -alt-','10'),(60261818,'Raiffeisenbank Weissacher Tal -alt-','10'),(60262063,'Korber Bank -alt-','10'),(60262693,'Kerner Volksbank -alt-','10'),(60270024,'Deutsche Bank Privat und Geschäftskunden','63'),(60270073,'Deutsche Bank','63'),(60290110,'Volksbank Rems -alt-','10'),(60291120,'Volksbank Backnang','10'),(60320291,'UniCredit Bank - HypoVereinsbank','99'),(60340071,'Commerzbank Sindelfingen','13'),(60350130,'Kreissparkasse Böblingen','01'),(60361923,'Raiffeisenbank Weissach','10'),(60380002,'Commerzbank vormals Dresdner Bank','76'),(60390000,'Vereinigte Volksbank','10'),(60390300,'Volksbank Region Leonberg','10'),(60391310,'Volksbank Herrenberg-Nagold-Rottenburg','10'),(60391420,'Volksbank Magstadt','10'),(60410600,'Wüstenrot Bank Pfandbriefbk ehe Wüstenrot Hypo','09'),(60420000,'Wüstenrot Bank Pfandbriefbank','06'),(60420020,'Wüstenrot Bank Pfandbriefbank','06'),(60420021,'Wüstenrot Bank Pfandbriefbank','06'),(60420186,'UniCredit Bank - HypoVereinsbank','99'),(60422000,'RSB Retail+Service Bank','06'),(60440073,'Commerzbank','13'),(60450050,'Kreissparkasse Ludwigsburg','01'),(60460142,'Volksbank Freiberg und Umgebung -alt-','10'),(60462808,'VR-Bank Asperg-Markgröningen','10'),(60470024,'Deutsche Bank Privat und Geschäftskunden','63'),(60470082,'Deutsche Bank','63'),(60480008,'Commerzbank vormals Dresdner Bank','76'),(60490150,'Volksbank Ludwigsburg','10'),(60491430,'VR-Bank Neckar-Enz','10'),(60651070,'Kreissparkasse Calw -alt-','A9'),(60661906,'Raiffeisenbank Wimsheim-Mönsheim','10'),(60663084,'Raiffeisenbank im Kreis Calw','10'),(60670024,'Deutsche Bank Privat- und Geschäftskunden','63'),(60670070,'Deutsche Bank','63'),(61030000,'Bankhaus Gebr. Martin','09'),(61040014,'Commerzbank','13'),(61050000,'Kreissparkasse Göppingen','01'),(61060500,'Volksbank Göppingen','10'),(61070024,'Deutsche Bank Privat und Geschäftskunden','63'),(61070078,'Deutsche Bank','63'),(61080006,'Commerzbank vormals Dresdner Bank','76'),(61091200,'Volksbank-Raiffeisenbank Deggingen','10'),(61120286,'UniCredit Bank - HypoVereinsbank','99'),(61140071,'Commerzbank','13'),(61150020,'Kreissparkasse Esslingen-Nürtingen','01'),(61161696,'Volksbank Filder','10'),(61170024,'Deutsche Bank Privat und Geschäftskunden','63'),(61170076,'Deutsche Bank','63'),(61180004,'Commerzbank vormals Dresdner Bank','76'),(61190110,'Volksbank Esslingen','10'),(61191310,'Volksbank Plochingen','10'),(61240048,'Commerzbank','13'),(61261213,'Raiffeisenbank Teck -alt-','10'),(61261339,'VR Bank Hohenneuffen-Teck','10'),(61262258,'Genossenschaftsbank Wolfschlugen -alt-','10'),(61262345,'Bernhauser Bank','10'),(61281007,'Commerzbank vormals Dresdner Bank','76'),(61290120,'Volksbank Kirchheim-Nürtingen','10'),(61340079,'Commerzbank','13'),(61361722,'Raiffeisenbank Rosenstein','10'),(61361975,'Raiffeisenbank Mutlangen','10'),(61370024,'Deutsche Bank Privat und Geschäftskunden','63'),(61370086,'Deutsche Bank','63'),(61390140,'Volksbank Schwäbisch Gmünd','10'),(61391410,'Volksbank Welzheim','10'),(61420086,'UniCredit Bank - HypoVereinsbank','99'),(61440086,'Commerzbank','13'),(61450050,'Kreissparkasse Ostalb','01'),(61480001,'Commerzbank vormals Dresdner Bank','76'),(61490150,'VR-Bank Aalen','10'),(61491010,'VR-Bank Ellwangen','10'),(62020000,'Hoerner-Bank','16'),(62020100,'FCA Bank Deutschland','09'),(62040060,'Commerzbank','13'),(62050000,'Kreissparkasse Heilbronn','01'),(62061991,'Volksbank Sulmtal','10'),(62062215,'Volksbank Beilstein-Ilsfeld-Abstatt','10'),(62062643,'Volksbank Flein-Talheim','10'),(62063263,'VBU Volksbank im Unterland','10'),(62070024,'Deutsche Bank Privat und Geschäftskunden','63'),(62070081,'Deutsche Bank','63'),(62080012,'Commerzbank vormals Dresdner Bank','76'),(62090100,'Volksbank Heilbronn','10'),(62091400,'Volksbank Brackenheim-Güglingen -alt-','10'),(62091600,'Volksbank Möckmühl-Neuenstadt','10'),(62091800,'Volksbank Hohenlohe','10'),(62220000,'Bausparkasse Schwäbisch Hall','09'),(62240048,'Commerzbank','13'),(62250030,'Sparkasse Schwäbisch Hall-Crailsheim','01'),(62251550,'Sparkasse Hohenlohekreis','01'),(62280012,'Commerzbank vormals Dresdner Bank','76'),(62290110,'VR Bank Schwäbisch Hall-Crailsheim','10'),(62291020,'Crailsheimer Volksbank -alt-','10'),(62391010,'Volksbank Bad Mergentheim -alt-','10'),(62391420,'Volksbank Vorbach-Tauber','10'),(63000000,'Bundesbank','09'),(63010111,'SEB','13'),(63020086,'UniCredit Bank - HypoVereinsbank','99'),(63040053,'Commerzbank','13'),(63050000,'Sparkasse Ulm','01'),(63061486,'VR-Bank Langenau-Ulmer Alb','10'),(63070024,'Deutsche Bank Privat und Geschäftskunden','63'),(63070088,'Deutsche Bank','63'),(63080015,'Commerzbank vormals Dresdner Bank','76'),(63080085,'Commerzbank vormals Dresdner Bank, PCC DCC-ITGK 1','09'),(63090100,'Volksbank Ulm-Biberach','10'),(63091010,'Donau-Iller Bank','10'),(63091200,'Volksbank Blaubeuren','10'),(63091300,'Volksbank Laichinger Alb','10'),(63220090,'UniCredit Bank - HypoVereinsbank','99'),(63240016,'Commerzbank','13'),(63250030,'Kreissparkasse Heidenheim','01'),(63290110,'Heidenheimer Volksbank','10'),(64000000,'Bundesbank','09'),(64020186,'UniCredit Bank - HypoVereinsbank','99'),(64040033,'Commerzbank','13'),(64040045,'Commerzbank','13'),(64050000,'Kreissparkasse Reutlingen','01'),(64061854,'VR Bank Steinlach-Wiesaz-Härten','10'),(64070024,'Deutsche Bank Privat und Geschäftskunden','63'),(64070085,'Deutsche Bank','63'),(64080014,'Commerzbank vormals Dresdner Bank','76'),(64090100,'Volksbank Reutlingen','10'),(64091200,'Volksbank Ermstal-Alb','10'),(64091300,'Volksbank Münsingen','10'),(64140036,'Commerzbank Tübingen','13'),(64150020,'Kreissparkasse Tübingen','01'),(64161397,'Volksbank Ammerbuch','10'),(64161608,'Raiffeisenbank Härten -alt-','10'),(64161956,'Volksbank Mössingen -alt-','10'),(64163225,'Volksbank Hohenzollern-Balingen','10'),(64180014,'Commerzbank vormals Dresdner Bank','76'),(64190110,'Volksbank Tübingen','10'),(64191030,'Volksbank Nagoldtal -alt-','10'),(64191210,'Volksbank Altensteig -alt-','10'),(64191700,'Volksbank Horb -alt-','10'),(64240048,'Commerzbank','13'),(64240071,'Commerzbank','13'),(64250040,'Kreissparkasse Rottweil','01'),(64251060,'Kreissparkasse Freudenstadt','01'),(64261363,'Volksbank Baiersbronn Murgtal','10'),(64261626,'Murgtalbank Mitteltal - Obertal -alt-','10'),(64261853,'Volksbank Nordschwarzwald','10'),(64262408,'Volksbank Dornstetten','10'),(64290120,'Volksbank Rottweil','10'),(64291010,'Volksbank Horb-Freudenstadt','10'),(64291420,'Volksbank Deisslingen','10'),(64292020,'Volksbank Schwarzwald-Neckar -alt-','10'),(64292310,'Volksbank Trossingen','10'),(64350070,'Kreissparkasse Tuttlingen','01'),(64361359,'Raiffeisenbank Donau-Heuberg','10'),(64380011,'Commerzbank vormals Dresdner Bank','76'),(64390130,'Volksbank Schwarzwald-Donau-Neckar','10'),(65020186,'UniCredit Bank - HypoVereinsbank','99'),(65040073,'Commerzbank','13'),(65050110,'Kreissparkasse Ravensburg','01'),(65061219,'Raiffeisenbank Aulendorf','10'),(65062577,'Raiffeisenbank Ravensburg','10'),(65063086,'Raiffeisenbank Bad Saulgau','10'),(65070024,'Deutsche Bank Privat und Geschäftskunden','63'),(65070084,'Deutsche Bank','63'),(65080009,'Commerzbank vormals Dresdner Bank','76'),(65090100,'Volksbank Ulm-Biberach -alt-','10'),(65091040,'Leutkircher Bank Raiffeisen- und Volksbank','10'),(65091300,'Bad Waldseer Bank -alt-','10'),(65091600,'Volksbank Weingarten','10'),(65092010,'Volksbank Allgäu-West','10'),(65092200,'Volksbank Altshausen','10'),(65093020,'Volksbank Bad Saulgau','10'),(65110200,'Internationales Bankhaus Bodensee','71'),(65140072,'Commerzbank','13'),(65161497,'Genossenschaftsbank Meckenbeuren','10'),(65162832,'Raiffeisenbank Oberteuringen','10'),(65180005,'Commerzbank vormals Dresdner Bank','76'),(65190110,'Volksbank Friedrichshafen','10'),(65191500,'Volksbank Tettnang','10'),(65310111,'SEB','13'),(65340004,'Commerzbank','13'),(65341204,'Commerzbank','13'),(65351050,'Hohenz Landesbank Kreissparkasse Sigmaringen','01'),(65351260,'Sparkasse Zollernalb','01'),(65361469,'Volksbank Heuberg','10'),(65361898,'Winterlinger Bank','10'),(65361989,'Onstmettinger Bank','10'),(65362499,'Raiffeisenbank Geislingen-Rosenfeld','10'),(65370024,'Deutsche Bank Privat und Geschäftskunden','63'),(65370075,'Deutsche Bank','63'),(65380003,'Commerzbank vormals Dresdner Bank','76'),(65390120,'Volksbank Albstadt','10'),(65391210,'Volksbank Balingen -alt-','10'),(65392030,'Volksbank Tailfingen -alt-','10'),(65440087,'Commerzbank','13'),(65450070,'Kreissparkasse Biberach','01'),(65461878,'Raiffeisenbank Riss-Umlach','10'),(65462231,'Raiffeisenbank Illertal -alt-','10'),(65491320,'Volksbank Raiffeisenbank Laupheim-Illertal','10'),(65491510,'Volksbank-Raiffeisenbank Riedlingen','10'),(66000000,'Bundesbank','09'),(66010075,'Postbank','24'),(66010111,'SEB','13'),(66010200,'Deutsche Bausparkasse Badenia','09'),(66010700,'Landeskreditbank Baden-Württemberg Förderbank','09'),(66020020,'Baden-Württembergische Bank','65'),(66020286,'UniCredit Bank - HypoVereinsbank','99'),(66020500,'Bank für Sozialwirtschaft','09'),(66020566,'Bank für Sozialwirtschaft','09'),(66030600,'Isbank Fil Karlsruhe','06'),(66040018,'Commerzbank','13'),(66040026,'Commerzbank/Kreditcenter Badenia','13'),(66050000,'Landesbank Baden-Württemberg','09'),(66050101,'Sparkasse Karlsruhe','00'),(66051220,'Sparkasse Ettlingen -alt-','00'),(66060000,'DZ BANK','09'),(66060300,'Spar- und Kreditbank','06'),(66061407,'Spar- und Kreditbank','06'),(66061724,'Volksbank Stutensee-Weingarten','06'),(66062138,'Spar- und Kreditbank Hardt','06'),(66062366,'Raiffeisenbank Hardt-Bruhrain','06'),(66069103,'Raiffeisenbank Elztal','06'),(66069104,'Spar- und Kreditbank','06'),(66069342,'Volksbank Krautheim','06'),(66070004,'Deutsche Bank','63'),(66070024,'Deutsche Bank Privat und Geschäftskunden','63'),(66080052,'Commerzbank vormals Dresdner Bank','76'),(66090621,'apoBank','A4'),(66090800,'BBBank','B3'),(66090900,'PSD Bank Karlsruhe-Neustadt','91'),(66091200,'Volksbank Ettlingen','06'),(66190000,'Volksbank Karlsruhe','06'),(66240002,'Commerzbank','13'),(66250030,'Sparkasse Baden-Baden Gaggenau','00'),(66251434,'Sparkasse Bühl','00'),(66261092,'Spar- und Kreditbank','06'),(66261416,'Raiffeisenbank Altschweier','06'),(66270001,'Deutsche Bank','63'),(66270024,'Deutsche Bank Privat und Geschäftskunden','63'),(66280053,'Commerzbank vormals Dresdner Bank','76'),(66290000,'Volksbank Baden-Baden Rastatt','06'),(66291300,'Volksbank Achern -alt-','06'),(66291400,'Volksbank Bühl','06'),(66340018,'Commerzbank','13'),(66350036,'Sparkasse Kraichgau Bruchsal-Bretten-Sinsheim','03'),(66391200,'Volksbank Bruchsal-Bretten','06'),(66391600,'Volksbank Bruhrain-Kraich-Hardt','06'),(66432700,'Bankhaus J. Faißt','09'),(66440084,'Commerzbank','13'),(66450050,'Sparkasse Offenburg/Ortenau','03'),(66451346,'Sparkasse Gengenbach','03'),(66451548,'Sparkasse Haslach-Zell','03'),(66451862,'Sparkasse Hanauerland','03'),(66452776,'Sparkasse Wolfach','03'),(66470024,'Deutsche Bank Privat und Geschäftskunden','63'),(66470035,'Deutsche Bank','63'),(66490000,'Volksbank in der Ortenau','06'),(66491800,'Volksbank Bühl Fil Kehl','06'),(66492600,'Volksbank Appenweier-Urloffen Appenweier -alt-','06'),(66492700,'Volksbank Mittlerer Schwarzwald','06'),(66550070,'Sparkasse Rastatt-Gernsbach','00'),(66562053,'Raiffeisenbank Südhardt Durmersheim','06'),(66562300,'VR-Bank in Mittelbaden','06'),(66610111,'SEB','13'),(66640035,'Commerzbank','13'),(66650085,'Sparkasse Pforzheim Calw','06'),(66661244,'Raiffeisenbank Bauschlott','06'),(66661329,'Raiffeisenbank Kieselbronn','06'),(66661454,'VR Bank im Enzkreis','42'),(66662155,'Raiffeisenbank Ersingen','06'),(66662220,'Volksbank Stein Eisingen','06'),(66670006,'Deutsche Bank','63'),(66670024,'Deutsche Bank Privat und Geschäftskunden','63'),(66680013,'Commerzbank vormals Dresdner Bank','76'),(66690000,'Volksbank Pforzheim','43'),(66692300,'Volksbank Wilferdingen-Keltern','06'),(66762332,'Raiffeisenbank Kraichgau','06'),(66762433,'Raiffeisenbank Neudenau-Stein-Herbolzheim','06'),(67010111,'SEB','13'),(67020190,'UniCredit Bank - HypoVereinsbank','99'),(67040031,'Commerzbank','13'),(67040060,'Commerzbank CC','09'),(67040061,'Commerzbank CC','09'),(67040085,'Commerzbank, Gf Web-K','13'),(67050505,'Sparkasse Rhein Neckar Nord','06'),(67051203,'Sparkasse Hockenheim','00'),(67060031,'Volksbank Sandhofen','06'),(67070010,'Deutsche Bank','63'),(67070024,'Deutsche Bank Privat und Geschäftskunden','63'),(67080050,'Commerzbank vormals Dresdner Bank','76'),(67080085,'Commerzbank vormals Dresdner Bank, PCC DCC-ITGK 2','09'),(67080086,'Commerzbank vormals Dresdner Bank, PCC DCC-ITGK 3','09'),(67089440,'Commerzbank vormals Dresdner Bank ITGK','09'),(67090000,'VR Bank Rhein-Neckar','06'),(67090617,'apoBank','A4'),(67092300,'Volksbank Weinheim','06'),(67210111,'SEB','13'),(67220286,'UniCredit Bank - HypoVereinsbank','99'),(67230000,'MLP Finanzdienstleistungen','92'),(67230001,'MLP Finanzdienstleistungen Zw CS','92'),(67240039,'Commerzbank','13'),(67250020,'Sparkasse Heidelberg','06'),(67262243,'Raiffeisen Privatbank','06'),(67262550,'Volksbank Rot','06'),(67270003,'Deutsche Bank','63'),(67270024,'Deutsche Bank Privat und Geschäftskunden','63'),(67280051,'Commerzbank vormals Dresdner Bank','76'),(67290000,'Heidelberger Volksbank','06'),(67290100,'Volksbank Kurpfalz','06'),(67291700,'Volksbank Neckartal','06'),(67291900,'Volksbank Kraichgau -alt-','06'),(67292200,'Volksbank Kraichgau Wiesloch-Sinsheim','06'),(67352565,'Sparkasse Tauberfranken','00'),(67362560,'Volksbank Tauber -alt-','06'),(67390000,'Volksbank Main-Tauber','06'),(67450048,'Sparkasse Neckartal-Odenwald','00'),(67460041,'Volksbank Mosbach','06'),(67461424,'Volksbank Franken','06'),(67461733,'Volksbank Kirnau','06'),(67462368,'Volksbank Limbach','06'),(67462480,'Raiffeisenbank Schefflenz-Seckach -alt-','06'),(68000000,'Bundesbank','09'),(68010111,'SEB','13'),(68020186,'UniCredit Bank - HypoVereinsbank','99'),(68030000,'Bankhaus E. Mayer','32'),(68040007,'Commerzbank','13'),(68050101,'Sparkasse Freiburg-Nördlicher Breisgau','01'),(68051004,'Sparkasse Hochschwarzwald','00'),(68051207,'Sparkasse Bonndorf-Stühlingen','00'),(68052230,'Sparkasse St. Blasien','00'),(68052328,'Sparkasse Staufen-Breisach','00'),(68052863,'Sparkasse Schönau-Todtnau -alt-','00'),(68061505,'Volksbank Breisgau-Süd','06'),(68062105,'Raiffeisenbank Denzlingen-Sexau','06'),(68062730,'Raiffeisenbank Wyhl','06'),(68063479,'Raiffeisenbank Kaiserstuhl','06'),(68064222,'Raiffeisenbank','06'),(68070024,'Deutsche Bank Privat und Geschäftskunden','63'),(68070030,'Deutsche Bank','63'),(68080030,'Commerzbank vormals Dresdner Bank','76'),(68080031,'Commerzbank vormals Dresdner Bank Zw Münsterstraße','76'),(68080085,'Commerzbank vormals Dresdner Bank, PCC DCC-ITGK 1','09'),(68080086,'Commerzbank vormals Dresdner Bank, PCC DCC-ITGK 2','09'),(68090000,'Volksbank Freiburg','06'),(68090622,'apoBank','A4'),(68090900,'PSD Bank RheinNeckarSaar','91'),(68091900,'Volksbank Müllheim','06'),(68092000,'Volksbank Breisgau Nord','06'),(68092300,'Volksbank Staufen','06'),(68270024,'Deutsche Bank Privat und Geschäftskunden','63'),(68270033,'Deutsche Bank','63'),(68290000,'Volksbank Lahr','06'),(68310111,'SEB','13'),(68340058,'Commerzbank','13'),(68350048,'Sparkasse Lörrach-Rheinfelden','00'),(68351557,'Sparkasse Wiesental','00'),(68351865,'Sparkasse Markgräflerland','00'),(68370024,'Deutsche Bank Privat und Geschäftskunden','63'),(68370034,'Deutsche Bank','63'),(68390000,'Volksbank Dreiländereck','06'),(68391500,'VR Bank','06'),(68452290,'Sparkasse Hochrhein','00'),(68462427,'Volksbank Klettgau-Wutöschingen','06'),(68490000,'Volksbank Rhein-Wehra','06'),(68492200,'Volksbank Hochrhein','06'),(69010111,'SEB','13'),(69020190,'UniCredit Bank - HypoVereinsbank','99'),(69040045,'Commerzbank','13'),(69050001,'Sparkasse Bodensee','00'),(69051410,'Bezirkssparkasse Reichenau','00'),(69051620,'Sparkasse Pfullendorf-Meßkirch','00'),(69051725,'Sparkasse Salem-Heiligenberg','00'),(69061800,'Volksbank Überlingen','06'),(69070024,'Deutsche Bank Privat und Geschäftskunden','63'),(69070032,'Deutsche Bank','63'),(69091200,'Hagnauer Volksbank','06'),(69091600,'Volksbank Pfullendorf','06'),(69220186,'UniCredit Bank - HypoVereinsbank','99'),(69240075,'Commerzbank','13'),(69250035,'Sparkasse Hegau-Bodensee','00'),(69251445,'Sparkasse Engen-Gottmadingen','00'),(69251755,'Sparkasse Stockach -alt-','00'),(69270024,'Deutsche Bank Privat und Geschäftskunden','63'),(69270038,'Deutsche Bank','63'),(69280035,'Commerzbank vormals Dresdner Bank','76'),(69290000,'Volksbank Hegau -alt-','06'),(69291000,'Volksbank','06'),(69291099,'Volksbank Gf GA','06'),(69362032,'Volksbank Meßkirch Raiffeisenbank','06'),(69400000,'Bundesbank','09'),(69440007,'Commerzbank Villingen u Schwenningen','13'),(69440060,'Commerzbank CC','09'),(69450065,'Sparkasse Schwarzwald-Baar','03'),(69451070,'Sparkasse Donaueschingen -alt-','03'),(69470024,'Deutsche Bank Privat und Geschäftskunden','63'),(69470039,'Deutsche Bank Villingen u Schwenningen','63'),(69490000,'Volksbank Schwarzwald Baar Hegau','06'),(69491700,'Volksbank Triberg -alt-','06'),(70000000,'Bundesbank','09'),(70010080,'Postbank (Giro)','24'),(70010111,'SEB','13'),(70010424,'Aareal Bank','09'),(70010500,'Deutsche Pfandbriefbank','09'),(70010555,'Deutsche Pfandbriefbank - Einlagengeschäfte','01'),(70010570,'Deutsche Pfandbriefbank','09'),(70011100,'Deutsche Kontor Privatbank','06'),(70011110,'Deutsche Kontor Privatbank','06'),(70011200,'Bank Vontobel Europe','17'),(70011300,'Autobank','16'),(70011400,'BfW - Bank für Wohnungswirtschaft','09'),(70011500,'SIEMENS BANK','09'),(70011600,'WEG Bank','06'),(70011700,'Bankhaus von der Heydt','01'),(70011900,'InterCard','10'),(70012000,'UniCredit Family Financing Bank, Ndl der UniCredit','09'),(70012100,'Dero Bank','55'),(70012200,'Bank J. Safra Sarasin (Deutschland)','09'),(70012300,'V-Bank','17'),(70012400,'Die AKTIONÄRSBANK Kulmbach','09'),(70012600,'Südtiroler Sparkasse Niederlassung München','06'),(70013000,'European Bank for Financial Services','67'),(70013010,'European Bank for Financial Services','67'),(70013100,'net-m privatbank 1891','32'),(70013199,'net-m privatbank 1891','32'),(70013400,'IC Cash Services','09'),(70013500,'Bankhaus Herzogpark','06'),(70015000,'transact Elektronische Zahlungssysteme','09'),(70015015,'transact Elektronische Zahlungssysteme','09'),(70015025,'transact Elektronische Zahlungssysteme','09'),(70015035,'transact Elektronische Zahlungssysteme','09'),(70017000,'PayCenter','09'),(70020270,'UniCredit Bank - HypoVereinsbank','95'),(70020300,'Commerz Finanz','09'),(70020500,'Bank für Sozialwirtschaft','09'),(70020570,'Bank für Sozialwirtschaft','09'),(70020800,'INTESA SANPAOLO','09'),(70021180,'UniCredit Bank - HypoVereinsbank','99'),(70022200,'Fidor Bank','16'),(70025175,'UniCredit Bank - HypoVereinsbank','99'),(70030014,'Fürst Fugger Privatbank','00'),(70030111,'Bankhaus Max Flessa','09'),(70030300,'Bankhaus Reuschel & Co -alt-','09'),(70030400,'Merck Finck Privatbankiers','10'),(70031000,'Bankhaus Ludwig Sperrer','00'),(70032500,'St. Galler Kantonalbank Deutschland','09'),(70033100,'Baader Bank','09'),(70035000,'Oldenburgische Landesbank','61'),(70040041,'Commerzbank','13'),(70040045,'Commerzbank, Filiale München 2','13'),(70040048,'Commerzbank GF-M48','13'),(70040060,'Commerzbank Gf 860','09'),(70040061,'Commerzbank Gf 861','09'),(70040062,'Commerzbank CC','09'),(70040063,'Commerzbank CC','09'),(70040070,'Commerzbank, CC SP','09'),(70045050,'Commerzbank Service-BZ','13'),(70050000,'Bayerische Landesbank','09'),(70051003,'Sparkasse Freising','00'),(70051540,'Sparkasse Dachau','00'),(70051805,'Kreissparkasse München Starnberg Ebersberg -alt-','00'),(70051995,'Kreis- und Stadtsparkasse Erding-Dorfen','00'),(70052060,'Sparkasse Landsberg-Dießen','00'),(70053070,'Sparkasse Fürstenfeldbruck','00'),(70054306,'Sparkasse Bad Tölz-Wolfratshausen','00'),(70070010,'Deutsche Bank','63'),(70070024,'Deutsche Bank Privat und Geschäftskunden','63'),(70080000,'Commerzbank vormals Dresdner Bank','76'),(70080056,'Commerzbank vormals Dresdner Bank Zw 56','76'),(70080057,'Commerzbank vormals Dresdner Bank Gf ZW 57','76'),(70080085,'Commerzbank vormals Dresdner Bank Gf PCC DCC-ITGK 3','09'),(70080086,'Commerzbank vormals Dresdner Bank, PCC DCC-ITGK 4','09'),(70080087,'Commerzbank vormals Dresdner Bank, PCC DCC-ITGK 5','09'),(70080088,'Commerzbank vormals Dresdner Bank, PCC DCC-ITGK 6','09'),(70089470,'Commerzbank vormals Dresdner Bank ITGK','09'),(70089472,'Commerzbank vormals Dresdner Bank ITGK','09'),(70090100,'Hausbank München','88'),(70090124,'Hausbank München','10'),(70090500,'Sparda-Bank München','81'),(70090606,'apoBank','A4'),(70091500,'Volksbank Raiffeisenbank Dachau','88'),(70091600,'VR-Bank Landsberg-Ammersee','88'),(70091900,'VR-Bank Erding','88'),(70093200,'Volksbank Raiffeisenbank Starnberg-Herrsching-Landsberg','88'),(70093400,'VR-Bank Ismaning Hallbergmoos Neufahrn','88'),(70110088,'Postbank (Spar)','09'),(70110500,'Münchener Hypothekenbank','09'),(70110600,'UBI BANCA Niederlassung München','09'),(70120100,'State Street Bank International','09'),(70120400,'BNP Paribas Niederlassung Deutschland','00'),(70120500,'CACEIS Bank, Germany Branch','D2'),(70120600,'Airbus Group Bank','30'),(70120700,'Oberbank Ndl Deutschland','00'),(70130700,'Bankhaus August Lenz & Co','09'),(70130799,'Bankhaus August Lenz & Co Gf GAA','09'),(70130800,'Merkur Bank','88'),(70133300,'Santander Consumer Bank','09'),(70150000,'Stadtsparkasse München','00'),(70160000,'DZ BANK','09'),(70160300,'Raiffeisenbank München -alt-','88'),(70163370,'Volksbank Raiffeisenbank Fürstenfeldbruck','88'),(70166486,'VR Bank München Land','88'),(70169132,'Raiffeisenbank Griesstätt-Halfing','88'),(70169165,'Raiffeisenbank Chiemgau-Nord - Obing','88'),(70169168,'VR-Bank Chiemgau-Süd -alt-','88'),(70169186,'Raiffeisenbank Pfaffenhofen a d Glonn','88'),(70169190,'Raiffeisenbank Tattenh-Großkarolinenf','88'),(70169191,'Raiffeisenbank Rupertiwinkel','88'),(70169195,'Raiffeisenbank Trostberg-Traunreut','88'),(70169310,'Alxing-Brucker Genossenschaftsbank','88'),(70169331,'Raiffeisenbank südöstl. Starnberger See -alt-','88'),(70169333,'Raiffeisenbank Beuerberg-Eurasburg','88'),(70169351,'Raiffeisenbank Nordkreis Landsberg','88'),(70169356,'Raiffeisenbank Erding','88'),(70169382,'Raiffeisenbank','88'),(70169383,'Raiffeisenbank Gmund am Tegernsee','88'),(70169388,'Raiffeisenbank Haag-Gars-Maitenbeth','88'),(70169402,'Raiffeisenbank Höhenkirchen und Umgebung','88'),(70169410,'Raiffeisenbank Holzkirchen-Otterfing','88'),(70169413,'Raiffeisenbank Singoldtal','88'),(70169450,'Raiffeisen-Volksbank Ebersberg','88'),(70169459,'Raiffeisenbank','88'),(70169460,'Raiffeisenbank Westkreis Fürstenfeldbruck','88'),(70169464,'Genossenschaftsbank München','88'),(70169465,'Raiffeisenbank München-Nord','88'),(70169466,'Raiffeisenbank München-Süd','88'),(70169470,'Raiffeisenbank München-Süd Gf GA','88'),(70169474,'Raiffbk Neumarkt-St. Veit - Niederbergkirchen -alt-','88'),(70169476,'Raiffeisenbank -alt-','88'),(70169493,'Raiffeisenbank Oberschleißheim -alt-','88'),(70169509,'Raiffeisenbank Pfaffenwinkel','88'),(70169521,'Raiffeisenbank Raisting','88'),(70169524,'Raiffeisenbank RSA','88'),(70169530,'Raiffeisenbank Neumarkt-St. Veit - Reischach','88'),(70169538,'Raiffeisenbank St. Wolfgang-Schwindkirchen','88'),(70169541,'Raiffeisenbank Lech-Ammersee -alt-','88'),(70169543,'Raiffeisenbank Isar-Loisachtal','88'),(70169558,'Raiffeisenbank','88'),(70169566,'VR-Bank Taufkirchen-Dorfen','88'),(70169568,'Raiffeisenbank Taufkirchen-Oberneukirchen','88'),(70169571,'Raiffeisenbank Tölzer Land','88'),(70169575,'Raiffeisenbank','88'),(70169576,'Raiffeisen-Volksbank Tüßling-Unterneukirchen','88'),(70169585,'Raiffeisenbank Unterschleißheim-Haimhn -alt-','88'),(70169598,'Raiffeisenbank im Oberland','88'),(70169599,'Raiffeisenbank Weil u Umgebung -alt-','88'),(70169602,'Raiffeisenbank Weilheim -alt-','88'),(70169605,'Raiffeisen-Volksbank Isen-Sempt','88'),(70169614,'Freisinger Bank Volksbank-Raiffeisenbank','88'),(70169619,'Raiffeisenbank Zorneding','88'),(70169653,'Raiffeisenbank Aiglsbach','88'),(70169693,'Raiffeisenbank Hallertau','88'),(70190000,'Münchner Bank','88'),(70220000,'LfA Förderbank Bayern','09'),(70220200,'BHF-BANK','60'),(70220300,'BMW Bank','09'),(70220800,'Vereinsbank Victoria Bauspar','07'),(70220900,'Wüstenrot Bausparkasse','61'),(70230600,'Isbank Fil München','06'),(70250150,'Kreissparkasse München Starnberg Ebersberg','00'),(70320090,'UniCredit Bank - HypoVereinsbank','99'),(70321194,'UniCredit Bank - HypoVereinsbank','99'),(70322192,'UniCredit Bank - HypoVereinsbank','99'),(70350000,'Kreissparkasse Garmisch-Partenkirchen','00'),(70351030,'Sparkasse Oberland','00'),(70362595,'Raiffeisenbank Wallgau-Krün','88'),(70380006,'Commerzbank vormals Dresdner Bank','76'),(70390000,'VR-Bank Werdenfels','88'),(70390010,'VR-Bank Werdenfels','88'),(70391800,'Volksbank-Raiffeisenbank Penzberg -alt-','88'),(71020072,'UniCredit Bank - HypoVereinsbank','99'),(71021270,'UniCredit Bank - HypoVereinsbank','99'),(71022182,'UniCredit Bank - HypoVereinsbank','99'),(71023173,'UniCredit Bank - HypoVereinsbank','99'),(71050000,'Sparkasse Berchtesgadener Land','00'),(71051010,'Kreissparkasse Altötting-Burghausen -alt-','00'),(71052050,'Kreissparkasse Traunstein-Trostberg','00'),(71061009,'VR meine Raiffeisenbank','88'),(71062802,'Raiffeisenbank','88'),(71090000,'Volksbank Raiffeisenbank Oberbayern Südost','88'),(71120077,'UniCredit Bank - HypoVereinsbank','99'),(71120078,'UniCredit Bank - HypoVereinsbank','99'),(71121176,'UniCredit Bank - HypoVereinsbank','99'),(71122183,'UniCredit Bank - HypoVereinsbank','99'),(71140041,'Commerzbank Rosenheim','13'),(71141041,'Commerzbank','13'),(71142041,'Commerzbank','13'),(71150000,'Sparkasse Rosenheim-Bad Aibling','00'),(71151020,'Sparkasse Altötting-Mühldorf','00'),(71152570,'Kreissparkasse Miesbach-Tegernsee','00'),(71152680,'Kreis- und Stadtsparkasse Wasserburg','00'),(71160000,'Volksbank Raiffeisenbank Rosenheim-Chiemsee','88'),(71160161,'VR Bank Rosenheim-Chiemsee -alt-','88'),(71161964,'Volksbank-Raiffeisenbank Chiemsee -alt-','88'),(71162355,'Raiffeisenbank Oberaudorf','88'),(71162804,'Raiffeisenbank Aschau-Samerberg','88'),(71165150,'Raiffeisenbank Mangfalltal -alt-','88'),(71180005,'Commerzbank vormals Dresdner Bank','76'),(71190000,'Volksbank Rosenheim -alt-','88'),(71191000,'VR-Bank Burghausen-Mühldorf -alt-','88'),(72000000,'Bundesbank','09'),(72010111,'SEB','13'),(72012300,'Bank für Tirol und Vorarlberg Deutschland','26'),(72020070,'UniCredit Bank - HypoVereinsbank','99'),(72020700,'Augsburger Aktienbank','23'),(72021271,'UniCredit Bank - HypoVereinsbank','99'),(72021876,'UniCredit Bank - HypoVereinsbank','99'),(72030014,'Fürst Fugger Privatbank','00'),(72030227,'Bankhaus Anton Hafner','00'),(72030260,'Bankhaus Anton Hafner (Gf PayCenter)','09'),(72040046,'Commerzbank','13'),(72050000,'Stadtsparkasse Augsburg','00'),(72050101,'Kreissparkasse Augsburg','00'),(72051210,'Sparkasse Aichach-Schrobenhausen','00'),(72051840,'Sparkasse Günzburg-Krumbach','00'),(72062152,'VR-Bank Handels- und Gewerbebank','88'),(72069002,'Raiffeisenbank Adelzhausen-Sielenbach','88'),(72069005,'Raiffeisenbank','88'),(72069034,'Raiffeisenbank Bissingen','88'),(72069036,'Raiffeisenbank','88'),(72069043,'VR-Bank Donau-Mindel','88'),(72069105,'Raiffeisenbank','88'),(72069113,'Raiffeisenbank Aschberg','88'),(72069114,'Raiffeisenbank','88'),(72069119,'Raiffeisenbank Ichenhausen','88'),(72069123,'Raiffeisenbank Jettingen-Scheppach','88'),(72069126,'Raiffeisenbank Mittelschwaben','88'),(72069132,'Raiffeisenbank Krumbach/Schwaben','88'),(72069135,'Raiffeisenbank Stauden','88'),(72069155,'Raiffeisenbank Kissing-Mering','88'),(72069179,'Raiffeisenbank Unteres Zusamtal','88'),(72069181,'Raiffeisenbank -alt-','88'),(72069193,'Raiffeisenbank','88'),(72069209,'Raiffeisenbank -alt-','88'),(72069220,'Raiffeisenbank','88'),(72069235,'Raiffeisenbank','88'),(72069263,'Raiffeisenbank Wittislingen','88'),(72069274,'Raiffeisenbank Augsburger Land West','88'),(72069308,'Raiffeisen-Volksbank Wemding','88'),(72069329,'Raiffeisen-Volksbank Ries','88'),(72069736,'Raiffeisenbank Iller-Roth-Günz','88'),(72069789,'Raiffeisenbank Pfaffenhausen','88'),(72070001,'Deutsche Bank','63'),(72070024,'Deutsche Bank Privat und Geschäftskunden','63'),(72080001,'Commerzbank vormals Dresdner Bank','76'),(72090000,'Augusta-Bank Raiffeisen-Volksbank','88'),(72090500,'Sparda-Bank Augsburg','84'),(72090900,'PSD Bank München','91'),(72091800,'Volksbank Günzburg -alt-','10'),(72120078,'UniCredit Bank - HypoVereinsbank','99'),(72122181,'UniCredit Bank - HypoVereinsbank','99'),(72140052,'Commerzbank','13'),(72150000,'Sparkasse Ingolstadt Eichstätt','00'),(72151340,'Sparkasse Eichstätt -alt-','00'),(72151650,'Sparkasse Pfaffenhofen','00'),(72151880,'Sparkasse Aichach-Schrobenhausen -alt-','00'),(72152070,'Sparkasse Neuburg-Rain','00'),(72160818,'Volksbank Raiffeisenbank Bayern Mitte','88'),(72169013,'Raiffeisenbank Aresing-Hörzhausen-Schiltberg -alt-','88'),(72169080,'Raiffeisenbank Aresing-Gerolsbach','88'),(72169111,'Raiffeisenbank Hohenwart -alt-','88'),(72169218,'Schrobenhausener Bank','88'),(72169246,'Raiffeisenbank Schrobenhausener Land','88'),(72169380,'Raiffeisenbank Beilngries','88'),(72169745,'Raiffeisenbank Ehekirchen-Oberhausen','88'),(72169756,'VR Bank Neuburg-Rain','88'),(72169764,'Raiffeisenbank Donaumooser Land','88'),(72169812,'Raiffeisenbank Gaimersheim-Buxheim','88'),(72169831,'Raiffeisenbank Riedenburg-Lobsing','88'),(72170007,'Deutsche Bank','63'),(72170024,'Deutsche Bank Privat und Geschäftskunden','63'),(72180002,'Commerzbank vormals Dresdner Bank','76'),(72191300,'Volksbank Raiffeisenbank Eichstätt -alt-','88'),(72191600,'Hallertauer Volksbank','88'),(72220074,'UniCredit Bank - HypoVereinsbank','99'),(72223182,'UniCredit Bank - HypoVereinsbank','99'),(72250000,'Sparkasse Nördlingen','00'),(72250160,'Sparkasse Donauwörth','00'),(72251520,'Kreis- und Stadtsparkasse Dillingen','10'),(72261754,'Raiffeisenbank Rain am Lech -alt-','88'),(72262401,'Raiffeisen-Volksbank Dillingen -alt-','88'),(72290100,'Raiffeisen-Volksbank Donauwörth','88'),(73050000,'Sparkasse Neu-Ulm-Illertissen','00'),(73061191,'VR-Bank Neu-Ulm','88'),(73090000,'Volksbank Neu-Ulm -alt-','88'),(73120075,'UniCredit Bank - HypoVereinsbank','99'),(73140046,'Commerzbank Memmingen','13'),(73150000,'Sparkasse Memmingen-Lindau-Mindelheim','00'),(73160000,'Genossenschaftsbank Unterallgäu','88'),(73180011,'Commerzbank vormals Dresdner Bank','76'),(73190000,'VR-Bank Memmingen','88'),(73191500,'Volksbank Ulm-Biberach -alt-','10'),(73311600,'Vorarlberger Landes- und Hypothekenbank','09'),(73320073,'UniCredit Bank - HypoVereinsbank','99'),(73321177,'UniCredit Bank - HypoVereinsbank','99'),(73322380,'UniCredit Bank - HypoVereinsbank','99'),(73331700,'Gabler-Saliter Bankgeschäft','09'),(73340046,'Commerzbank Kempten Allgäu','13'),(73350000,'Sparkasse Allgäu','00'),(73351635,'Sparkasse Riezlern, Kleinwalsertal','00'),(73369264,'Raiffeisenbank im Allgäuer Land','88'),(73369821,'BodenseeBank','88'),(73369823,'Raiffeisenbank Westallgäu','88'),(73369826,'Volksbank','88'),(73369851,'Raiffeisenbank Aitrang-Ruderatshofen','88'),(73369854,'Raiffeisenbank Fuchstal-Denklingen','88'),(73369859,'Raiffeisenbank','88'),(73369871,'Raiffeisenbank Baisweil-Eggenthal-Friesenried','88'),(73369878,'Raiffeisenbank Füssen-Pfronten-Nesselwang -alt-','88'),(73369881,'Raiffeisenbank Haldenwang -alt-','88'),(73369902,'Raiffeisenbank Kempten -alt-','88'),(73369918,'Raiffeisenbank Kirchweihtal','88'),(73369920,'Raiffeisenbank Kempten-Oberallgäu','88'),(73369933,'Raiffeisenbank Südliches Ostallgäu','88'),(73369936,'Raiffeisenbank Seeg -alt-','88'),(73369954,'Raiffeisenbank Wald-Görisried','88'),(73370008,'Deutsche Bank','63'),(73370024,'Deutsche Bank Privat und Geschäftskunden','63'),(73380004,'Commerzbank vormals Dresdner Bank','76'),(73390000,'Allgäuer Volksbank Kempten-Sonthofen','88'),(73392000,'Volksbank Immenstadt','88'),(73420071,'UniCredit Bank - HypoVereinsbank','99'),(73421478,'UniCredit Bank - HypoVereinsbank','99'),(73440048,'Commerzbank','13'),(73450000,'Kreis- und Stadtsparkasse Kaufbeuren','00'),(73451450,'Kreissparkasse Schongau -alt-','00'),(73460046,'VR Bank Kaufbeuren-Ostallgäu','88'),(73480013,'Commerzbank vormals Dresdner Bank','76'),(74020074,'UniCredit Bank - HypoVereinsbank','99'),(74020100,'Raiffeisenlandesbank OÖ Zndl Süddeutschland','60'),(74020150,'Raiffeisenlandesbank OÖ Zndl Südde - für interne Zwecke','60'),(74040082,'Commerzbank Passau','13'),(74050000,'Sparkasse Passau','00'),(74051230,'Sparkasse Freyung-Grafenau','00'),(74061101,'Raiffeisenbank Am Goldenen Steig','88'),(74061564,'Raiffeisenbank Unteres Inntal','88'),(74061670,'Raiffeisenbank Ortenburg-Kirchberg','88'),(74061813,'VR-Bank Rottal-Inn','88'),(74061814,'VR-Bank Rottal-Inn','88'),(74062490,'Raiffeisenbank Vilshofener Land','88'),(74062786,'Raiffeisenbank i Lkr Passau-Nord','88'),(74064593,'Raiffeisenbank','88'),(74065782,'Raiffeisenbank Salzweg-Thyrnau -alt-','88'),(74066749,'Raiffeisenbank Südl. Bayerischer Wald','88'),(74067000,'Rottaler Raiffeisenbank','88'),(74069744,'Raiffeisenbank','88'),(74069752,'Raiffeisenbank Hohenau-Mauth -alt-','88'),(74069758,'Raiffeisenbank Kirchberg v. Wald','88'),(74069768,'Raiffeisenbank am Dreisessel','88'),(74090000,'VR-Bank Passau','88'),(74092400,'Volksbank Vilshofen','88'),(74120071,'UniCredit Bank - HypoVereinsbank','99'),(74131000,'TEBA Kreditbank','09'),(74140048,'Commerzbank','13'),(74150000,'Sparkasse Deggendorf','00'),(74151450,'Sparkasse Regen-Viechtach','00'),(74160025,'Raiffeisenbank Deggendorf-Plattling','88'),(74161608,'Raiffeisenbank Hengersberg-Schöllnach','88'),(74164149,'VR-Bank -alt-','88'),(74165013,'Raiffeisenbank Sonnenwald','88'),(74180009,'Commerzbank vormals Dresdner Bank','76'),(74190000,'VR GenoBank DonauWald','88'),(74191000,'VR-Bank Landau','88'),(74220075,'UniCredit Bank - HypoVereinsbank','99'),(74221170,'UniCredit Bank - HypoVereinsbank','99'),(74240062,'Commerzbank Straubing','13'),(74250000,'Sparkasse Niederbayern-Mitte','00'),(74251020,'Sparkasse im Landkreis Cham','00'),(74260110,'Raiffeisenbank','88'),(74261024,'Raiffeisenbank Chamer Land','88'),(74290000,'Volksbank Straubing','88'),(74290100,'CB Bank','98'),(74320073,'UniCredit Bank - HypoVereinsbank','99'),(74340077,'Commerzbank','13'),(74350000,'Sparkasse Landshut','11'),(74351310,'Sparkasse Dingolfing-Landau -alt-','00'),(74351430,'Sparkasse Rottal-Inn','00'),(74351740,'Stadt- und Kreissparkasse Moosburg','10'),(74361211,'Raiffeisenbank Arnstorf','88'),(74362663,'Raiffeisenbank Altdorf-Ergolding','88'),(74364689,'Raiffeisenbank Pfeffenhausen-Rottenburg-Wildenberg','88'),(74366666,'Raiffeisenbank Geisenhausen','88'),(74369068,'Raiffeisenbank Hofkirchen-Bayerbach','88'),(74369088,'Raiffeisenbank Geiselhöring-Pfaffenberg','88'),(74369130,'Raiffeisenbank Parkstetten','88'),(74369146,'Raiffeisenbank Rattiszell-Konzell','88'),(74369656,'Raiffeisenbank Essenbach','88'),(74369662,'Raiffeisenbank Buch-Eching','88'),(74369704,'Raiffeisenbank Mengkofen-Loiching','88'),(74369709,'Raiffeisenbank Wildenberg -alt-','88'),(74380007,'Commerzbank vormals Dresdner Bank','76'),(74390000,'VR-Bank Landshut','88'),(74391300,'Volksbank-Raiffeisenbank Dingolfing','88'),(74391400,'VR-Bank Rottal-Inn','88'),(74392300,'VR-Bank Vilsbiburg','88'),(75000000,'Bundesbank','09'),(75010111,'SEB','13'),(75020073,'UniCredit Bank - HypoVereinsbank','99'),(75021174,'UniCredit Bank - HypoVereinsbank','99'),(75040062,'Commerzbank Regensburg','13'),(75050000,'Sparkasse Regensburg','00'),(75051040,'Sparkasse im Landkreis Schwandorf','00'),(75051565,'Kreissparkasse Kelheim','00'),(75060150,'Raiffeisenbank Regensburg-Wenzenbach','88'),(75061168,'Raiffeisenbank Schwandorf-Nittenau','88'),(75061851,'Raiffeisenbank Regenstauf','88'),(75062026,'Raiffeisenbank Oberpfalz Süd','88'),(75069014,'Raiffeisenbank Bad Abbach-Saal','88'),(75069015,'Raiffeisenbank Bad Gögging','88'),(75069020,'Raiffeisenbank Bruck','88'),(75069038,'Raiffeisenbank Falkenstein-Wörth','88'),(75069050,'Raiffeisenbank Grafenwöhr-Kirchenthumbach','88'),(75069055,'Raiffeisenbank Alteglofsheim-Hagelstadt','88'),(75069061,'Raiffeisenbank Hemau-Kallmünz','88'),(75069062,'Raiffeisenbank Herrnwahlthann-Teugn-Dünzling -alt-','88'),(75069078,'Raiffeisenbank','88'),(75069081,'Raiffeisenbank Bad Kötzting','88'),(75069094,'Raiffeisenbank Parsberg-Velburg','88'),(75069110,'Raiffeisenbank Eschlkam-Lam-Lohberg-Neukirchen b Hl Blut','88'),(75069171,'Raiffeisenbank im Naabtal','88'),(75070013,'Deutsche Bank','63'),(75070024,'Deutsche Bank Privat und Geschäftskunden','63'),(75080003,'Commerzbank vormals Dresdner Bank','76'),(75090000,'Volksbank Regensburg','88'),(75090300,'LIGA Bank','88'),(75090500,'Sparda-Bank Ostbayern','84'),(75090629,'apoBank','A4'),(75090900,'PSD Bank Niederbayern-Oberpfalz','91'),(75091400,'VR Bank Burglengenfeld','88'),(75220070,'UniCredit Bank - HypoVereinsbank','99'),(75240000,'Commerzbank','13'),(75250000,'Sparkasse Amberg-Sulzbach','00'),(75261700,'Raiffeisenbank Sulzbach-Rosenberg','88'),(75290000,'Volksbank-Raiffeisenbank Amberg','88'),(75320075,'UniCredit Bank - HypoVereinsbank','99'),(75340090,'Commerzbank','13'),(75350000,'Sparkasse Oberpfalz Nord','00'),(75351960,'Vereinigte Sparkassen Eschenbach i d Opf','00'),(75360011,'Raiffeisenbank Weiden','88'),(75362039,'Raiffeisenbank','88'),(75363189,'Raiffeisenbank Neustadt-Vohenstrauß','88'),(75390000,'Volksbank Nordoberpfalz','88'),(76000000,'Bundesbank','09'),(76010085,'Postbank','24'),(76010111,'SEB','13'),(76020070,'UniCredit Bank - HypoVereinsbank','99'),(76020099,'UniCredit Bank - HypoVereinsbank Prepaid Card','09'),(76026000,'norisbank','C7'),(76030080,'BNP Paribas Niederlassung Deutschland','01'),(76030600,'Isbank Fil Nürnberg','06'),(76030800,'BIW Bank für Investments und Wertpapiere','01'),(76032000,'TeamBank Nürnberg','06'),(76032001,'TeamBank Nürnberg GF Austria','06'),(76035000,'UmweltBank','55'),(76040060,'Commerzbank CC','09'),(76040061,'Commerzbank','13'),(76040062,'Commerzbank CC','09'),(76040065,'Commerzbank, Filiale Nürnberg 2','13'),(76050000,'Bayerische Landesbank','09'),(76050101,'Sparkasse Nürnberg','49'),(76052080,'Sparkasse Neumarkt i d OPf-Parsberg','00'),(76060000,'DZ BANK','09'),(76060618,'Volksbank Raiffeisenbank','88'),(76061025,'Raiffeisen Spar+Kreditbank Lauf a d Pegnitz','88'),(76061482,'Raiffeisenbank Hersbruck','88'),(76069369,'Raiffeisenbank Auerbach-Freihung','88'),(76069372,'Raiffeisenbank Bad Windsheim','88'),(76069378,'Raiffeisenbank','88'),(76069404,'Raiffeisenbank Uehlfeld-Dachsbach','88'),(76069409,'Raiffeisenbank Dietenhofen -alt-','88'),(76069410,'Raiffeisenbank Dietersheim und Umgebung','88'),(76069440,'Raiffeisenbank Altdorf-Feucht','88'),(76069441,'VR-Bank Feuchtwangen-Limes','88'),(76069448,'Raiffeisenbank -alt-','88'),(76069449,'Raiffeisenbank Berching-Freystadt-Mühlhausen','88'),(76069462,'Raiffeisenbank Greding - Thalmässing','88'),(76069468,'Raiffeisenbank Weißenburg-Gunzenhausen','88'),(76069486,'Raiffeisenbank Hirschau','88'),(76069512,'Raiffeisenbank Knoblauchsland Nürnberg-Buch','88'),(76069549,'Raiffeisenbank Münchaurach -alt-','88'),(76069552,'Raiffeisenbank -alt-','88'),(76069553,'Raiffeisenbank Neumarkt','88'),(76069559,'VR meine Bank','88'),(76069564,'Raiffeisenbank Oberferrieden-Burgthann','88'),(76069576,'Raiffeisenbank Plankstetten','88'),(76069598,'Raiffeisenbank Großhabersdorf-Roßtal -alt-','88'),(76069601,'VR-Bank Rothenburg -alt-','88'),(76069602,'Raiffeisenbank Seebachgrund','88'),(76069611,'Raiffeisenbank Unteres Vilstal','88'),(76069635,'Raiffeisenbank Ursensollen-Ammerthal-Hohenburg -alt-','88'),(76069663,'Raiffeisenbank Heilsbronn-Windsbach','88'),(76069669,'Raiffeisenbank Bibertgrund','88'),(76070012,'Deutsche Bank','63'),(76070024,'Deutsche Bank Privat und Geschäftskunden','63'),(76080040,'Commerzbank vormals Dresdner Bank','76'),(76080053,'Commerzbank vormals Dresdner Bank Zw 53','76'),(76080055,'Commerzbank vormals Dresdner Bank Zw 55','09'),(76080085,'Commerzbank vormals Dresdner Bank, PCC DCC-ITGK 1','09'),(76080086,'Commerzbank vormals Dresdner Bank, PCC DCC-ITGK 2','09'),(76089480,'Commerzbank vormals Dresdner Bank ITGK','09'),(76089482,'Commerzbank vormals Dresdner Bank ITGK','09'),(76090400,'Evenord-Bank','88'),(76090500,'Sparda-Bank Nürnberg','81'),(76090613,'apoBank','A4'),(76090900,'PSD Bank','91'),(76211900,'CVW - Privatbank','88'),(76220073,'UniCredit Bank - HypoVereinsbank','99'),(76230000,'BSQ Bauspar','11'),(76240011,'Commerzbank Fürth Bayern','13'),(76250000,'Sparkasse Fürth','00'),(76251020,'Sparkasse i Landkreis Neustadt a d Aisch','00'),(76260451,'Raiffeisen-Volksbank Fürth -alt-','88'),(76320072,'UniCredit Bank - HypoVereinsbank','99'),(76330111,'Bankhaus Max Flessa','09'),(76340061,'Commerzbank Erlangen','13'),(76350000,'Stadt- und Kreissparkasse Erlangen','01'),(76351040,'Sparkasse Forchheim','00'),(76351560,'Kreissparkasse Höchstadt','00'),(76360033,'VR-Bank Erlangen-Höchstadt-Herzogenaurach','88'),(76391000,'Volksbank Forchheim','88'),(76420080,'UniCredit Bank - HypoVereinsbank','99'),(76450000,'Sparkasse Mittelfranken-Süd','A5'),(76460015,'Raiffeisenbank Roth-Schwabach','88'),(76461485,'Raiffeisenbank am Rothsee','88'),(76520071,'UniCredit Bank - HypoVereinsbank','99'),(76550000,'Sparkasse Ansbach','00'),(76551020,'Kreis- und Stadtsparkasse Dinkelsbühl','00'),(76551540,'Vereinigte Sparkassen Gunzenhausen','00'),(76551860,'Stadt- und Kreissparkasse Rothenburg','00'),(76560060,'VR-Bank Mittelfranken West','88'),(76561979,'Raiffeisenbank -alt-','88'),(76591000,'VR Bank Dinkelsbühl','88'),(77020070,'UniCredit Bank - HypoVereinsbank','99'),(77030111,'Bankhaus Max Flessa','09'),(77040080,'Commerzbank Bamberg','13'),(77050000,'Sparkasse Bamberg','00'),(77060100,'VR Bank Bamberg Raiffeisen-Volksbank','88'),(77061004,'Raiffeisenbank Obermain Nord','88'),(77061425,'Raiffeisen-Volksbank','88'),(77062014,'Raiffeisenbank Burgebrach-Stegaurach','88'),(77062139,'Raiffeisen-Volksbank Bad Staffelstein','88'),(77065141,'Raiffeisenbank Stegaurach -alt-','88'),(77069042,'Raiffeisenbank Gößweinstein -alt-','88'),(77069044,'Raiffeisenbank Küps-Mitwitz-Stockheim','88'),(77069051,'Raiffeisenbank','88'),(77069052,'Raiffeisenbank','88'),(77069091,'Raiffeisenbank Ebrachgrund','88'),(77069110,'Raiffeisenbank Pretzfeld -alt-','88'),(77069461,'Vereinigte Raiffeisenbanken','88'),(77069556,'VR-Bank Erlangen-Höchstadt-Herzogenaurach','88'),(77069739,'Raiffeisenbank Thurnauer Land','88'),(77069746,'Raiffeisenbank','88'),(77069764,'Raiffeisenbank Kemnather Land - Steinwald','88'),(77069782,'Raiffeisenbank am Kulm','88'),(77069836,'Raiffeisenbank Berg-Bad Steben -alt-','88'),(77069868,'Raiffeisenbank Oberland','88'),(77069870,'Raiffeisenbank Hochfranken West','88'),(77069906,'Raiffeisenbank Wüstenselbitz','88'),(77069908,'Raiffeisenbank Sparneck-Stammbach-Zell -alt-','88'),(77091800,'Raiffeisen-Volksbank Lichtenfels-Itzgrund','88'),(77120073,'UniCredit Bank - HypoVereinsbank','99'),(77140061,'Commerzbank','13'),(77150000,'Sparkasse Kulmbach-Kronach','00'),(77190000,'Kulmbacher Bank','88'),(77300000,'Bundesbank eh Bayreuth','09'),(77320072,'UniCredit Bank - HypoVereinsbank','99'),(77322200,'Fondsdepot Bank','00'),(77340076,'Commerzbank','13'),(77350110,'Sparkasse Bayreuth','00'),(77361600,'Raiffeisen-Volksbank Kronach-Ludwigsstadt','88'),(77363749,'Raiffeisenbank','88'),(77365792,'Raiffeisenbank Hollfeld-Waischenfeld-Aufseß','88'),(77390000,'Volksbank-Raiffeisenbank Bayreuth','88'),(77390628,'apoBank','A4'),(78020070,'UniCredit Bank - HypoVereinsbank','99'),(78040081,'Commerzbank Hof Saale','13'),(78050000,'Sparkasse Hochfranken','00'),(78055050,'Sparkasse Hochfranken -alt-','00'),(78060896,'VR Bank Hof','88'),(78140000,'Commerzbank','13'),(78160069,'VR-Bank Fichtelgebirge-Frankenwald','88'),(78161575,'Raiffeisenbank im Stiftland','88'),(78320076,'UniCredit Bank - HypoVereinsbank','99'),(78330111,'Bankhaus Max Flessa','09'),(78340091,'Commerzbank','13'),(78350000,'Sparkasse Coburg-Lichtenfels','00'),(78360000,'VR-Bank Coburg','88'),(79000000,'Bundesbank','09'),(79010111,'SEB','13'),(79020076,'UniCredit Bank - HypoVereinsbank','99'),(79030001,'Fürstlich Castellsche Bank Credit-Casse','09'),(79032038,'Bank Schilling & Co','00'),(79040047,'Commerzbank Würzburg','13'),(79050000,'Sparkasse Mainfranken Würzburg','00'),(79061000,'Raiffeisenbank-alt-','88'),(79062106,'Raiffeisenbank','88'),(79063060,'Raiffeisenbank Estenfeld-Bergtheim','88'),(79063122,'Raiffeisenbank Höchberg','88'),(79065028,'VR-Bank Bad Kissingen-Bad Brückenau','88'),(79066082,'Raiffeisenbank -alt-','88'),(79069001,'Raiffeisenbank Volkach-Wiesentheid','88'),(79069010,'VR-Bank Schweinfurt','88'),(79069031,'Raiffeisenbank Bütthard-Gaukönigshofen','88'),(79069090,'Raiffeisenbank Ulsenheim-Gollhofen -alt-','88'),(79069145,'Raiffeisenbank Kreuzwertheim-Hasloch -alt-','88'),(79069150,'Raiffeisenbank Main-Spessart','88'),(79069165,'Volksbank Raiffeisenbank Rhön-Grabfeld','88'),(79069181,'Raiffeisenbank','88'),(79069188,'Raiffeisenbank im Grabfeld','88'),(79069213,'Raiffeisenbank Maßbach','88'),(79069271,'Raiffeisenbank -alt-','88'),(79070016,'Deutsche Bank','63'),(79070024,'Deutsche Bank Privat und Geschäftskunden','63'),(79080052,'Commerzbank vormals Dresdner Bank','76'),(79080085,'Commerzbank vormals Dresdner Bank, PCC DCC-ITGK 1','09'),(79090000,'Volksbank Raiffeisenbank','88'),(79090624,'apoBank','A4'),(79161058,'Raiffeisenbank Fränkisches Weinland','88'),(79161499,'Raiffeisenbank Kitzinger Land','88'),(79190000,'VR Bank Kitzingen','88'),(79320075,'UniCredit Bank - HypoVereinsbank','99'),(79330111,'Bankhaus Max Flessa','09'),(79340054,'Commerzbank Schweinfurt','13'),(79350000,'Städtische Sparkasse Schweinfurt -alt-','00'),(79350101,'Sparkasse Schweinfurt','00'),(79351010,'Sparkasse Bad Kissingen','00'),(79351730,'Sparkasse Ostunterfranken','00'),(79353090,'Sparkasse Bad Neustadt a d Saale','00'),(79362081,'VR-Bank Gerolzhofen','88'),(79363016,'Volksbank Raiffeisenbank Rhön-Grabfeld -alt-','88'),(79363151,'Raiffeisen-Volksbank Haßberge','88'),(79364069,'Raiffeisenbank Frankenwinheim und Umgebung','88'),(79364406,'VR-Bank Schweinfurt Land -alt-','88'),(79380051,'Commerzbank vormals Dresdner Bank','76'),(79510111,'SEB','13'),(79520070,'UniCredit Bank - HypoVereinsbank','99'),(79540049,'Commerzbank','13'),(79550000,'Sparkasse Aschaffenburg Alzenau','00'),(79561348,'Raiffeisenbank Bachgau -alt-','88'),(79562514,'Raiffeisenbank Aschaffenburg','88'),(79565568,'Raiffeisenbank Waldaschaff-Heigenbrücken','88'),(79567531,'VR-Bank','88'),(79568518,'Raiffeisenbank Haibach-Obernau','88'),(79570024,'Deutsche Bank Privat und Geschäftskunden','63'),(79570051,'Deutsche Bank','63'),(79580099,'Commerzbank vormals Dresdner Bank','76'),(79589402,'Commerzbank vormals Dresdner Bank ITGK','09'),(79590000,'Volksbank Aschaffenburg','88'),(79650000,'Sparkasse Miltenberg-Obernburg','00'),(79665540,'Raiffeisenbank Elsavatal','88'),(79666548,'Raiffeisenbank Großostheim-Obernburg','88'),(79668509,'Raiffeisenbank Eichenbühl und Umgebung','88'),(79690000,'Raiffeisen-Volksbank Miltenberg -alt-','88'),(80020086,'UniCredit Bank - HypoVereinsbank','99'),(80020087,'UniCredit Bank - HypoVereinsbank','99'),(80040000,'Commerzbank','13'),(80050500,'Kreissparkasse Merseburg-Querfurt -alt-','20'),(80053000,'Sparkasse Burgenlandkreis','20'),(80053572,'Stadtsparkasse Dessau','C0'),(80053622,'Kreissparkasse Köthen -alt-','C0'),(80053722,'Kreissparkasse Anhalt-Bitterfeld','C0'),(80053762,'Saalesparkasse','B6'),(80054000,'Kreissparkasse Weißenfels -alt-','20'),(80055008,'Sparkasse Mansfeld-Südharz','20'),(80055500,'Salzlandsparkasse','20'),(80062608,'Volksbank Elsterland','32'),(80063508,'Harzer Volksbank','28'),(80063558,'Volksbank','32'),(80063598,'Volksbank Wittenberg','32'),(80063628,'Volksbank','32'),(80063648,'Volks- und Raiffeisenbank Saale-Unstrut','28'),(80063678,'VR-Bank Zeitz -alt-','32'),(80063718,'Volks- und Raiffeisenbank Eisleben','32'),(80080000,'Commerzbank vormals Dresdner Bank','76'),(80093574,'Volksbank Dessau-Anhalt','32'),(80093784,'Volksbank Halle, Saale','32'),(80550101,'Sparkasse Wittenberg','20'),(80550200,'Kreissparkasse Anhalt-Zerbst -alt-','20'),(81000000,'Bundesbank','09'),(81010111,'SEB','13'),(81020500,'Bank für Sozialwirtschaft','09'),(81040000,'Commerzbank','13'),(81050555,'Kreissparkasse Stendal','20'),(81052000,'Harzsparkasse','20'),(81053272,'Stadtsparkasse Magdeburg','C0'),(81054000,'Sparkasse Jerichower Land','20'),(81055000,'Kreissparkasse Börde','20'),(81055555,'Sparkasse Altmark West','20'),(81063028,'Raiffeisenbank Kalbe-Bismark','32'),(81063238,'Volksbank Jerichower Land','32'),(81068106,'Bank für Kirche und Diakonie - KD-Bank Gf Sonder-BLZ','09'),(81069052,'Volksbank Börde-Bernburg','32'),(81070000,'Deutsche Bank','63'),(81070024,'Deutsche Bank Privat und Geschäftskunden','63'),(81080000,'Commerzbank vormals Dresdner Bank','76'),(81093034,'Volksbank','32'),(81093044,'Volksbank Osterburg-Lüchow-Dannenberg -alt-','32'),(81093054,'Volksbank Stendal','32'),(81093274,'Volksbank Magdeburg','32'),(82000000,'Bundesbank','09'),(82010111,'SEB','13'),(82020086,'UniCredit Bank - HypoVereinsbank','99'),(82020087,'UniCredit Bank - HypoVereinsbank','99'),(82020088,'UniCredit Bank - HypoVereinsbank','99'),(82040000,'Commerzbank','13'),(82040085,'Commerzbank, Gf Web-K','13'),(82050000,'Landesbank Hessen-Thür Girozentrale Erfurt','00'),(82051000,'Sparkasse Mittelthüringen','20'),(82052020,'Kreissparkasse Gotha','20'),(82054052,'Kreissparkasse Nordhausen','C0'),(82055000,'Kyffhäusersparkasse','20'),(82056060,'Sparkasse Unstrut-Hainich','20'),(82057070,'Kreissparkasse Eichsfeld','20'),(82060197,'Pax-Bank','06'),(82064038,'VR Bank Westthüringen','32'),(82064088,'Volksbank und Raiffeisenbank','32'),(82064168,'Raiffeisenbank Gotha','32'),(82064188,'VR Bank Weimar','32'),(82064228,'Erfurter Bank','32'),(82070000,'Deutsche Bank','63'),(82070024,'Deutsche Bank Privat und Geschäftskunden','63'),(82080000,'Commerzbank vormals Dresdner Bank','76'),(82094004,'Volksbank Heiligenstadt','06'),(82094054,'Nordthüringer Volksbank','32'),(83020086,'UniCredit Bank - HypoVereinsbank','99'),(83020087,'UniCredit Bank - HypoVereinsbank','99'),(83020088,'UniCredit Bank - HypoVereinsbank','99'),(83040000,'Commerzbank','13'),(83050000,'Sparkasse Gera-Greiz','20'),(83050200,'Sparkasse Altenburger Land','20'),(83050303,'Kreissparkasse Saalfeld-Rudolstadt','20'),(83050505,'Kreissparkasse Saale-Orla','20'),(83053030,'Sparkasse Jena-Saale-Holzland','20'),(83064488,'Raiffeisen-Volksbank Hermsdorfer Kreuz','32'),(83064568,'Geraer Bank -alt-','32'),(83065408,'VR-Bank Altenburger Land / Deutsche Skatbank','32'),(83080000,'Commerzbank vormals Dresdner Bank','76'),(83094444,'Raiffeisen-Volksbank Saale-Orla','32'),(83094454,'Volksbank Gera-Jena-Rudolstadt','06'),(83094494,'Volksbank Eisenberg','32'),(83094495,'EthikBank, Zndl der Volksbank Eisenberg','32'),(84020087,'UniCredit Bank - HypoVereinsbank','99'),(84030111,'Bankhaus Max Flessa','09'),(84040000,'Commerzbank','13'),(84050000,'Rhön-Rennsteig-Sparkasse','20'),(84051010,'Sparkasse Arnstadt-Ilmenau','20'),(84054040,'Kreissparkasse Hildburghausen','20'),(84054722,'Sparkasse Sonneberg','20'),(84055050,'Wartburg-Sparkasse','20'),(84064798,'Genobank Rhön-Grabfeld','88'),(84069065,'Raiffeisenbank Schleusingen -alt-','32'),(84080000,'Commerzbank vormals Dresdner Bank','76'),(84094754,'VR-Bank Bad Salzungen Schmalkalden','32'),(84094755,'VR-Bank Bad Salzungen Schmalkalden GAA','32'),(84094814,'VR Bank Südthüringen','32'),(85000000,'Bundesbank eh Dresden','09'),(85010500,'Sächsische Aufbaubank -Förderbank-','09'),(85020086,'UniCredit Bank - HypoVereinsbank','99'),(85020500,'Bank für Sozialwirtschaft','09'),(85040000,'Commerzbank','13'),(85040060,'Commerzbank CC','09'),(85040061,'Commerzbank CC','09'),(85050100,'Sparkasse Oberlausitz-Niederschlesien','20'),(85050200,'Kreissparkasse Riesa-Großenhain -alt-','20'),(85050300,'Ostsächsische Sparkasse Dresden','20'),(85055000,'Sparkasse Meißen','20'),(85060000,'Volksbank Pirna','32'),(85065028,'Raiffeisenbank Neustadt, Sachs -alt-','32'),(85080000,'Commerzbank vormals Dresdner Bank','76'),(85080085,'Commerzbank vormals Dresdner Bank, PCC DCC-ITGK 1','09'),(85080086,'Commerzbank vormals Dresdner Bank, PCC DCC-ITGK 2','09'),(85080200,'Commerzbank vormals Dresdner Bank','76'),(85089270,'Commerzbank vormals Dresdner Bank ITGK','09'),(85090000,'Dresdner Volksbank Raiffeisenbank','06'),(85094984,'Volksbank Riesa','06'),(85095004,'Volksbank Raiffeisenbank Meißen Großenhain','06'),(85550000,'Kreissparkasse Bautzen','20'),(85590000,'Volksbank Bautzen','06'),(85590100,'Volksbank Löbau-Zittau','06'),(85591000,'Volksbank Raiffeisenbank Niederschlesien','06'),(86000000,'Bundesbank','09'),(86010090,'Postbank','24'),(86010111,'SEB','13'),(86010424,'Aareal Bank','09'),(86020086,'UniCredit Bank - HypoVereinsbank','99'),(86020500,'Bank für Sozialwirtschaft','09'),(86033300,'Santander Consumer Bank','09'),(86040000,'Commerzbank','13'),(86040060,'Commerzbank CC','09'),(86040061,'Commerzbank CC','09'),(86050000,'ZV Landesbank Baden-Württemberg','09'),(86050200,'Sparkasse Muldental','20'),(86050600,'Kreissparkasse Torgau-Oschatz -alt-','20'),(86055002,'Sparkasse Delitzsch-Eilenburg -alt-','20'),(86055462,'Kreissparkasse Döbeln','C0'),(86055592,'Stadt- und Kreissparkasse Leipzig','D0'),(86065448,'VR Bank Leipziger Land','32'),(86065468,'VR-Bank Mittelsachsen','06'),(86065483,'Raiffeisenbank Grimma','06'),(86069070,'Raiffeisenbank','06'),(86070000,'Deutsche Bank','63'),(86070024,'Deutsche Bank Privat und Geschäftskunden','63'),(86080000,'Commerzbank vormals Dresdner Bank','76'),(86080055,'Commerzbank vormals Dresdner Bank Zw 55','76'),(86080057,'Commerzbank vormals Dresdner Bank Gf ZW 57','76'),(86080085,'Commerzbank vormals Dresdner Bank, PCC DCC-ITGK 1','09'),(86080086,'Commerzbank vormals Dresdner Bank, PCC DCC-ITGK 2','09'),(86089280,'Commerzbank vormals Dresdner Bank ITGK','09'),(86095484,'Volks- und Raiffeisenbank Muldental','06'),(86095554,'Volksbank Delitzsch','06'),(86095604,'Leipziger Volksbank','06'),(87000000,'Bundesbank','09'),(87020086,'UniCredit Bank - HypoVereinsbank','99'),(87020087,'UniCredit Bank - HypoVereinsbank','99'),(87020088,'UniCredit Bank - HypoVereinsbank','99'),(87040000,'Commerzbank','13'),(87050000,'Sparkasse Chemnitz','20'),(87051000,'Sparkasse Mittelsachsen -alt-','20'),(87052000,'Sparkasse Mittelsachsen','20'),(87053000,'Sparkasse Mittleres Erzgebirge -alt-','20'),(87054000,'Erzgebirgssparkasse','20'),(87055000,'Sparkasse Zwickau','20'),(87056000,'Kreissparkasse Aue-Schwarzenberg -alt-','20'),(87058000,'Sparkasse Vogtland','20'),(87069075,'Volksbank Mittleres Erzgebirge','06'),(87069077,'Vereinigte Raiffeisenbank Burgstädt','06'),(87070000,'Deutsche Bank','63'),(87070024,'Deutsche Bank Privat und Geschäftskunden','63'),(87080000,'Commerzbank vormals Dresdner Bank','76'),(87095824,'Volksbank Vogtland','06'),(87095899,'Volksbank Vogtland GAA','09'),(87095934,'Volksbank Zwickau','06'),(87095974,'Volksbank-Raiffeisenbank Glauchau','06'),(87096034,'Volksbank Erzgebirge -alt-','06'),(87096124,'Volksbank Mittweida','06'),(87096214,'Volksbank Chemnitz','06');
/*!40000 ALTER TABLE `banktransfer_blz` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `banners`
--

DROP TABLE IF EXISTS `banners`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `banners` (
  `banners_id` int(11) NOT NULL AUTO_INCREMENT,
  `banners_title` varchar(64) COLLATE latin1_german1_ci NOT NULL,
  `banners_url` varchar(255) COLLATE latin1_german1_ci NOT NULL,
  `banners_image` varchar(64) COLLATE latin1_german1_ci NOT NULL,
  `banners_group` varchar(10) COLLATE latin1_german1_ci NOT NULL,
  `banners_html_text` text COLLATE latin1_german1_ci,
  `languages_id` int(11) NOT NULL,
  `expires_impressions` int(7) DEFAULT NULL,
  `expires_date` datetime DEFAULT NULL,
  `date_scheduled` datetime DEFAULT NULL,
  `date_added` datetime NOT NULL,
  `date_status_change` datetime DEFAULT NULL,
  `status` int(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`banners_id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=latin1 COLLATE=latin1_german1_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `banners`
--

LOCK TABLES `banners` WRITE;
/*!40000 ALTER TABLE `banners` DISABLE KEYS */;
INSERT INTO `banners` VALUES (1,'modified eCommerce Shopsoftware','http://www.modified-shop.org','banner_modified-ecommerce-shopsoftware_en.jpg','banner','',1,NULL,NULL,NULL,'2019-02-05 19:42:01',NULL,1),(2,'modified eCommerce Shopsoftware','http://www.modified-shop.org','banner_modified-ecommerce-shopsoftware_de.jpg','banner','',2,NULL,NULL,NULL,'2019-02-05 19:42:01',NULL,1);
/*!40000 ALTER TABLE `banners` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `banners_history`
--

DROP TABLE IF EXISTS `banners_history`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `banners_history` (
  `banners_history_id` int(11) NOT NULL AUTO_INCREMENT,
  `banners_id` int(11) NOT NULL,
  `banners_shown` int(5) NOT NULL DEFAULT '0',
  `banners_clicked` int(5) NOT NULL DEFAULT '0',
  `banners_history_date` datetime NOT NULL,
  PRIMARY KEY (`banners_history_id`),
  KEY `idx_banners_id` (`banners_id`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=latin1 COLLATE=latin1_german1_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `banners_history`
--

LOCK TABLES `banners_history` WRITE;
/*!40000 ALTER TABLE `banners_history` DISABLE KEYS */;
INSERT INTO `banners_history` VALUES (1,2,6,0,'2019-02-05 19:45:31'),(2,2,134,0,'2019-02-07 06:32:50'),(3,2,8,0,'2019-02-08 06:34:43'),(4,2,6,0,'2019-02-09 11:07:34');
/*!40000 ALTER TABLE `banners_history` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `campaigns`
--

DROP TABLE IF EXISTS `campaigns`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `campaigns` (
  `campaigns_id` int(11) NOT NULL AUTO_INCREMENT,
  `campaigns_name` varchar(32) COLLATE latin1_german1_ci NOT NULL DEFAULT '',
  `campaigns_refID` varchar(64) COLLATE latin1_german1_ci NOT NULL,
  `campaigns_leads` int(11) NOT NULL DEFAULT '0',
  `date_added` datetime DEFAULT NULL,
  `last_modified` datetime DEFAULT NULL,
  PRIMARY KEY (`campaigns_id`),
  UNIQUE KEY `idx_campaigns_refID` (`campaigns_refID`),
  KEY `idx_campaigns_name` (`campaigns_name`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_german1_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `campaigns`
--

LOCK TABLES `campaigns` WRITE;
/*!40000 ALTER TABLE `campaigns` DISABLE KEYS */;
/*!40000 ALTER TABLE `campaigns` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `campaigns_ip`
--

DROP TABLE IF EXISTS `campaigns_ip`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `campaigns_ip` (
  `user_ip` varchar(50) COLLATE latin1_german1_ci NOT NULL,
  `time` datetime NOT NULL,
  `campaign` varchar(32) COLLATE latin1_german1_ci NOT NULL,
  KEY `idx_campaign` (`campaign`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_german1_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `campaigns_ip`
--

LOCK TABLES `campaigns_ip` WRITE;
/*!40000 ALTER TABLE `campaigns_ip` DISABLE KEYS */;
/*!40000 ALTER TABLE `campaigns_ip` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `carriers`
--

DROP TABLE IF EXISTS `carriers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `carriers` (
  `carrier_id` int(11) NOT NULL AUTO_INCREMENT,
  `carrier_name` varchar(80) COLLATE latin1_german1_ci NOT NULL,
  `carrier_tracking_link` varchar(512) COLLATE latin1_german1_ci NOT NULL,
  `carrier_sort_order` int(11) NOT NULL,
  `carrier_date_added` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `carrier_last_modified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`carrier_id`)
) ENGINE=MyISAM AUTO_INCREMENT=13 DEFAULT CHARSET=latin1 COLLATE=latin1_german1_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `carriers`
--

LOCK TABLES `carriers` WRITE;
/*!40000 ALTER TABLE `carriers` DISABLE KEYS */;
INSERT INTO `carriers` VALUES (1,'DHL','http://nolp.dhl.de/nextt-online-public/set_identcodes.do?lang=$2&idc=$1',10,'2019-02-05 19:42:01','0000-00-00 00:00:00'),(2,'DPD','https://extranet.dpd.de/cgi-bin/delistrack?pknr=$1+&typ=1&lang=$2',20,'2019-02-05 19:42:01','0000-00-00 00:00:00'),(3,'GLS','https://gls-group.eu/DE/de/paketverfolgung?match=$1',30,'2019-02-05 19:42:01','0000-00-00 00:00:00'),(4,'UPS','http://wwwapps.ups.com/WebTracking/track?track=yes&trackNums=$1',40,'2019-02-05 19:42:01','0000-00-00 00:00:00'),(5,'HERMES','http://tracking.hlg.de/Tracking.jsp?TrackID=$1',50,'2019-02-05 19:42:01','0000-00-00 00:00:00'),(6,'FEDEX','http://www.fedex.com/Tracking?action=track&tracknumbers=$1',60,'2019-02-05 19:42:01','0000-00-00 00:00:00'),(7,'TNT','http://www.tnt.de/servlet/Tracking?cons=$1',70,'2019-02-05 19:42:01','0000-00-00 00:00:00'),(8,'TRANS-O-FLEX','http://track.tof.de/trace/tracking.cgi?barcode=$1',80,'2019-02-05 19:42:01','0000-00-00 00:00:00'),(9,'KUEHNE-NAGEL','https://knlogin.kuehne-nagel.com/apps/fls.do?subevent=search&knReference=$1',90,'2019-02-05 19:42:01','0000-00-00 00:00:00'),(10,'ILOXX','http://www.iloxx.de/net/einzelversand/tracking.aspx?ix=$1',100,'2019-02-05 19:42:01','0000-00-00 00:00:00'),(11,'LogoiX','http://www.logoix.com/cgi-bin/tnt.pl?q=$1',110,'2019-02-05 19:42:01','0000-00-00 00:00:00'),(12,'POST','https://www.deutschepost.de/sendung/simpleQueryResult.html?form.sendungsnummer=$1&form.einlieferungsdatum_tag=$3&form.einlieferungsdatum_monat=$4&form.einlieferungsdatum_jahr=$5',120,'2019-02-05 19:42:01','0000-00-00 00:00:00');
/*!40000 ALTER TABLE `carriers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `categories`
--

DROP TABLE IF EXISTS `categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `categories` (
  `categories_id` int(11) NOT NULL AUTO_INCREMENT,
  `categories_image` varchar(64) COLLATE latin1_german1_ci DEFAULT NULL,
  `parent_id` int(11) NOT NULL DEFAULT '0',
  `categories_status` int(1) NOT NULL,
  `categories_template` varchar(64) COLLATE latin1_german1_ci DEFAULT NULL,
  `group_permission_0` tinyint(1) NOT NULL,
  `group_permission_1` tinyint(1) NOT NULL,
  `group_permission_2` tinyint(1) NOT NULL,
  `group_permission_3` tinyint(1) NOT NULL,
  `group_permission_4` tinyint(1) NOT NULL,
  `listing_template` varchar(64) COLLATE latin1_german1_ci NOT NULL DEFAULT '',
  `sort_order` int(3) NOT NULL DEFAULT '0',
  `products_sorting` varchar(64) COLLATE latin1_german1_ci DEFAULT NULL,
  `products_sorting2` varchar(64) COLLATE latin1_german1_ci DEFAULT NULL,
  `date_added` datetime DEFAULT NULL,
  `last_modified` datetime DEFAULT NULL,
  PRIMARY KEY (`categories_id`),
  KEY `idx_categories_parent_id` (`parent_id`),
  KEY `idx_categories_status` (`categories_status`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_german1_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `categories`
--

LOCK TABLES `categories` WRITE;
/*!40000 ALTER TABLE `categories` DISABLE KEYS */;
/*!40000 ALTER TABLE `categories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `categories_description`
--

DROP TABLE IF EXISTS `categories_description`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `categories_description` (
  `categories_id` int(11) NOT NULL,
  `language_id` int(11) NOT NULL,
  `categories_name` varchar(255) COLLATE latin1_german1_ci NOT NULL,
  `categories_heading_title` varchar(255) COLLATE latin1_german1_ci NOT NULL,
  `categories_description` text COLLATE latin1_german1_ci NOT NULL,
  `categories_meta_title` text COLLATE latin1_german1_ci NOT NULL,
  `categories_meta_description` text COLLATE latin1_german1_ci NOT NULL,
  `categories_meta_keywords` text COLLATE latin1_german1_ci NOT NULL,
  PRIMARY KEY (`categories_id`,`language_id`),
  KEY `idx_categories_name` (`categories_name`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_german1_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `categories_description`
--

LOCK TABLES `categories_description` WRITE;
/*!40000 ALTER TABLE `categories_description` DISABLE KEYS */;
/*!40000 ALTER TABLE `categories_description` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cm_file_flags`
--

DROP TABLE IF EXISTS `cm_file_flags`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cm_file_flags` (
  `file_flag` int(11) NOT NULL,
  `file_flag_name` varchar(32) COLLATE latin1_german1_ci NOT NULL,
  PRIMARY KEY (`file_flag`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_german1_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cm_file_flags`
--

LOCK TABLES `cm_file_flags` WRITE;
/*!40000 ALTER TABLE `cm_file_flags` DISABLE KEYS */;
INSERT INTO `cm_file_flags` VALUES (0,'information'),(1,'content');
/*!40000 ALTER TABLE `cm_file_flags` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `configuration`
--

DROP TABLE IF EXISTS `configuration`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `configuration` (
  `configuration_id` int(11) NOT NULL AUTO_INCREMENT,
  `configuration_key` varchar(64) COLLATE latin1_german1_ci NOT NULL,
  `configuration_value` text COLLATE latin1_german1_ci NOT NULL,
  `configuration_group_id` int(11) NOT NULL,
  `sort_order` int(5) DEFAULT NULL,
  `last_modified` datetime DEFAULT NULL,
  `date_added` datetime NOT NULL,
  `use_function` varchar(255) COLLATE latin1_german1_ci DEFAULT NULL,
  `set_function` varchar(255) COLLATE latin1_german1_ci DEFAULT NULL,
  PRIMARY KEY (`configuration_id`),
  UNIQUE KEY `idx_configuration_key` (`configuration_key`),
  KEY `idx_configuration_group_id` (`configuration_group_id`)
) ENGINE=MyISAM AUTO_INCREMENT=387 DEFAULT CHARSET=latin1 COLLATE=latin1_german1_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `configuration`
--

LOCK TABLES `configuration` WRITE;
/*!40000 ALTER TABLE `configuration` DISABLE KEYS */;
INSERT INTO `configuration` VALUES (1,'STORE_NAME','ascasa Gmbh',1,1,NULL,'2019-02-05 19:42:01',NULL,NULL),(2,'STORE_OWNER','ascasa Gmbh',1,2,NULL,'2019-02-05 19:42:01',NULL,NULL),(3,'STORE_NAME_ADDRESS','ascasa Gmbh\r\nFabian Schwarzbauer\r\nOtto-Hahn-Straße 13 b\r\n85521 Hohenbrunn-Riemerling\r\n\r\nm.foerster@brainsquad.de',1,3,'2019-02-05 19:45:59','2019-02-05 19:42:01',NULL,'xtc_cfg_textarea('),(4,'STORE_COUNTRY','81',1,4,NULL,'2019-02-05 19:42:01','xtc_get_country_name','xtc_cfg_pull_down_country_list('),(5,'STORE_ZONE','81',1,5,'2019-02-07 11:26:04','2019-02-05 19:42:01','xtc_cfg_get_zone_name','xtc_cfg_pull_down_zone_list('),(6,'STORE_OWNER_EMAIL_ADDRESS','m.foerster@brainsquad.de',1,6,NULL,'2019-02-05 19:42:01',NULL,NULL),(7,'EMAIL_FROM','m.foerster@brainsquad.de',1,7,NULL,'2019-02-05 19:42:01',NULL,NULL),(8,'USE_DEFAULT_LANGUAGE_CURRENCY','false',1,10,NULL,'2019-02-05 19:42:01',NULL,'xtc_cfg_select_option(array(\'true\', \'false\'),'),(9,'USE_BROWSER_LANGUAGE','false',1,11,NULL,'2019-02-05 19:42:01',NULL,'xtc_cfg_select_option(array(\'true\', \'false\'),'),(10,'DISPLAY_CART','false',1,13,NULL,'2019-02-05 19:42:01',NULL,'xtc_cfg_select_option(array(\'true\', \'false\'),'),(11,'SHOW_COUNTS','false',1,17,NULL,'2019-02-05 19:42:01',NULL,'xtc_cfg_select_option(array(\'true\', \'false\'),'),(12,'DEFAULT_CUSTOMERS_STATUS_ID_ADMIN','0',1,20,NULL,'2019-02-05 19:42:01','xtc_get_customers_status_name','xtc_cfg_pull_down_customers_status_list('),(13,'DEFAULT_CUSTOMERS_STATUS_ID_GUEST','1',1,21,NULL,'2019-02-05 19:42:01','xtc_get_customers_status_name','xtc_cfg_pull_down_customers_status_list('),(14,'DEFAULT_CUSTOMERS_STATUS_ID','2',1,23,NULL,'2019-02-05 19:42:01','xtc_get_customers_status_name','xtc_cfg_pull_down_customers_status_list('),(15,'ALLOW_ADD_TO_CART','false',1,24,NULL,'2019-02-05 19:42:01',NULL,'xtc_cfg_select_option(array(\'true\', \'false\'),'),(16,'CURRENT_TEMPLATE','tpl_modified_responsive',1,26,'2019-02-05 19:45:59','2019-02-05 19:42:01',NULL,'xtc_cfg_pull_down_template_sets('),(17,'USE_SHORT_DATE_FORMAT','true',1,50,NULL,'2019-02-05 19:42:01',NULL,'xtc_cfg_select_option(array(\'true\', \'false\'),'),(18,'CHECKOUT_USE_PRODUCTS_SHORT_DESCRIPTION','true',1,40,NULL,'2019-02-05 19:42:01',NULL,'xtc_cfg_select_option(array(\'true\', \'false\'),'),(19,'CHECKOUT_USE_PRODUCTS_DESCRIPTION_FALLBACK_LENGTH','300',1,41,NULL,'2019-02-05 19:42:01',NULL,NULL),(20,'CHECKOUT_SHOW_PRODUCTS_IMAGES','true',1,42,NULL,'2019-02-05 19:42:01',NULL,'xtc_cfg_select_option(array(\'true\', \'false\'),'),(21,'ENTRY_FIRST_NAME_MIN_LENGTH','2',2,1,NULL,'2019-02-05 19:42:02',NULL,NULL),(22,'ENTRY_LAST_NAME_MIN_LENGTH','2',2,2,NULL,'2019-02-05 19:42:02',NULL,NULL),(23,'ENTRY_DOB_MIN_LENGTH','10',2,3,NULL,'2019-02-05 19:42:02',NULL,NULL),(24,'ENTRY_EMAIL_ADDRESS_MIN_LENGTH','6',2,4,NULL,'2019-02-05 19:42:02',NULL,NULL),(25,'ENTRY_STREET_ADDRESS_MIN_LENGTH','4',2,5,NULL,'2019-02-05 19:42:02',NULL,NULL),(26,'ENTRY_COMPANY_MIN_LENGTH','2',2,6,NULL,'2019-02-05 19:42:02',NULL,NULL),(27,'ENTRY_POSTCODE_MIN_LENGTH','4',2,7,NULL,'2019-02-05 19:42:02',NULL,NULL),(28,'ENTRY_CITY_MIN_LENGTH','3',2,8,NULL,'2019-02-05 19:42:02',NULL,NULL),(29,'ENTRY_STATE_MIN_LENGTH','0',2,9,NULL,'2019-02-05 19:42:02',NULL,NULL),(30,'ENTRY_TELEPHONE_MIN_LENGTH','3',2,10,NULL,'2019-02-05 19:42:02',NULL,NULL),(31,'ENTRY_PASSWORD_MIN_LENGTH','8',2,11,NULL,'2019-02-05 19:42:02',NULL,NULL),(32,'POLICY_MIN_LOWER_CHARS','1',2,12,NULL,'2019-02-05 19:42:02',NULL,NULL),(33,'POLICY_MIN_UPPER_CHARS','1',2,12,NULL,'2019-02-05 19:42:02',NULL,NULL),(34,'POLICY_MIN_NUMERIC_CHARS','1',2,12,NULL,'2019-02-05 19:42:02',NULL,NULL),(35,'POLICY_MIN_SPECIAL_CHARS','1',2,12,NULL,'2019-02-05 19:42:02',NULL,NULL),(36,'REVIEW_TEXT_MIN_LENGTH','50',2,14,NULL,'2019-02-05 19:42:02',NULL,NULL),(37,'MIN_DISPLAY_BESTSELLERS','1',2,15,NULL,'2019-02-05 19:42:02',NULL,NULL),(38,'MIN_DISPLAY_ALSO_PURCHASED','1',2,16,NULL,'2019-02-05 19:42:02',NULL,NULL),(39,'MAX_ADDRESS_BOOK_ENTRIES','5',3,1,NULL,'2019-02-05 19:42:02',NULL,NULL),(40,'MAX_DISPLAY_SEARCH_RESULTS','20',3,2,NULL,'2019-02-05 19:42:02',NULL,NULL),(41,'MAX_DISPLAY_PAGE_LINKS','5',3,3,NULL,'2019-02-05 19:42:02',NULL,NULL),(42,'MAX_DISPLAY_SPECIAL_PRODUCTS','9',3,4,NULL,'2019-02-05 19:42:02',NULL,NULL),(43,'MAX_DISPLAY_NEW_PRODUCTS','9',3,5,NULL,'2019-02-05 19:42:02',NULL,NULL),(44,'MAX_DISPLAY_UPCOMING_PRODUCTS','10',3,6,NULL,'2019-02-05 19:42:02',NULL,NULL),(45,'MAX_DISPLAY_MANUFACTURERS_IN_A_LIST','0',3,7,NULL,'2019-02-05 19:42:02',NULL,NULL),(46,'MAX_MANUFACTURERS_LIST','1',3,7,NULL,'2019-02-05 19:42:02',NULL,NULL),(47,'MAX_DISPLAY_MANUFACTURER_NAME_LEN','26',3,8,NULL,'2019-02-05 19:42:02',NULL,NULL),(48,'MAX_DISPLAY_NEW_REVIEWS','6',3,9,NULL,'2019-02-05 19:42:02',NULL,NULL),(49,'MAX_RANDOM_SELECT_REVIEWS','10',3,10,NULL,'2019-02-05 19:42:02',NULL,NULL),(50,'MAX_RANDOM_SELECT_NEW','10',3,11,NULL,'2019-02-05 19:42:02',NULL,NULL),(51,'MAX_RANDOM_SELECT_SPECIALS','10',3,12,NULL,'2019-02-05 19:42:02',NULL,NULL),(52,'MAX_DISPLAY_CATEGORIES_PER_ROW','5',3,13,NULL,'2019-02-05 19:42:02',NULL,NULL),(53,'MAX_DISPLAY_PRODUCTS_NEW','10',3,14,NULL,'2019-02-05 19:42:02',NULL,NULL),(54,'MAX_DISPLAY_BESTSELLERS','10',3,15,NULL,'2019-02-05 19:42:02',NULL,NULL),(55,'MAX_DISPLAY_BESTSELLERS_DAYS','100',3,15,NULL,'2019-02-05 19:42:02',NULL,NULL),(56,'MAX_DISPLAY_ALSO_PURCHASED','6',3,16,NULL,'2019-02-05 19:42:02',NULL,NULL),(57,'MAX_DISPLAY_PRODUCTS_IN_ORDER_HISTORY_BOX','6',3,17,NULL,'2019-02-05 19:42:02',NULL,NULL),(58,'MAX_DISPLAY_ORDER_HISTORY','10',3,18,NULL,'2019-02-05 19:42:02',NULL,NULL),(59,'PRODUCT_REVIEWS_VIEW','5',3,19,NULL,'2019-02-05 19:42:02',NULL,NULL),(60,'MAX_PRODUCTS_QTY','1000',3,21,NULL,'2019-02-05 19:42:02',NULL,NULL),(61,'MAX_DISPLAY_NEW_PRODUCTS_DAYS','30',3,22,NULL,'2019-02-05 19:42:02',NULL,NULL),(62,'MAX_DISPLAY_PRODUCTS_CATEGORY','10',3,23,NULL,'2019-02-05 19:42:03',NULL,NULL),(63,'MAX_DISPLAY_ADVANCED_SEARCH_RESULTS','10',3,24,NULL,'2019-02-05 19:42:03',NULL,NULL),(64,'MAX_DISPLAY_PRODUCTS_HISTORY','6',3,25,NULL,'2019-02-05 19:42:03',NULL,NULL),(65,'CONFIG_CALCULATE_IMAGE_SIZE','true',4,1,NULL,'2019-02-05 19:42:03',NULL,'xtc_cfg_select_option(array(\'true\', \'false\'),'),(66,'IMAGE_QUALITY','100',4,2,NULL,'2019-02-05 19:42:03',NULL,NULL),(67,'PRODUCT_IMAGE_THUMBNAIL_WIDTH','160',4,7,NULL,'2019-02-05 19:42:03',NULL,NULL),(68,'PRODUCT_IMAGE_THUMBNAIL_HEIGHT','160',4,8,NULL,'2019-02-05 19:42:03',NULL,NULL),(69,'PRODUCT_IMAGE_INFO_WIDTH','230',4,9,NULL,'2019-02-05 19:42:03',NULL,NULL),(70,'PRODUCT_IMAGE_INFO_HEIGHT','230',4,10,NULL,'2019-02-05 19:42:03',NULL,NULL),(71,'PRODUCT_IMAGE_POPUP_WIDTH','800',4,11,NULL,'2019-02-05 19:42:03',NULL,NULL),(72,'PRODUCT_IMAGE_POPUP_HEIGHT','800',4,12,NULL,'2019-02-05 19:42:03',NULL,NULL),(73,'PRODUCT_IMAGE_THUMBNAIL_MERGE','',4,17,NULL,'2019-02-05 19:42:03',NULL,NULL),(74,'PRODUCT_IMAGE_INFO_MERGE','',4,25,NULL,'2019-02-05 19:42:03',NULL,NULL),(75,'PRODUCT_IMAGE_POPUP_MERGE','',4,33,NULL,'2019-02-05 19:42:03',NULL,NULL),(76,'MO_PICS','3',4,3,NULL,'2019-02-05 19:42:03',NULL,NULL),(77,'IMAGE_MANIPULATOR','image_manipulator_GD2_advanced.php',4,3,NULL,'2019-02-05 19:42:03',NULL,'xtc_cfg_select_option(array(\'image_manipulator_GD2.php\', \'image_manipulator_GD2_advanced.php\', \'image_manipulator_GD1.php\'),'),(78,'PRODUCT_IMAGE_NO_ENLARGE_UNDER_DEFAULT','false',4,6,NULL,'2019-02-05 19:42:03',NULL,'xtc_cfg_select_option(array(\'true\', \'false\'), '),(79,'PRODUCT_IMAGE_SHOW_NO_IMAGE','false',4,6,NULL,'2019-02-05 19:42:03',NULL,'xtc_cfg_select_option(array(\'true\', \'false\'), '),(80,'CATEGORIES_IMAGE_SHOW_NO_IMAGE','true',4,6,NULL,'2019-02-05 19:42:03',NULL,'xtc_cfg_select_option(array(\'true\', \'false\'), '),(81,'MANUFACTURER_IMAGE_SHOW_NO_IMAGE','false',4,6,NULL,'2019-02-05 19:42:03',NULL,'xtc_cfg_select_option(array(\'true\', \'false\'), '),(82,'ACCOUNT_GENDER','true',5,10,NULL,'2019-02-05 19:42:03',NULL,'xtc_cfg_select_option(array(\'true\', \'false\'),'),(83,'ACCOUNT_DOB','false',5,20,NULL,'2019-02-05 19:42:03',NULL,'xtc_cfg_select_option(array(\'true\', \'false\'),'),(84,'ACCOUNT_COMPANY','true',5,30,NULL,'2019-02-05 19:42:03',NULL,'xtc_cfg_select_option(array(\'true\', \'false\'),'),(85,'ACCOUNT_SUBURB','true',5,50,NULL,'2019-02-05 19:42:03',NULL,'xtc_cfg_select_option(array(\'true\', \'false\'),'),(86,'ACCOUNT_STATE','false',5,60,NULL,'2019-02-05 19:42:03',NULL,'xtc_cfg_select_option(array(\'true\', \'false\'),'),(87,'ACCOUNT_TELEPHONE_OPTIONAL','false',5,70,NULL,'2019-02-05 19:42:03',NULL,'xtc_cfg_select_option(array(\'true\', \'false\'),'),(88,'ACCOUNT_OPTIONS','account',5,100,NULL,'2019-02-05 19:42:03',NULL,'xtc_cfg_select_option(array(\'account\', \'guest\', \'both\'),'),(89,'DELETE_GUEST_ACCOUNT','true',5,110,NULL,'2019-02-05 19:42:03',NULL,'xtc_cfg_select_option(array(\'true\', \'false\'),'),(90,'GUEST_ACCOUNT_EDIT','false',5,120,NULL,'2019-02-05 19:42:03',NULL,'xtc_cfg_select_option(array(\'true\', \'false\'),'),(91,'DISPLAY_PRIVACY_CHECK','true',5,130,NULL,'2019-02-05 19:42:03',NULL,'xtc_cfg_select_option(array(\'true\', \'false\'),'),(92,'MODULE_PAYMENT_INSTALLED','',6,0,NULL,'2019-02-05 19:42:03',NULL,NULL),(93,'MODULE_ORDER_TOTAL_INSTALLED','ot_subtotal.php;ot_shipping.php;ot_tax.php;ot_total.php',6,0,NULL,'2019-02-05 19:42:03',NULL,NULL),(94,'MODULE_SHIPPING_INSTALLED','',6,0,NULL,'2019-02-05 19:42:03',NULL,NULL),(95,'DEFAULT_CURRENCY','EUR',6,0,NULL,'2019-02-05 19:42:03',NULL,NULL),(96,'DEFAULT_LANGUAGE','de',6,0,NULL,'2019-02-05 19:42:03',NULL,NULL),(97,'DEFAULT_ORDERS_STATUS_ID','1',6,0,NULL,'2019-02-05 19:42:03',NULL,NULL),(98,'DEFAULT_PRODUCTS_VPE_ID','',6,0,NULL,'2019-02-05 19:42:03',NULL,NULL),(99,'DEFAULT_SHIPPING_STATUS_ID','1',6,0,NULL,'2019-02-05 19:42:03',NULL,NULL),(100,'MODULE_ORDER_TOTAL_SHIPPING_STATUS','true',6,1,NULL,'2019-02-05 19:42:03',NULL,'xtc_cfg_select_option(array(\'true\', \'false\'),'),(101,'MODULE_ORDER_TOTAL_SHIPPING_SORT_ORDER','30',6,2,NULL,'2019-02-05 19:42:03',NULL,NULL),(102,'MODULE_ORDER_TOTAL_SHIPPING_FREE_SHIPPING','false',6,3,NULL,'2019-02-05 19:42:03',NULL,'xtc_cfg_select_option(array(\'true\', \'false\'),'),(103,'MODULE_ORDER_TOTAL_SHIPPING_FREE_SHIPPING_OVER','50',6,4,NULL,'2019-02-05 19:42:03','currencies->format',NULL),(104,'MODULE_ORDER_TOTAL_SHIPPING_FREE_SHIPPING_OVER_INTERNATIONAL','50',6,4,NULL,'2019-02-05 19:42:04','currencies->format',NULL),(105,'MODULE_ORDER_TOTAL_SHIPPING_DESTINATION','national',6,5,NULL,'2019-02-05 19:42:04',NULL,'xtc_cfg_select_option(array(\'national\', \'international\', \'both\'),'),(106,'MODULE_ORDER_TOTAL_SHIPPING_TAX_CLASS','0',6,7,NULL,'2019-02-05 19:42:04','xtc_get_tax_class_title','xtc_cfg_pull_down_tax_classes('),(107,'MODULE_ORDER_TOTAL_SUBTOTAL_STATUS','true',6,1,NULL,'2019-02-05 19:42:04',NULL,'xtc_cfg_select_option(array(\'true\', \'false\'),'),(108,'MODULE_ORDER_TOTAL_SUBTOTAL_SORT_ORDER','10',6,2,NULL,'2019-02-05 19:42:04',NULL,NULL),(109,'MODULE_ORDER_TOTAL_TAX_STATUS','true',6,1,NULL,'2019-02-05 19:42:04',NULL,'xtc_cfg_select_option(array(\'true\', \'false\'),'),(110,'MODULE_ORDER_TOTAL_TAX_SORT_ORDER','50',6,2,NULL,'2019-02-05 19:42:04',NULL,NULL),(111,'MODULE_ORDER_TOTAL_TOTAL_STATUS','true',6,1,NULL,'2019-02-05 19:42:04',NULL,'xtc_cfg_select_option(array(\'true\', \'false\'),'),(112,'MODULE_ORDER_TOTAL_TOTAL_SORT_ORDER','99',6,2,NULL,'2019-02-05 19:42:04',NULL,NULL),(113,'MODULE_ORDER_TOTAL_DISCOUNT_STATUS','true',6,1,NULL,'2019-02-05 19:42:04',NULL,'xtc_cfg_select_option(array(\'true\', \'false\'),'),(114,'MODULE_ORDER_TOTAL_DISCOUNT_SORT_ORDER','20',6,2,NULL,'2019-02-05 19:42:04',NULL,NULL),(115,'MODULE_ORDER_TOTAL_SUBTOTAL_NO_TAX_STATUS','true',6,1,NULL,'2019-02-05 19:42:04',NULL,'xtc_cfg_select_option(array(\'true\', \'false\'),'),(116,'MODULE_ORDER_TOTAL_SUBTOTAL_NO_TAX_SORT_ORDER','40',6,2,NULL,'2019-02-05 19:42:04',NULL,NULL),(117,'NEWSFEED_LAST_READ','',6,100,NULL,'2019-02-05 19:42:04',NULL,NULL),(118,'NEWSFEED_LAST_UPDATE','1549534984',6,100,NULL,'2019-02-05 19:42:04',NULL,NULL),(119,'SESSION_CHECK_SSL_SESSION_ID','False',6,100,NULL,'2019-02-05 19:42:04',NULL,'xtc_cfg_select_option(array(\'True\', \'False\'),'),(120,'SESSION_CHECK_USER_AGENT','False',6,100,NULL,'2019-02-05 19:42:04',NULL,'xtc_cfg_select_option(array(\'True\', \'False\'),'),(121,'SESSION_CHECK_IP_ADDRESS','False',6,100,NULL,'2019-02-05 19:42:04',NULL,'xtc_cfg_select_option(array(\'True\', \'False\'),'),(122,'SHIPPING_MAX_WEIGHT','50',7,3,NULL,'2019-02-05 19:42:04',NULL,NULL),(123,'SHIPPING_BOX_WEIGHT','3',7,4,NULL,'2019-02-05 19:42:04',NULL,NULL),(124,'SHIPPING_BOX_PADDING','10',7,5,NULL,'2019-02-05 19:42:04',NULL,NULL),(125,'SHOW_SHIPPING','true',7,6,NULL,'2019-02-05 19:42:04',NULL,'xtc_cfg_select_option(array(\'true\', \'false\'),'),(126,'SHOW_SHIPPING_EXCL','true',7,6,NULL,'2019-02-05 19:42:04',NULL,'xtc_cfg_select_option(array(\'true\', \'false\'),'),(127,'SHIPPING_INFOS','1',7,7,NULL,'2019-02-05 19:42:04',NULL,'xtc_cfg_select_content(\'SHIPPING_INFOS\','),(128,'CHECK_CHEAPEST_SHIPPING_MODUL','false',7,8,NULL,'2019-02-05 19:42:04',NULL,'xtc_cfg_select_option(array(\'true\', \'false\'),'),(129,'SHOW_SELFPICKUP_FREE','false',7,9,NULL,'2019-02-05 19:42:04',NULL,'xtc_cfg_select_option(array(\'true\', \'false\'),'),(130,'PRODUCT_LIST_FILTER','true',8,1,NULL,'2019-02-05 19:42:04',NULL,'xtc_cfg_select_option(array(\'true\', \'false\'),'),(131,'SHOW_BUTTON_BUY_NOW','false',8,2,NULL,'2019-02-05 19:42:04',NULL,'xtc_cfg_select_option(array(\'true\', \'false\'),'),(132,'EXPECTED_PRODUCTS_SORT','desc',8,4,NULL,'2019-02-05 19:42:04',NULL,'xtc_cfg_select_option(array(\'asc\', \'desc\'),'),(133,'EXPECTED_PRODUCTS_FIELD','date_expected',8,5,NULL,'2019-02-05 19:42:04',NULL,'xtc_cfg_select_option(array(\'products_name\', \'date_expected\'),'),(134,'CATEGORIES_SHOW_PRODUCTS_SUBCATS','false',8,10,NULL,'2019-02-05 19:42:04',NULL,'xtc_cfg_select_option(array(\'true\', \'false\'),'),(135,'DISPLAY_FILTER_INDEX','3,12,27,all',8,100,NULL,'2019-02-05 19:42:04',NULL,NULL),(136,'DISPLAY_FILTER_SPECIALS','3,12,27,all',8,101,NULL,'2019-02-05 19:42:04',NULL,NULL),(137,'DISPLAY_FILTER_PRODUCTS_NEW','3,12,27,all',8,102,NULL,'2019-02-05 19:42:04',NULL,NULL),(138,'DISPLAY_FILTER_ADVANCED_SEARCH_RESULT','4,12,32,all',8,103,NULL,'2019-02-05 19:42:04',NULL,NULL),(139,'STOCK_CHECK','true',9,1,NULL,'2019-02-05 19:42:04',NULL,'xtc_cfg_select_option(array(\'true\', \'false\'),'),(140,'ATTRIBUTE_STOCK_CHECK','true',9,2,NULL,'2019-02-05 19:42:04',NULL,'xtc_cfg_select_option(array(\'true\', \'false\'),'),(141,'STOCK_LIMITED','true',9,3,NULL,'2019-02-05 19:42:04',NULL,'xtc_cfg_select_option(array(\'true\', \'false\'),'),(142,'STOCK_ALLOW_CHECKOUT','true',9,4,NULL,'2019-02-05 19:42:04',NULL,'xtc_cfg_select_option(array(\'true\', \'false\'),'),(143,'STOCK_MARK_PRODUCT_OUT_OF_STOCK','<span style=\"color:red\">***</span>',9,5,NULL,'2019-02-05 19:42:04',NULL,NULL),(144,'STOCK_REORDER_LEVEL','5',9,6,NULL,'2019-02-05 19:42:04',NULL,NULL),(145,'STOCK_CHECKOUT_UPDATE_PRODUCTS_STATUS','false',9,20,NULL,'2019-02-05 19:42:05',NULL,'xtc_cfg_select_option(array(\'true\', \'false\'),'),(146,'STOCK_CHECK_SPECIALS','false',9,21,NULL,'2019-02-05 19:42:05',NULL,'xtc_cfg_select_option(array(\'true\', \'false\'),'),(147,'ATTRIBUTES_VALID_CHECK','true',9,22,NULL,'2019-02-05 19:42:05',NULL,'xtc_cfg_select_option(array(\'true\', \'false\'),'),(148,'STORE_PAGE_PARSE_TIME','false',10,1,NULL,'2019-02-05 19:42:05',NULL,'xtc_cfg_select_option(array(\'true\', \'false\'),'),(149,'STORE_PAGE_PARSE_TIME_THRESHOLD','1.0',10,2,NULL,'2019-02-05 19:42:05',NULL,NULL),(150,'STORE_PARSE_DATE_TIME_FORMAT','%d/%m/%Y %H:%M:%S',10,3,NULL,'2019-02-05 19:42:05',NULL,NULL),(151,'DISPLAY_PAGE_PARSE_TIME','none',10,4,NULL,'2019-02-05 19:42:05',NULL,'xtc_cfg_select_option(array(\'none\', \'admin\', \'all\'),'),(152,'STORE_DB_TRANSACTIONS','false',10,5,NULL,'2019-02-05 19:42:05',NULL,'xtc_cfg_select_option(array(\'true\', \'false\'),'),(153,'STORE_DB_SLOW_QUERY','false',10,6,NULL,'2019-02-05 19:42:05',NULL,'xtc_cfg_select_option(array(\'true\', \'false\'),'),(154,'STORE_DB_SLOW_QUERY_TIME','1.0',10,7,NULL,'2019-02-05 19:42:05',NULL,NULL),(155,'DISPLAY_ERROR_REPORTING','none',10,8,NULL,'2019-02-05 19:42:05',NULL,'xtc_cfg_select_option(array(\'none\', \'admin\', \'all\'),'),(156,'USE_CACHE','false',11,1,NULL,'2019-02-05 19:42:05',NULL,'xtc_cfg_select_option(array(\'true\', \'false\'),'),(157,'DIR_FS_CACHE','cache',11,2,NULL,'2019-02-05 19:42:05',NULL,NULL),(158,'CACHE_LIFETIME','3600',11,3,NULL,'2019-02-05 19:42:05',NULL,NULL),(159,'CACHE_CHECK','true',11,4,NULL,'2019-02-05 19:42:05',NULL,'xtc_cfg_select_option(array(\'true\', \'false\'),'),(160,'DB_CACHE','false',11,5,NULL,'2019-02-05 19:42:05',NULL,'xtc_cfg_select_option(array(\'true\', \'false\'),'),(161,'DB_CACHE_EXPIRE','3600',11,6,NULL,'2019-02-05 19:42:05',NULL,NULL),(162,'DB_CACHE_TYPE','files',11,7,NULL,'2019-02-05 19:42:05',NULL,'xtc_cfg_pull_down_cache_type(\'DB_CACHE_TYPE\','),(163,'EMAIL_TRANSPORT','mail',12,1,NULL,'2019-02-05 19:42:05',NULL,'xtc_cfg_select_option(array(\'sendmail\', \'smtp\', \'mail\'),'),(164,'SENDMAIL_PATH','/usr/sbin/sendmail',12,2,NULL,'2019-02-05 19:42:05',NULL,NULL),(165,'SMTP_MAIN_SERVER','localhost',12,3,NULL,'2019-02-05 19:42:05',NULL,NULL),(166,'SMTP_BACKUP_SERVER','localhost',12,4,NULL,'2019-02-05 19:42:05',NULL,NULL),(167,'SMTP_PORT','25',12,5,NULL,'2019-02-05 19:42:05',NULL,NULL),(168,'SMTP_USERNAME','Please Enter',12,6,NULL,'2019-02-05 19:42:05',NULL,NULL),(169,'SMTP_PASSWORD','Please Enter',12,7,NULL,'2019-02-05 19:42:05',NULL,'xtc_cfg_password_field;SMTP_PASSWORD'),(170,'SMTP_AUTH','false',12,8,NULL,'2019-02-05 19:42:05',NULL,'xtc_cfg_select_option(array(\'true\', \'false\'),'),(171,'SMTP_SECURE','none',12,8,NULL,'2019-02-05 19:42:05',NULL,'xtc_cfg_select_option(array(\'none\', \'ssl\', \'tls\'),'),(172,'SMTP_AUTO_TLS','false',12,8,NULL,'2019-02-05 19:42:05',NULL,'xtc_cfg_select_option(array(\'true\', \'false\'),'),(173,'SMTP_DEBUG','0',12,8,NULL,'2019-02-05 19:42:05',NULL,'xtc_cfg_select_option(array(\'0\', \'1\', \'2\', \'3\', \'4\'),'),(174,'EMAIL_LINEFEED','LF',12,9,NULL,'2019-02-05 19:42:05',NULL,'xtc_cfg_select_option(array(\'LF\', \'CRLF\'),'),(175,'EMAIL_USE_HTML','true',12,10,NULL,'2019-02-05 19:42:05',NULL,'xtc_cfg_select_option(array(\'true\', \'false\'),'),(176,'ENTRY_EMAIL_ADDRESS_CHECK','false',12,11,NULL,'2019-02-05 19:42:05',NULL,'xtc_cfg_select_option(array(\'true\', \'false\'),'),(177,'SEND_EMAILS','true',12,12,NULL,'2019-02-05 19:42:05',NULL,'xtc_cfg_select_option(array(\'true\', \'false\'),'),(178,'EMAIL_SQL_ERRORS','false',12,14,NULL,'2019-02-05 19:42:05',NULL,'xtc_cfg_select_option(array(\'true\', \'false\'),'),(179,'SEND_EMAILS_DOUBLE_OPT_IN','true',12,14,NULL,'2019-02-05 19:42:05',NULL,'xtc_cfg_select_option(array(\'true\', \'false\'),'),(180,'SEND_MAIL_ACCOUNT_CREATED','false',12,14,NULL,'2019-02-05 19:42:05',NULL,'xtc_cfg_select_option(array(\'true\', \'false\'),'),(181,'STATUS_EMAIL_SENT_COPY_TO_ADMIN','false',12,14,NULL,'2019-02-05 19:42:05',NULL,'xtc_cfg_select_option(array(\'true\', \'false\'),'),(182,'EMAIL_WORD_WRAP','50',12,18,NULL,'2019-02-05 19:42:05',NULL,NULL),(183,'EMAIL_SIGNATURE_ID','11',12,19,NULL,'2019-02-05 19:42:05',NULL,'xtc_cfg_select_content(\'EMAIL_SIGNATURE_ID\','),(184,'EMAIL_ARCHIVE_ADDRESS','',12,40,NULL,'2019-02-05 19:42:05',NULL,'xtc_cfg_input_email_language;EMAIL_ARCHIVE_ADDRESS'),(185,'SHOW_IMAGES_IN_EMAIL','false',12,15,NULL,'2019-02-05 19:42:05',NULL,'xtc_cfg_select_option(array(\'true\', \'false\'),'),(186,'SHOW_IMAGES_IN_EMAIL_DIR','thumbnail',12,16,NULL,'2019-02-05 19:42:05',NULL,'xtc_cfg_select_option(array(\'thumbnail\', \'info\'),'),(187,'SHOW_IMAGES_IN_EMAIL_STYLE','max-width:90px;max-height:120px;',12,17,NULL,'2019-02-05 19:42:06',NULL,NULL),(188,'CONTACT_US_EMAIL_ADDRESS','DE::m.foerster@brainsquad.de||EN::m.foerster@brainsquad.de',12,20,NULL,'2019-02-05 19:42:06',NULL,'xtc_cfg_input_email_language;CONTACT_US_EMAIL_ADDRESS'),(189,'CONTACT_US_NAME','DE::Kontaktformular||EN::Contactform',12,21,NULL,'2019-02-05 19:42:06',NULL,'xtc_cfg_input_email_language;CONTACT_US_NAME'),(190,'CONTACT_US_REPLY_ADDRESS','DE::m.foerster@brainsquad.de||EN::m.foerster@brainsquad.de',12,22,NULL,'2019-02-05 19:42:06',NULL,'xtc_cfg_input_email_language;CONTACT_US_REPLY_ADDRESS'),(191,'CONTACT_US_REPLY_ADDRESS_NAME','',12,23,NULL,'2019-02-05 19:42:06',NULL,'xtc_cfg_input_email_language;CONTACT_US_REPLY_ADDRESS_NAME'),(192,'CONTACT_US_EMAIL_SUBJECT','DE::Ihre Anfrage||EN::Your inquiry',12,24,NULL,'2019-02-05 19:42:06',NULL,'xtc_cfg_input_email_language;CONTACT_US_EMAIL_SUBJECT'),(193,'CONTACT_US_FORWARDING_STRING','',12,25,NULL,'2019-02-05 19:42:06',NULL,'xtc_cfg_input_email_language;CONTACT_US_FORWARDING_STRING'),(194,'EMAIL_SUPPORT_ADDRESS','DE::m.foerster@brainsquad.de||EN::m.foerster@brainsquad.de',12,26,NULL,'2019-02-05 19:42:06',NULL,'xtc_cfg_input_email_language;EMAIL_SUPPORT_ADDRESS'),(195,'EMAIL_SUPPORT_NAME','DE::Support System||EN::Support System',12,27,NULL,'2019-02-05 19:42:06',NULL,'xtc_cfg_input_email_language;EMAIL_SUPPORT_NAME'),(196,'EMAIL_SUPPORT_REPLY_ADDRESS','DE::m.foerster@brainsquad.de||EN::m.foerster@brainsquad.de',12,28,NULL,'2019-02-05 19:42:06',NULL,'xtc_cfg_input_email_language;EMAIL_SUPPORT_REPLY_ADDRESS'),(197,'EMAIL_SUPPORT_REPLY_ADDRESS_NAME','',12,29,NULL,'2019-02-05 19:42:06',NULL,'xtc_cfg_input_email_language;EMAIL_SUPPORT_REPLY_ADDRESS_NAME'),(198,'EMAIL_SUPPORT_SUBJECT','DE::Ihr Kundenkonto||EN::Your customer account',12,30,NULL,'2019-02-05 19:42:06',NULL,'xtc_cfg_input_email_language;EMAIL_SUPPORT_SUBJECT'),(199,'EMAIL_SUPPORT_FORWARDING_STRING','',12,31,NULL,'2019-02-05 19:42:06',NULL,'xtc_cfg_input_email_language;EMAIL_SUPPORT_FORWARDING_STRING'),(200,'EMAIL_BILLING_ADDRESS','DE::m.foerster@brainsquad.de||EN::m.foerster@brainsquad.de',12,32,NULL,'2019-02-05 19:42:06',NULL,'xtc_cfg_input_email_language;EMAIL_BILLING_ADDRESS'),(201,'EMAIL_BILLING_NAME','DE::Verrechnungssystem||EN::Billingsystem',12,33,NULL,'2019-02-05 19:42:06',NULL,'xtc_cfg_input_email_language;EMAIL_BILLING_NAME'),(202,'EMAIL_BILLING_REPLY_ADDRESS','DE::m.foerster@brainsquad.de||EN::m.foerster@brainsquad.de',12,34,NULL,'2019-02-05 19:42:06',NULL,'xtc_cfg_input_email_language;EMAIL_BILLING_REPLY_ADDRESS'),(203,'EMAIL_BILLING_REPLY_ADDRESS_NAME','',12,35,NULL,'2019-02-05 19:42:06',NULL,'xtc_cfg_input_email_language;EMAIL_BILLING_REPLY_ADDRESS_NAME'),(204,'EMAIL_BILLING_SUBJECT','DE::Ihre Bestellung||EN::Your order',12,36,NULL,'2019-02-05 19:42:06',NULL,'xtc_cfg_input_email_language;EMAIL_BILLING_SUBJECT'),(205,'EMAIL_BILLING_FORWARDING_STRING','DE::m.foerster@brainsquad.de||EN::m.foerster@brainsquad.de',12,37,NULL,'2019-02-05 19:42:06',NULL,'xtc_cfg_input_email_language;EMAIL_BILLING_FORWARDING_STRING'),(206,'EMAIL_BILLING_SUBJECT_ORDER','DE::Ihre Bestellung {$nr} vom {$date}||EN::Your order {$nr} from {$date}',12,38,NULL,'2019-02-05 19:42:06',NULL,'xtc_cfg_input_email_language;EMAIL_BILLING_SUBJECT_ORDER'),(207,'EMAIL_BILLING_ATTACHMENTS','',12,39,NULL,'2019-02-05 19:42:06',NULL,'xtc_cfg_input_email_language;EMAIL_BILLING_ATTACHMENTS'),(208,'DOWNLOAD_ENABLED','false',13,1,NULL,'2019-02-05 19:42:06',NULL,'xtc_cfg_select_option(array(\'true\', \'false\'),'),(209,'DOWNLOAD_BY_REDIRECT','false',13,2,NULL,'2019-02-05 19:42:06',NULL,'xtc_cfg_select_option(array(\'true\', \'false\'),'),(210,'DOWNLOAD_UNALLOWED_PAYMENT','banktransfer,cod,invoice,moneyorder',13,5,NULL,'2019-02-05 19:42:06',NULL,'xtc_cfg_checkbox_unallowed_module(\'payment\', \'DOWNLOAD_UNALLOWED_PAYMENT\','),(211,'DOWNLOAD_MIN_ORDERS_STATUS','1',13,5,NULL,'2019-02-05 19:42:06',NULL,'xtc_cfg_multi_checkbox(\'xtc_get_orders_status\', \'chr(44)\','),(212,'DOWNLOAD_MULTIPLE_ATTRIBUTES_ALLOWED','false',13,6,NULL,'2019-02-05 19:42:06',NULL,'xtc_cfg_select_option(array(\'true\', \'false\'),'),(213,'DOWNLOAD_SHOW_LANG_DROPDOWN','true',13,7,NULL,'2019-02-05 19:42:06',NULL,'xtc_cfg_select_option(array(\'true\', \'false\'),'),(214,'GZIP_COMPRESSION','false',14,1,NULL,'2019-02-05 19:42:06',NULL,'xtc_cfg_select_option(array(\'true\', \'false\'),'),(215,'GZIP_LEVEL','5',14,2,NULL,'2019-02-05 19:42:06',NULL,NULL),(216,'COMPRESS_HTML_OUTPUT','true',14,3,NULL,'2019-02-05 19:42:06',NULL,'xtc_cfg_select_option(array(\'true\', \'false\'),'),(217,'COMPRESS_STYLESHEET','true',14,4,NULL,'2019-02-05 19:42:06',NULL,'xtc_cfg_select_option(array(\'true\', \'false\'),'),(218,'COMPRESS_JAVASCRIPT','true',14,5,NULL,'2019-02-05 19:42:06',NULL,'xtc_cfg_select_option(array(\'true\', \'false\'),'),(219,'SESSION_WRITE_DIRECTORY','/tmp',15,1,NULL,'2019-02-05 19:42:06',NULL,NULL),(220,'SESSION_FORCE_COOKIE_USE','False',15,2,NULL,'2019-02-05 19:42:06',NULL,'xtc_cfg_select_option(array(\'True\', \'False\'),'),(221,'SESSION_RECREATE','False',15,3,NULL,'2019-02-05 19:42:06',NULL,'xtc_cfg_select_option(array(\'True\', \'False\'),'),(222,'SESSION_LIFE_CUSTOMERS','1440',15,20,NULL,'2019-02-05 19:42:06',NULL,NULL),(223,'SESSION_LIFE_ADMIN','7200',15,21,NULL,'2019-02-05 19:42:06',NULL,NULL),(224,'META_MAX_KEYWORD_LENGTH','18',16,1,NULL,'2019-02-05 19:42:06',NULL,NULL),(225,'META_MIN_KEYWORD_LENGTH','5',16,2,NULL,'2019-02-05 19:42:06',NULL,NULL),(226,'META_KEYWORDS_NUMBER','15',16,3,NULL,'2019-02-05 19:42:06',NULL,NULL),(227,'META_AUTHOR','Fabian Schwarzbauer',16,4,NULL,'2019-02-05 19:42:06',NULL,NULL),(228,'META_PUBLISHER','ascasa Gmbh',16,5,NULL,'2019-02-05 19:42:07',NULL,NULL),(229,'META_COMPANY','ascasa Gmbh',16,6,NULL,'2019-02-05 19:42:07',NULL,NULL),(230,'META_TOPIC','shopping',16,7,NULL,'2019-02-05 19:42:07',NULL,NULL),(231,'META_REPLY_TO','m.foerster@brainsquad.de',16,8,NULL,'2019-02-05 19:42:07',NULL,NULL),(232,'META_REVISIT_AFTER','5',16,9,NULL,'2019-02-05 19:42:07',NULL,NULL),(233,'META_ROBOTS','index,follow',16,10,NULL,'2019-02-05 19:42:07',NULL,NULL),(234,'META_DESCRIPTION','',16,11,NULL,'2019-02-05 19:42:07',NULL,NULL),(235,'META_KEYWORDS','',16,12,NULL,'2019-02-05 19:42:07',NULL,NULL),(236,'SEARCH_ENGINE_FRIENDLY_URLS','true',16,13,'2019-02-07 11:26:29','2019-02-05 19:42:07',NULL,'xtc_cfg_select_option(array(\'true\', \'false\'),'),(237,'SEO_URL_MOD_CLASS','seo_url_shopstat',16,13,NULL,'2019-02-05 19:42:07',NULL,'xtc_cfg_select_mod_seo_url('),(238,'CHECK_CLIENT_AGENT','true',16,14,NULL,'2019-02-05 19:42:07',NULL,'xtc_cfg_select_option(array(\'true\', \'false\'),'),(239,'DISPLAY_BREADCRUMB_OPTION','name',16,15,NULL,'2019-02-05 19:42:07',NULL,'xtc_cfg_select_option(array(\'name\', \'model\'),'),(240,'META_DESCRIPTION_LENGTH','320',16,2,NULL,'2019-02-05 19:42:07',NULL,NULL),(241,'META_PRODUCTS_KEYWORDS_LENGTH','255',16,2,NULL,'2019-02-05 19:42:07',NULL,NULL),(242,'META_KEYWORDS_LENGTH','255',16,2,NULL,'2019-02-05 19:42:07',NULL,NULL),(243,'META_TITLE_LENGTH','70',16,2,NULL,'2019-02-05 19:42:07',NULL,NULL),(244,'META_STOP_WORDS','#german:\r\nab,aber,abgerufen,abgerufene,abgerufener,abgerufenes,acht,alle,allein,allem,allen,aller,allerdings,allerlei,alles,allgemein,allmählich,allzu,als,alsbald,also,am,an,ander,andere,anderem,anderen,anderer,andererseits,anderes,anderm,andern,andernfalls,anders,anerkannt,anerkannte,anerkannter,anerkanntes,anfangen,anfing,angefangen,angesetze,angesetzt,angesetzten,angesetzter,ansetzen,anstatt,arbeiten,auch,auf,aufgehört,aufgrund,aufhören,aufhörte,aufzusuchen,aus,ausdrücken,ausdrückt,ausdrückte,ausgenommen,ausser,ausserdem,author,autor,außen,außer,außerdem,außerhalb,bald,bearbeite,bearbeiten,bearbeitete,bearbeiteten,bedarf,bedurfte,bedürfen,befragen,befragte,befragten,befragter,begann,beginnen,begonnen,behalten,behielt,bei,beide,beiden,beiderlei,beides,beim,beinahe,beitragen,beitrugen,bekannt,bekannte,bekannter,bekennen,benutzt,bereits,berichten,berichtet,berichtete,berichteten,besonders,besser,bestehen,besteht,beträchtlich,bevor,bezüglich,bietet,bin,bis,bisher,bislang,bist,bleiben,blieb,bloss,bloß,brachte,brachten,brauchen,braucht,bringen,bräuchte,bsp.,bzw,böden,ca.,da,dabei,dadurch,dafür,dagegen,daher,dahin,damals,damit,danach,daneben,dank,danke,danken,dann,dannen,daran,darauf,daraus,darf,darfst,darin,darum,darunter,darüber,darüberhinaus,das,dass,dasselbe,davon,davor,dazu,daß,dein,deine,deinem,deinen,deiner,deines,dem,demnach,demselben,den,denen,denn,dennoch,denselben,der,derart,derartig,derem,deren,derer,derjenige,derjenigen,derselbe,derselben,derzeit,des,deshalb,desselben,dessen,desto,deswegen,dich,die,diejenige,dies,diese,dieselbe,dieselben,diesem,diesen,dieser,dieses,diesseits,dinge,dir,direkt,direkte,direkten,direkter,doch,doppelt,dort,dorther,dorthin,drauf,drei,dreißig,drin,dritte,drunter,drüber,du,dunklen,durch,durchaus,durfte,durften,dürfen,dürfte,eben,ebenfalls,ebenso,ehe,eher,eigenen,eigenes,eigentlich,ein,einbaün,eine,einem,einen,einer,einerseits,eines,einfach,einführen,einführte,einführten,eingesetzt,einig,einige,einigem,einigen,einiger,einigermaßen,einiges,einmal,eins,einseitig,einseitige,einseitigen,einseitiger,einst,einstmals,einzig,ende,entsprechend,entweder,er,ergänze,ergänzen,ergänzte,ergänzten,erhalten,erhielt,erhielten,erhält,erneut,erst,erste,ersten,erster,eröffne,eröffnen,eröffnet,eröffnete,eröffnetes,es,etc,etliche,etwa,etwas,euch,euer,eure,eurem,euren,eurer,eures,fall,falls,fand,fast,ferner,finden,findest,findet,folgende,folgenden,folgender,folgendes,folglich,fordern,fordert,forderte,forderten,fortsetzen,fortsetzt,fortsetzte,fortsetzten,fragte,frau,frei,freie,freier,freies,fuer,fünf,für,gab,ganz,ganze,ganzem,ganzen,ganzer,ganzes,gar,gbr,geb,geben,geblieben,gebracht,gedurft,geehrt,geehrte,geehrten,geehrter,gefallen,gefiel,gefälligst,gefällt,gegeben,gegen,gehabt,gehen,geht,gekommen,gekonnt,gemacht,gemocht,gemäss,genommen,genug,gern,gesagt,gesehen,gestern,gestrige,getan,geteilt,geteilte,getragen,gewesen,gewissermaßen,gewollt,geworden,ggf,gib,gibt,gleich,gleichwohl,gleichzeitig,glücklicherweise,gmbh,gratulieren,gratuliert,gratulierte,gute,guten,gängig,gängige,gängigen,gängiger,gängiges,gänzlich,hab,habe,haben,haette,halb,hallo,hast,hat,hatte,hatten,hattest,hattet,heraus,herein,heute,heutige,hier,hiermit,hiesige,hin,hinein,hinten,hinter,hinterher,hoch,hundert,hätt,hätte,hätten,höchstens,ich,igitt,ihm,ihn,ihnen,ihr,ihre,ihrem,ihren,ihrer,ihres,im,immer,immerhin,important,in,indem,indessen,info,infolge,innen,innerhalb,ins,insofern,inzwischen,irgend,irgendeine,irgendwas,irgendwen,irgendwer,irgendwie,irgendwo,ist,ja,je,jede,jedem,jeden,jedenfalls,jeder,jederlei,jedes,jedoch,jemand,jene,jenem,jenen,jener,jenes,jenseits,jetzt,jährig,jährige,jährigen,jähriges,kam,kann,kannst,kaum,kein,keine,keinem,keinen,keiner,keinerlei,keines,keineswegs,klar,klare,klaren,klares,klein,kleinen,kleiner,kleines,koennen,koennt,koennte,koennten,komme,kommen,kommt,konkret,konkrete,konkreten,konkreter,konkretes,konnte,konnten,könn,können,könnt,könnte,könnten,künftig,lag,lagen,langsam,lassen,laut,lediglich,leer,legen,legte,legten,leicht,leider,lesen,letze,letzten,letztendlich,letztens,letztes,letztlich,lichten,liegt,liest,links,längst,längstens,mache,machen,machst,macht,machte,machten,mag,magst,mal,man,manche,manchem,manchen,mancher,mancherorts,manches,manchmal,mann,margin,mehr,mehrere,mein,meine,meinem,meinen,meiner,meines,meist,meiste,meisten,meta,mich,mindestens,mir,mit,mithin,mochte,morgen,morgige,muessen,muesst,muesste,muss,musst,musste,mussten,muß,mußt,möchte,möchten,möchtest,mögen,möglich,mögliche,möglichen,möglicher,möglicherweise,müssen,müsste,müssten,müßt,müßte,nach,nachdem,nacher,nachhinein,nacht,nahm,natürlich,neben,nebenan,nehmen,nein,neu,neue,neuem,neuen,neuer,neues,neun,nicht,nichts,nie,niemals,niemand,nimm,nimmer,nimmt,nirgends,nirgendwo,noch,nun,nur,nutzen,nutzt,nutzung,nächste,nämlich,nötigenfalls,nützt,ob,oben,oberhalb,obgleich,obschon,obwohl,oder,oft,ohne,per,pfui,plötzlich,pro,reagiere,reagieren,reagiert,reagierte,rechts,regelmäßig,rief,rund,sage,sagen,sagt,sagte,sagten,sagtest,sang,sangen,schlechter,schließlich,schnell,schon,schreibe,schreiben,schreibens,schreiber,schwierig,schätzen,schätzt,schätzte,schätzten,sechs,sect,sehe,sehen,sehr,sehrwohl,seht,sei,seid,sein,seine,seinem,seinen,seiner,seines,seit,seitdem,seite,seiten,seither,selber,selbst,senke,senken,senkt,senkte,senkten,setzen,setzt,setzte,setzten,sich,sicher,sicherlich,sie,sieben,siebte,siehe,sieht,sind,singen,singt,so,sobald,sodaß,soeben,sofern,sofort,sog,sogar,solange,solch,solche,solchem,solchen,solcher,solches,soll,sollen,sollst,sollt,sollte,sollten,solltest,somit,sondern,sonst,sonstwo,sooft,soviel,soweit,sowie,sowohl,spielen,später,startet,startete,starteten,statt,stattdessen,steht,steige,steigen,steigt,stets,stieg,stiegen,such,suchen,sämtliche,tages,tat,tatsächlich,tatsächlichen,tatsächlicher,tatsächliches,tausend,teile,teilen,teilte,teilten,titel,total,trage,tragen,trotzdem,trug,trägt,tun,tust,tut,txt,tät,ueber,um,umso,unbedingt,und,ungefähr,unmöglich,unmögliche,unmöglichen,unmöglicher,unnötig,uns,unse,unsem,unsen,unser,unsere,unserem,unseren,unserer,unseres,unserm,unses,unten,unter,unterbrach,unterbrechen,unterhalb,unwichtig,usw,vergangen,vergangene,vergangener,vergangenes,vermag,vermutlich,vermögen,verrate,verraten,verriet,verrieten,version,versorge,versorgen,versorgt,versorgte,versorgten,versorgtes,veröffentlichen,veröffentlicher,veröffentlicht,veröffentlichte,veröffentlichten,veröffentlichtes,viel,viele,vielen,vieler,vieles,vielleicht,vielmals,vier,vollständig,vom,von,vor,voran,vorbei,vorgestern,vorher,vorne,vorüber,völlig,wachen,waere,wann,war,waren,warst,warum,was,weder,weg,wegen,weil,weiter,weitere,weiterem,weiteren,weiterer,weiteres,weiterhin,weiß,welche,welchem,welchen,welcher,welches,wem,wen,wenig,wenige,weniger,wenigstens,wenn,wenngleich,wer,werde,werden,werdet,weshalb,wessen,wichtig,wie,wieder,wieso,wieviel,wiewohl,will,willst,wir,wird,wirklich,wirst,wo,wodurch,wogegen,woher,wohin,wohingegen,wohl,wohlweislich,wolle,wollen,wollt,wollte,wollten,wolltest,wolltet,womit,woraufhin,woraus,worin,wurde,wurden,während,währenddessen,wär,wäre,wären,würde,würden,z.B.,zahlreich,zehn,zeitweise,ziehen,zieht,zog,zogen,zu,zudem,zuerst,zufolge,zugleich,zuletzt,zum,zumal,zur,zurück,zusammen,zuviel,zwanzig,zwar,zwei,zwischen,zwölf,ähnlich,übel,über,überall,überallhin,überdies,übermorgen,übrig,übrigens\r\n\r\n#english:\r\na\\\'s,able,about,above,abroad,according,accordingly,across,actually,adj,after,afterwards,again,against,ago,ahead,ain\\\'t,all,allow,allows,almost,alone,along,alongside,already,also,although,always,am,amid,amidst,among,amongst,an,and,another,any,anybody,anyhow,anyone,anything,anyway,anyways,anywhere,apart,appear,appreciate,appropriate,are,aren\\\'t,around,as,aside,ask,asking,associated,at,available,away,awfully,back,backward,backwards,be,became,because,become,becomes,becoming,been,before,beforehand,begin,behind,being,believe,below,beside,besides,best,better,between,beyond,both,brief,but,by,c\\\'mon,c\\\'s,came,can,can\\\'t,cannot,cant,caption,cause,causes,certain,certainly,changes,clearly,co,co.,com,come,comes,concerning,consequently,consider,considering,contain,containing,contains,corresponding,could,couldn\\\'t,course,currently,dare,daren\\\'t,definitely,described,despite,did,didn\\\'t,different,directly,do,does,doesn\\\'t,doing,don\\\'t,done,down,downwards,during,each,edu,eg,eight,eighty,either,else,elsewhere,end,ending,enough,entirely,especially,et,etc,even,ever,evermore,every,everybody,everyone,everything,everywhere,ex,exactly,example,except,fairly,far,farther,few,fewer,fifth,first,five,followed,following,follows,for,forever,former,formerly,forth,forward,found,four,from,further,furthermore,get,gets,getting,given,gives,go,goes,going,gone,got,gotten,greetings,had,hadn\\\'t,half,happens,hardly,has,hasn\\\'t,have,haven\\\'t,having,he,he\\\'d,he\\\'ll,he\\\'s,hello,help,hence,her,here,here\\\'s,hereafter,hereby,herein,hereupon,hers,herself,hi,him,himself,his,hither,hopefully,how,howbeit,however,hundred,i\\\'d,i\\\'ll,i\\\'m,i\\\'ve,ie,if,ignored,immediate,in,inasmuch,inc,inc.,indeed,indicate,indicated,indicates,inner,inside,insofar,instead,into,inward,is,isn\\\'t,it,it\\\'d,it\\\'ll,it\\\'s,its,itself,just,k,keep,keeps,kept,know,known,knows,last,lately,later,latter,latterly,least,less,lest,let,let\\\'s,like,liked,likely,likewise,little,look,looking,looks,low,lower,ltd,made,mainly,make,makes,many,may,maybe,mayn\\\'t,me,mean,meantime,meanwhile,merely,might,mightn\\\'t,mine,minus,miss,more,moreover,most,mostly,mr,mrs,much,must,mustn\\\'t,my,myself,name,namely,nd,near,nearly,necessary,need,needn\\\'t,needs,neither,never,neverf,neverless,nevertheless,new,next,nine,ninety,no,no-one,nobody,non,none,nonetheless,noone,nor,normally,not,nothing,notwithstanding,novel,now,nowhere,obviously,of,off,often,oh,ok,okay,old,on,once,one,one\\\'s,ones,only,onto,opposite,or,other,others,otherwise,ought,oughtn\\\'t,our,ours,ourselves,out,outside,over,overall,own,particular,particularly,past,per,perhaps,placed,please,plus,possible,presumably,probably,provided,provides,que,quite,qv,rather,rd,re,really,reasonably,recent,recently,regarding,regardless,regards,relatively,respectively,right,round,said,same,saw,say,saying,says,second,secondly,see,seeing,seem,seemed,seeming,seems,seen,self,selves,sensible,sent,serious,seriously,seven,several,shall,shan\\\'t,she,she\\\'d,she\\\'ll,she\\\'s,should,shouldn\\\'t,since,six,so,some,somebody,someday,somehow,someone,something,sometime,sometimes,somewhat,somewhere,soon,sorry,specified,specify,specifying,still,sub,such,sup,sure,t\\\'s,take,taken,taking,tell,tends,th,than,thank,thanks,thanx,that,that\\\'ll,that\\\'s,that\\\'ve,thats,the,their,theirs,them,themselves,then,thence,there,there\\\'d,there\\\'ll,there\\\'re,there\\\'s,there\\\'ve,thereafter,thereby,therefore,therein,theres,thereupon,these,they,they\\\'d,they\\\'ll,they\\\'re,they\\\'ve,thing,things,think,third,thirty,this,thorough,thoroughly,those,though,three,through,throughout,thru,thus,till,to,together,too,took,toward,towards,tried,tries,truly,try,trying,twice,two,un,under,underneath,undoing,unfortunately,unless,unlike,unlikely,until,unto,up,upon,upwards,us,use,used,useful,uses,using,usually,v,value,various,versus,very,via,viz,vs,want,wants,was,wasn\\\'t,way,we,we\\\'d,we\\\'ll,we\\\'re,we\\\'ve,welcome,well,went,were,weren\\\'t,what,what\\\'ll,what\\\'s,what\\\'ve,whatever,when,whence,whenever,where,where\\\'s,whereafter,whereas,whereby,wherein,whereupon,wherever,whether,which,whichever,while,whilst,whither,who,who\\\'d,who\\\'ll,who\\\'s,whoever,whole,whom,whomever,whose,why,will,willing,wish,with,within,without,won\\\'t,wonder,would,wouldn\\\'t,yes,yet,you,you\\\'d,you\\\'ll,you\\\'re,you\\\'ve,your,yours,yourself,yourselves,zero',16,16,'2019-02-07 11:26:29','2019-02-05 19:42:07',NULL,'xtc_cfg_textarea('),(245,'META_GO_WORDS','',16,17,NULL,'2019-02-05 19:42:07',NULL,'xtc_cfg_textarea('),(246,'META_CAT_SHOP_TITLE','false',16,18,NULL,'2019-02-05 19:42:07',NULL,'xtc_cfg_select_option(array(\'true\', \'false\'),'),(247,'META_PROD_SHOP_TITLE','false',16,19,NULL,'2019-02-05 19:42:07',NULL,'xtc_cfg_select_option(array(\'true\', \'false\'),'),(248,'META_CONTENT_SHOP_TITLE','false',16,20,NULL,'2019-02-05 19:42:07',NULL,'xtc_cfg_select_option(array(\'true\', \'false\'),'),(249,'META_SPECIALS_SHOP_TITLE','false',16,21,NULL,'2019-02-05 19:42:07',NULL,'xtc_cfg_select_option(array(\'true\', \'false\'),'),(250,'META_NEWS_SHOP_TITLE','false',16,22,NULL,'2019-02-05 19:42:07',NULL,'xtc_cfg_select_option(array(\'true\', \'false\'),'),(251,'META_SEARCH_SHOP_TITLE','false',16,23,NULL,'2019-02-05 19:42:07',NULL,'xtc_cfg_select_option(array(\'true\', \'false\'),'),(252,'META_OTHER_SHOP_TITLE','false',16,24,NULL,'2019-02-05 19:42:07',NULL,'xtc_cfg_select_option(array(\'true\', \'false\'),'),(253,'META_GOOGLE_VERIFICATION_KEY','',16,25,NULL,'2019-02-05 19:42:07',NULL,NULL),(254,'META_BING_VERIFICATION_KEY','',16,26,NULL,'2019-02-05 19:42:07',NULL,NULL),(255,'USE_WYSIWYG','true',17,1,NULL,'2019-02-05 19:42:07',NULL,'xtc_cfg_select_option(array(\'true\', \'false\'),'),(256,'WYSIWYG_SKIN','moonocolor',17,1,NULL,'2019-02-05 19:42:07',NULL,'xtc_cfg_select_option(array(\'moono\', \'moonocolor\'),'),(257,'ACTIVATE_GIFT_SYSTEM','false',17,2,NULL,'2019-02-05 19:42:07',NULL,'xtc_cfg_select_option(array(\'true\', \'false\'),'),(258,'SECURITY_CODE_LENGTH','10',17,3,NULL,'2019-02-05 19:42:07',NULL,NULL),(259,'NEW_SIGNUP_GIFT_VOUCHER_AMOUNT','0',17,4,NULL,'2019-02-05 19:42:07',NULL,NULL),(260,'NEW_SIGNUP_DISCOUNT_COUPON','',17,5,NULL,'2019-02-05 19:42:07',NULL,NULL),(261,'ACTIVATE_SHIPPING_STATUS','true',17,6,NULL,'2019-02-05 19:42:07',NULL,'xtc_cfg_select_option(array(\'true\', \'false\'),'),(262,'DISPLAY_CONDITIONS_ON_CHECKOUT','false',17,7,NULL,'2019-02-05 19:42:07',NULL,'xtc_cfg_select_option(array(\'true\', \'false\'),'),(263,'SHOW_IP_LOG','false',17,8,NULL,'2019-02-05 19:42:07',NULL,'xtc_cfg_select_option(array(\'true\', \'false\'),'),(264,'SAVE_IP_LOG','false',17,8,NULL,'2019-02-05 19:42:07',NULL,'xtc_cfg_select_option(array(\'true\', \'false\', \'xxx\'),'),(265,'DISPLAY_HEADQUARTER_ON_CHECKOUT','true',17,8,NULL,'2019-02-05 19:42:07',NULL,'xtc_cfg_select_option(array(\'true\', \'false\'),'),(266,'GROUP_CHECK','false',17,9,NULL,'2019-02-05 19:42:07',NULL,'xtc_cfg_select_option(array(\'true\', \'false\'),'),(267,'MODULE_SMALL_BUSINESS','false',17,9,NULL,'2019-02-05 19:42:07',NULL,'xtc_cfg_select_option(array(\'true\', \'false\'),'),(268,'ACTIVATE_NAVIGATOR','false',17,10,NULL,'2019-02-05 19:42:07',NULL,'xtc_cfg_select_option(array(\'true\', \'false\'),'),(269,'QUICKLINK_ACTIVATED','true',17,11,NULL,'2019-02-05 19:42:07',NULL,'xtc_cfg_select_option(array(\'true\', \'false\'),'),(270,'ACTIVATE_REVERSE_CROSS_SELLING','true',17,12,NULL,'2019-02-05 19:42:08',NULL,'xtc_cfg_select_option(array(\'true\', \'false\'),'),(271,'DISPLAY_REVOCATION_ON_CHECKOUT','true',17,13,NULL,'2019-02-05 19:42:08',NULL,'xtc_cfg_select_option(array(\'true\', \'false\'),'),(272,'DISPLAY_REVOCATION_VIRTUAL_ON_CHECKOUT','false',17,13,NULL,'2019-02-05 19:42:08',NULL,'xtc_cfg_select_option(array(\'true\', \'false\'),'),(273,'REVOCATION_ID','9',17,14,NULL,'2019-02-05 19:42:08',NULL,'xtc_cfg_select_content(\'REVOCATION_ID\','),(274,'SHIPPING_STATUS_INFOS','10',17,14,NULL,'2019-02-05 19:42:08',NULL,'xtc_cfg_select_content(\'SHIPPING_STATUS_INFOS\','),(275,'GOOGLE_RSS_FEED_REFID','',17,15,NULL,'2019-02-05 19:42:08',NULL,NULL),(276,'CHECK_FIRST_PAYMENT_MODUL','false',17,16,NULL,'2019-02-05 19:42:08',NULL,'xtc_cfg_select_option(array(\'true\', \'false\'),'),(277,'INVOICE_INFOS','12',17,17,NULL,'2019-02-05 19:42:08',NULL,'xtc_cfg_select_content(\'INVOICE_INFOS\','),(278,'MODULE_BANNER_MANAGER_STATUS','true',17,18,NULL,'2019-02-05 19:42:08',NULL,'xtc_cfg_select_option(array(\'true\', \'false\'),'),(279,'MODULE_NEWSLETTER_STATUS','true',17,19,NULL,'2019-02-05 19:42:08',NULL,'xtc_cfg_select_option(array(\'true\', \'false\'),'),(280,'MODULE_NEWSLETTER_VOUCHER_AMOUNT','0',17,20,NULL,'2019-02-05 19:42:08',NULL,NULL),(281,'MODULE_NEWSLETTER_DISCOUNT_COUPON','',17,21,NULL,'2019-02-05 19:42:08',NULL,NULL),(282,'ACCOUNT_COMPANY_VAT_CHECK','true',18,4,NULL,'2019-02-05 19:42:08',NULL,'xtc_cfg_select_option(array(\'true\', \'false\'),'),(283,'STORE_OWNER_VAT_ID','',18,3,NULL,'2019-02-05 19:42:08',NULL,NULL),(284,'DEFAULT_CUSTOMERS_VAT_STATUS_ID','4',18,23,NULL,'2019-02-05 19:42:08','xtc_get_customers_status_name','xtc_cfg_pull_down_customers_status_list('),(285,'ACCOUNT_COMPANY_VAT_LIVE_CHECK','true',18,4,NULL,'2019-02-05 19:42:08',NULL,'xtc_cfg_select_option(array(\'true\', \'false\'),'),(286,'ACCOUNT_COMPANY_VAT_GROUP','true',18,4,NULL,'2019-02-05 19:42:08',NULL,'xtc_cfg_select_option(array(\'true\', \'false\'),'),(287,'ACCOUNT_VAT_BLOCK_ERROR','true',18,4,NULL,'2019-02-05 19:42:08',NULL,'xtc_cfg_select_option(array(\'true\', \'false\'),'),(288,'DEFAULT_CUSTOMERS_VAT_STATUS_ID_LOCAL','3',18,24,NULL,'2019-02-05 19:42:08','xtc_get_customers_status_name','xtc_cfg_pull_down_customers_status_list('),(289,'GOOGLE_CONVERSION_ID','',19,2,NULL,'2019-02-05 19:42:08',NULL,NULL),(290,'GOOGLE_LANG','de',19,3,NULL,'2019-02-05 19:42:08',NULL,NULL),(291,'GOOGLE_CONVERSION','false',19,0,NULL,'2019-02-05 19:42:08',NULL,'xtc_cfg_select_option(array(\'true\', \'false\'),'),(292,'GOOGLE_CONVERSION_LABEL','Purchase',19,4,NULL,'2019-02-05 19:42:08',NULL,NULL),(293,'CSV_TEXTSIGN','\"',20,1,NULL,'2019-02-05 19:42:08',NULL,NULL),(294,'CSV_SEPERATOR',';',20,2,NULL,'2019-02-05 19:42:08',NULL,NULL),(295,'COMPRESS_EXPORT','false',20,3,NULL,'2019-02-05 19:42:08',NULL,'xtc_cfg_select_option(array(\'true\', \'false\'),'),(296,'CSV_CATEGORY_DEFAULT','0',20,4,NULL,'2019-02-05 19:42:08',NULL,'xtc_cfg_get_category_tree('),(297,'CSV_CAT_DEPTH','4',20,5,NULL,'2019-02-05 19:42:08',NULL,NULL),(298,'AFTERBUY_PARTNERID','',21,2,NULL,'2019-02-05 19:42:08',NULL,NULL),(299,'AFTERBUY_PARTNERPASS','',21,3,NULL,'2019-02-05 19:42:08',NULL,NULL),(300,'AFTERBUY_USERID','',21,4,NULL,'2019-02-05 19:42:08',NULL,NULL),(301,'AFTERBUY_ORDERSTATUS','1',21,5,NULL,'2019-02-05 19:42:08','xtc_get_order_status_name','xtc_cfg_pull_down_order_statuses('),(302,'AFTERBUY_ACTIVATED','false',21,6,NULL,'2019-02-05 19:42:08',NULL,'xtc_cfg_select_option(array(\'true\', \'false\'),'),(303,'SEARCH_IN_DESC','true',22,2,NULL,'2019-02-05 19:42:08',NULL,'xtc_cfg_select_option(array(\'true\', \'false\'),'),(304,'SEARCH_IN_ATTR','true',22,3,NULL,'2019-02-05 19:42:08',NULL,'xtc_cfg_select_option(array(\'true\', \'false\'),'),(305,'ADVANCED_SEARCH_DEFAULT_OPERATOR','and',22,4,NULL,'2019-02-05 19:42:08',NULL,'xtc_cfg_select_option(array(\'and\', \'or\'),'),(306,'SEARCH_IN_MANU','true',22,4,NULL,'2019-02-05 19:42:08',NULL,'xtc_cfg_select_option(array(\'true\', \'false\'),'),(307,'SEARCH_IN_FILTER','true',22,5,NULL,'2019-02-05 19:42:08',NULL,'xtc_cfg_select_option(array(\'true\', \'false\'),'),(308,'SEARCH_AC_STATUS','true',22,10,NULL,'2019-02-05 19:42:08',NULL,'xtc_cfg_select_option(array(\'true\', \'false\'),'),(309,'SEARCH_AC_MIN_LENGTH','3',22,11,NULL,'2019-02-05 19:42:08',NULL,NULL),(310,'TRACKING_ECONDA_ACTIVE','false',23,1,NULL,'2019-02-05 19:42:08',NULL,'xtc_cfg_select_option(array(\'true\', \'false\'),'),(311,'TRACKING_ECONDA_ID','',23,2,NULL,'2019-02-05 19:42:09',NULL,NULL),(312,'TRACKING_COUNT_ADMIN_ACTIVE','false',24,1,NULL,'2019-02-05 19:42:09',NULL,'xtc_cfg_select_option(array(\'true\', \'false\'),'),(313,'TRACKING_GOOGLEANALYTICS_ACTIVE','false',24,2,NULL,'2019-02-05 19:42:09',NULL,'xtc_cfg_select_option(array(\'true\', \'false\'),'),(314,'TRACKING_GOOGLEANALYTICS_ID','UA-XXXXXXX-X',24,3,NULL,'2019-02-05 19:42:09',NULL,NULL),(315,'TRACKING_GOOGLEANALYTICS_UNIVERSAL','false',24,3,NULL,'2019-02-05 19:42:09',NULL,'xtc_cfg_select_option(array(\'true\', \'false\'),'),(316,'TRACKING_GOOGLEANALYTICS_DOMAIN','auto',24,3,NULL,'2019-02-05 19:42:09',NULL,NULL),(317,'TRACKING_GOOGLE_LINKID','false',24,3,NULL,'2019-02-05 19:42:09',NULL,'xtc_cfg_select_option(array(\'true\', \'false\'),'),(318,'TRACKING_GOOGLE_DISPLAY','false',24,3,NULL,'2019-02-05 19:42:09',NULL,'xtc_cfg_select_option(array(\'true\', \'false\'),'),(319,'TRACKING_GOOGLE_ECOMMERCE','false',24,3,NULL,'2019-02-05 19:42:09',NULL,'xtc_cfg_select_option(array(\'true\', \'false\'),'),(320,'TRACKING_PIWIK_ACTIVE','false',24,4,NULL,'2019-02-05 19:42:09',NULL,'xtc_cfg_select_option(array(\'true\', \'false\'),'),(321,'TRACKING_PIWIK_LOCAL_PATH','www.domain.de/piwik',24,5,NULL,'2019-02-05 19:42:09',NULL,NULL),(322,'TRACKING_PIWIK_ID','1',24,6,NULL,'2019-02-05 19:42:09',NULL,NULL),(323,'TRACKING_PIWIK_GOAL','1',24,7,NULL,'2019-02-05 19:42:09',NULL,NULL),(324,'TRACKING_FACEBOOK_ACTIVE','false',24,8,NULL,'2019-02-05 19:42:09',NULL,'xtc_cfg_select_option(array(\'true\', \'false\'),'),(325,'TRACKING_FACEBOOK_ID','',24,9,NULL,'2019-02-05 19:42:09',NULL,NULL),(326,'GOOGLE_CERTIFIED_SHOPS_MERCHANT_ACTIVE','false',24,10,NULL,'2019-02-05 19:42:09',NULL,'xtc_cfg_select_option(array(\'true\', \'false\'),'),(327,'GOOGLE_SHOPPING_ID','',24,11,NULL,'2019-02-05 19:42:09',NULL,NULL),(328,'GOOGLE_TRUSTED_ID','',24,12,NULL,'2019-02-05 19:42:09',NULL,NULL),(329,'MODULE_CAPTCHA_ACTIVE','newsletter,contact,password',25,1,NULL,'2019-02-05 19:42:09',NULL,'xtc_cfg_multi_checkbox(array(\'newsletter\' => \'Newsletter\', \'contact\' => \'Contact\', \'password\' => \'Password\', \'reviews\' => \'Reviews\', \'create_account\' => \'Registration\'), \',\','),(330,'MODULE_CAPTCHA_LOGGED_IN','False',25,2,NULL,'2019-02-05 19:42:09',NULL,'xtc_cfg_select_option(array(\'True\', \'False\'),'),(331,'MODULE_CAPTCHA_USE_COLOR','True',25,10,NULL,'2019-02-05 19:42:09',NULL,'xtc_cfg_select_option(array(\'True\', \'False\'),'),(332,'MODULE_CAPTCHA_USE_SHADOW','False',25,11,NULL,'2019-02-05 19:42:09',NULL,'xtc_cfg_select_option(array(\'True\', \'False\'),'),(333,'MODULE_CAPTCHA_CODE_LENGTH','6',25,12,NULL,'2019-02-05 19:42:09',NULL,NULL),(334,'MODULE_CAPTCHA_NUM_LINES','70',25,13,NULL,'2019-02-05 19:42:09',NULL,NULL),(335,'MODULE_CAPTCHA_MIN_FONT','24',25,14,NULL,'2019-02-05 19:42:09',NULL,NULL),(336,'MODULE_CAPTCHA_MAX_FONT','28',25,15,NULL,'2019-02-05 19:42:09',NULL,NULL),(337,'MODULE_CAPTCHA_BACKGROUND_RGB','192,192,192',25,16,NULL,'2019-02-05 19:42:09',NULL,NULL),(338,'MODULE_CAPTCHA_LINES_RGB','220,148,002',25,17,NULL,'2019-02-05 19:42:09',NULL,NULL),(339,'MODULE_CAPTCHA_CHARS_RGB','112,112,112',25,18,NULL,'2019-02-05 19:42:09',NULL,NULL),(340,'MODULE_CAPTCHA_WIDTH','240',25,19,NULL,'2019-02-05 19:42:09',NULL,NULL),(341,'MODULE_CAPTCHA_HEIGHT','50',25,20,NULL,'2019-02-05 19:42:09',NULL,NULL),(342,'_PAYMENT_MONEYBOOKERS_EMAILID','',31,1,NULL,'2019-02-05 19:42:09',NULL,NULL),(343,'_PAYMENT_MONEYBOOKERS_PWD','',31,2,NULL,'2019-02-05 19:42:09',NULL,NULL),(344,'_PAYMENT_MONEYBOOKERS_MERCHANTID','',31,3,NULL,'2019-02-05 19:42:09',NULL,NULL),(345,'_PAYMENT_MONEYBOOKERS_TMP_STATUS_ID','0',31,4,NULL,'2019-02-05 19:42:09','xtc_get_order_status_name','xtc_cfg_pull_down_order_statuses('),(346,'_PAYMENT_MONEYBOOKERS_PROCESSED_STATUS_ID','0',31,5,NULL,'2019-02-05 19:42:09','xtc_get_order_status_name','xtc_cfg_pull_down_order_statuses('),(347,'_PAYMENT_MONEYBOOKERS_PENDING_STATUS_ID','0',31,6,NULL,'2019-02-05 19:42:09','xtc_get_order_status_name','xtc_cfg_pull_down_order_statuses('),(348,'_PAYMENT_MONEYBOOKERS_CANCELED_STATUS_ID','0',31,7,NULL,'2019-02-05 19:42:09','xtc_get_order_status_name','xtc_cfg_pull_down_order_statuses('),(349,'POPUP_SHIPPING_LINK_PARAMETERS','&KeepThis=true&TB_iframe=true&height=400&width=600',40,10,NULL,'2019-02-05 19:42:09',NULL,NULL),(350,'POPUP_SHIPPING_LINK_CLASS','thickbox',40,11,NULL,'2019-02-05 19:42:09',NULL,NULL),(351,'POPUP_CONTENT_LINK_PARAMETERS','&KeepThis=true&TB_iframe=true&height=400&width=600',40,20,NULL,'2019-02-05 19:42:09',NULL,NULL),(352,'POPUP_CONTENT_LINK_CLASS','thickbox',40,21,NULL,'2019-02-05 19:42:09',NULL,NULL),(353,'POPUP_PRODUCT_LINK_PARAMETERS','&KeepThis=true&TB_iframe=true&height=450&width=750',40,30,NULL,'2019-02-05 19:42:10',NULL,NULL),(354,'POPUP_PRODUCT_LINK_CLASS','thickbox',40,31,NULL,'2019-02-05 19:42:10',NULL,NULL),(355,'POPUP_COUPON_HELP_LINK_PARAMETERS','&KeepThis=true&TB_iframe=true&height=400&width=600',40,40,NULL,'2019-02-05 19:42:10',NULL,NULL),(356,'POPUP_COUPON_HELP_LINK_CLASS','thickbox',40,41,NULL,'2019-02-05 19:42:10',NULL,NULL),(357,'POPUP_PRODUCT_PRINT_SIZE','width=640, height=600',40,60,NULL,'2019-02-05 19:42:10',NULL,NULL),(358,'POPUP_PRINT_ORDER_SIZE','width=640, height=600',40,70,NULL,'2019-02-05 19:42:10',NULL,NULL),(359,'PRICE_IS_BRUTTO','false',1000,10,NULL,'2019-02-05 19:42:10',NULL,'xtc_cfg_select_option(array(\'true\', \'false\'),'),(360,'PRICE_PRECISION','4',1000,11,NULL,'2019-02-05 19:42:10',NULL,NULL),(361,'USE_ADMIN_TOP_MENU','true',1000,20,NULL,'2019-02-05 19:42:10',NULL,'xtc_cfg_select_option(array(\'true\', \'false\'),'),(362,'USE_ADMIN_LANG_TABS','true',1000,26,NULL,'2019-02-05 19:42:10',NULL,'xtc_cfg_select_option(array(\'true\', \'false\'),'),(363,'MAX_DISPLAY_ORDER_RESULTS','30',1000,30,NULL,'2019-02-05 19:42:10',NULL,NULL),(364,'USE_ADMIN_THUMBS_IN_LIST','true',1000,32,NULL,'2019-02-05 19:42:10',NULL,'xtc_cfg_select_option(array(\'true\', \'false\'),'),(365,'USE_ADMIN_THUMBS_IN_LIST_STYLE','max-width:40px;max-height:40px;',1000,33,NULL,'2019-02-05 19:42:10',NULL,NULL),(366,'MAX_DISPLAY_LIST_PRODUCTS','50',1000,51,NULL,'2019-02-05 19:42:10',NULL,NULL),(367,'MAX_DISPLAY_LIST_CUSTOMERS','100',1000,52,NULL,'2019-02-05 19:42:10',NULL,NULL),(368,'MAX_ROW_LISTS_ATTR_OPTIONS','10',1000,53,NULL,'2019-02-05 19:42:10',NULL,NULL),(369,'MAX_ROW_LISTS_ATTR_VALUES','50',1000,54,NULL,'2019-02-05 19:42:10',NULL,NULL),(370,'WHOS_ONLINE_TIME_LAST_CLICK','900',1000,60,NULL,'2019-02-05 19:42:10',NULL,NULL),(371,'WHOS_ONLINE_IP_WHOIS_SERVICE','http://www.utrace.de/?query=',1000,62,NULL,'2019-02-05 19:42:10',NULL,NULL),(372,'CONFIRM_SAVE_ENTRY','true',1000,70,NULL,'2019-02-05 19:42:10',NULL,'xtc_cfg_select_option(array(\'true\', \'false\'),'),(373,'USE_ADMIN_FIXED_TOP','true',1000,23,NULL,'2019-02-05 19:42:10',NULL,'xtc_cfg_select_option(array(\'true\', \'false\'),'),(374,'USE_ADMIN_FIXED_SEARCH','false',1000,24,NULL,'2019-02-05 19:42:10',NULL,'xtc_cfg_select_option(array(\'true\', \'false\'),'),(375,'MAX_DISPLAY_STATS_RESULTS','30',1000,55,NULL,'2019-02-05 19:42:10',NULL,NULL),(376,'MAX_DISPLAY_COUPON_RESULTS','30',1000,56,NULL,'2019-02-05 19:42:10',NULL,NULL),(377,'ORDER_STATUSES_DISPLAY_DEFAULT','',1000,90,NULL,'2019-02-05 19:42:10',NULL,'xtc_cfg_multi_checkbox(\'order_statuses\', \',\','),(378,'ORDER_STATUSES_FOR_SALES_STATISTICS','3',1000,100,NULL,'2019-02-05 19:42:10',NULL,'xtc_cfg_multi_checkbox(\'order_statuses\', \',\','),(379,'MIN_GROUP_PRICE_STAFFEL','2',1000,34,NULL,'2019-02-05 19:42:10',NULL,NULL),(380,'USE_ATTRIBUTES_IFRAME','true',1000,110,NULL,'2019-02-05 19:42:10',NULL,'xtc_cfg_select_option(array(\'true\', \'false\'),'),(381,'NEW_ATTRIBUTES_STYLING','true',1000,112,NULL,'2019-02-05 19:42:10',NULL,'xtc_cfg_select_option(array(\'true\', \'false\'),'),(382,'NEW_SELECT_CHECKBOX','true',1000,113,NULL,'2019-02-05 19:42:10',NULL,'xtc_cfg_select_option(array(\'true\', \'false\'),'),(383,'CSRF_TOKEN_SYSTEM','true',1000,114,NULL,'2019-02-05 19:42:10',NULL,'xtc_cfg_select_option(array(\'true\', \'false\'),'),(384,'ADMIN_HEADER_X_FRAME_OPTIONS','true',1000,115,NULL,'2019-02-05 19:42:10',NULL,'xtc_cfg_select_option(array(\'true\', \'false\'),'),(385,'ATTRIBUTE_MODEL_DELIMITER','<br />',1000,116,NULL,'2019-02-05 19:42:10',NULL,NULL),(386,'CFG_INTSTALLER_FILEEMTIME','1549281418',1000,-1,'2019-02-07 11:25:58','2019-02-05 19:45:49',NULL,NULL);
/*!40000 ALTER TABLE `configuration` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `configuration_group`
--

DROP TABLE IF EXISTS `configuration_group`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `configuration_group` (
  `configuration_group_id` int(11) NOT NULL AUTO_INCREMENT,
  `configuration_group_title` varchar(64) COLLATE latin1_german1_ci NOT NULL,
  `configuration_group_description` varchar(255) COLLATE latin1_german1_ci NOT NULL,
  `sort_order` int(5) DEFAULT NULL,
  `visible` int(1) DEFAULT '1',
  PRIMARY KEY (`configuration_group_id`)
) ENGINE=MyISAM AUTO_INCREMENT=1001 DEFAULT CHARSET=latin1 COLLATE=latin1_german1_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `configuration_group`
--

LOCK TABLES `configuration_group` WRITE;
/*!40000 ALTER TABLE `configuration_group` DISABLE KEYS */;
INSERT INTO `configuration_group` VALUES (1,'My Store','General information about my store',1,1),(2,'Minimum Values','The minimum values for functions / data',2,1),(3,'Maximum Values','The maximum values for functions / data',3,1),(4,'Images','Image parameters',4,1),(5,'Customer Details','Customer account configuration',5,1),(6,'Module Options','Hidden from configuration',6,0),(7,'Shipping/Packaging','Shipping options available at my store',7,1),(8,'Product Listing','Product Listing configuration options',8,1),(9,'Stock','Stock configuration options',9,1),(10,'Logging','Logging configuration options',10,1),(11,'Cache','Caching configuration options',11,1),(12,'E-Mail Options','General setting for E-Mail transport and HTML E-Mails',12,1),(13,'Download','Downloadable products options',13,1),(14,'GZip Compression','GZip compression options',14,1),(15,'Sessions','Session options',15,1),(16,'Meta-Tags/Search engines','Meta-tags/Search engines',16,1),(17,'Additional Modules','Additional Modules',17,1),(18,'Vat ID','Vat ID',18,1),(19,'Google Conversion','Google Conversion-Tracking',19,1),(20,'Import/Export','Import/Export',20,1),(21,'Afterbuy','Afterbuy.de',21,1),(22,'Search Options','Additional Options for search function',22,1),(23,'Econda Tracking','Econda Tracking System',23,1),(24,'PIWIK & Google Analytics Tracking','Settings for PIWIK & Google Analytics Tracking',24,1),(25,'Captcha','Captcha Configuration',25,1),(31,'Skrill','Skrill System',31,1),(40,'Popup Window Configuration','Popup Window Parameters',40,1),(1000,'Adminarea Options','Adminarea Configuration',1000,1);
/*!40000 ALTER TABLE `configuration_group` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `content_manager`
--

DROP TABLE IF EXISTS `content_manager`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `content_manager` (
  `content_id` int(11) NOT NULL AUTO_INCREMENT,
  `categories_id` int(11) NOT NULL DEFAULT '0',
  `parent_id` int(11) NOT NULL DEFAULT '0',
  `group_ids` text COLLATE latin1_german1_ci,
  `languages_id` int(11) NOT NULL,
  `content_title` text COLLATE latin1_german1_ci NOT NULL,
  `content_heading` text COLLATE latin1_german1_ci NOT NULL,
  `content_text` text COLLATE latin1_german1_ci NOT NULL,
  `sort_order` int(4) NOT NULL DEFAULT '0',
  `file_flag` int(1) NOT NULL DEFAULT '0',
  `content_file` varchar(255) COLLATE latin1_german1_ci NOT NULL DEFAULT '',
  `content_status` int(1) NOT NULL DEFAULT '0',
  `content_group` int(11) NOT NULL,
  `content_delete` int(1) NOT NULL DEFAULT '1',
  `content_meta_title` text COLLATE latin1_german1_ci NOT NULL,
  `content_meta_description` text COLLATE latin1_german1_ci NOT NULL,
  `content_meta_keywords` text COLLATE latin1_german1_ci NOT NULL,
  `content_meta_robots` varchar(32) COLLATE latin1_german1_ci NOT NULL,
  `content_active` int(1) NOT NULL DEFAULT '1',
  `content_group_index` int(4) NOT NULL DEFAULT '0',
  `date_added` datetime NOT NULL,
  `last_modified` datetime DEFAULT NULL,
  PRIMARY KEY (`content_id`),
  KEY `idx_content_group` (`content_group`,`languages_id`)
) ENGINE=MyISAM AUTO_INCREMENT=27 DEFAULT CHARSET=latin1 COLLATE=latin1_german1_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `content_manager`
--

LOCK TABLES `content_manager` WRITE;
/*!40000 ALTER TABLE `content_manager` DISABLE KEYS */;
INSERT INTO `content_manager` VALUES (1,0,0,'',1,'Payment &amp; Shipping','Payment &amp; Shipping','Put here your Payment &amp; Shipping information.',0,1,'',1,1,0,'','','','',1,0,'2019-02-05 19:42:11',NULL),(2,0,0,'',1,'Privacy Notice','Privacy Notice','Put here your Privacy Notice information.',0,1,'',1,2,0,'','','','',1,0,'2019-02-05 19:42:11',NULL),(3,0,0,'',1,'Conditions of Use','Conditions of Use','<strong>Conditions of Use</strong><br /><br />Put here your Conditions of Use information.<br /><br /><ol><li>Scope of Application</li><li>Contract partner</li><li>Conclusion of the Contract</li><li>Right to cancel</li><li>Price and Delivery Costs</li><li>Shipment and delivery conditions</li><li>Payment methods</li><li>Reservation of title</li><li>Warranty</li><li>Information about online dispute resolution</li></ol>...<br />...<br />...<h2>Information about online dispute resolution</h2><p>The EU Commission provides on its website the following link to the ODR platform: <a href=\"https://ec.europa.eu/consumers/odr/\" rel=\"nofollow noopener\" target=\"_blank\">https://ec.europa.eu/consumers/odr/</a></p><p>This platform shall be a point of entry for out-of-court resolutions of disputes arising from online sales and service contracts concluded between consumers and traders.</p><h2>Further informations</h2>...<br />...<br />...',0,1,'',1,3,0,'','','','',1,0,'2019-02-05 19:42:11',NULL),(4,0,0,'',1,'Imprint','Imprint','Put here your Company information.<br /><br />DemoShop GmbH<br />Managing director: Max Muster und Fritz Beispiel<br /><br />Max Muster Stra&szlig;e 21-23<br />D-0815 Musterhausen<br />E-Mail: max.muster@muster.de<br /><br />HRB 123456<br />Amtsgericht Musterhausen<br />VAT ID No.: DE 000 111 222<br /><br />Platform of the EU Commission regarding online dispute resolution: <a href=\"https://ec.europa.eu/consumers/odr/\" rel=\"nofollow noopener\" target=\"_blank\">https://ec.europa.eu/consumers/odr/</a>',0,1,'',1,4,0,'','','','',1,0,'2019-02-05 19:42:11',NULL),(5,0,0,'',1,'Index','Welcome','{$greeting}<br /><br />This is the default installation of <strong><span style=\"color:#B0347E;\">mod</span><span style=\"color:#6D6D6D;\">ified eCommerce Shopsoftware</span></strong>. All products shown are for demonstrational purposes. If you order products, they will be not be delivered nor billed.<br /><br />Should you be interested in the program, which forms the basis for this store, so please visit the website of <a href=\"https://www.modified-shop.org\" rel=\"nofollow noopener\" target=\"_blank\"><u><strong><span style=\"color:#B0347E;\">mod</span><span style=\"color:#6D6D6D;\">ified eCommerce Shopsoftware</span></strong></u></a>.<br /><br />The text shown here may be edited in the admin area under <b>Content Manager</b> - entry Index.',0,1,'',0,5,0,'','','','',1,0,'2019-02-05 19:42:11',NULL),(6,0,0,'',1,'Coupons','Coupons FAQ','<table cellSpacing=\"0\" cellPadding=\"0\">\r\n<tbody>\r\n<tr>\r\n<td class=\"main\"><strong>Buy Gift Vouchers/Coupons </strong></td></tr>\r\n<tr>\r\n<td class=\"main\">If the shop provided gift vouchers or coupons, You can buy them alike all other products. As soon as You have bought and payed the coupon, the shop system will activate Your coupon. You will then see the coupon amount in Your shopping cart. Then You can send the coupon via e-mail by clicking the link \"Send Coupon\". </td></tr></tbody></table>\r\n<table cellSpacing=\"0\" cellPadding=\"0\">\r\n<tbody>\r\n<tr>\r\n<td class=\"main\"><strong>How to dispatch Coupons </strong></td></tr>\r\n<tr>\r\n<td class=\"main\">To dispatch a coupon, please click the link \"Send Coupon\" in Your shopping cart. To send the coupon to the correct person, we need the following details: Surname and realname of the recipient and a valid e-mail adress of the recipient, and the desired coupon amount (You can also use only parts of Your balance). Please provide also a short message for the recipient. Please check those information again before You click the \"Send Coupon\" button. You can change all information at any time before clicking the \"Send Coupon\" button. </td></tr></tbody></table>\r\n<table cellSpacing=\"0\" cellPadding=\"0\">\r\n<tbody>\r\n<tr>\r\n<td class=\"main\"><strong>How to use Coupons to buy products. </strong></td></tr>\r\n<tr>\r\n<td class=\"main\">As soon as You have a balance, You can use it to pay for Your orders. During the checkout process, You can redeem Your coupon. In case Your balance is less than the value of goods You ordered, You would have to choose Your preferred method of payment for the difference amount. In case Your balance is more than the value of goods You ordered, the remaining amount of Your balance will be saved for Your next order. </td></tr></tbody></table>\r\n<table cellSpacing=\"0\" cellPadding=\"0\">\r\n<tbody>\r\n<tr>\r\n<td class=\"main\"><strong>How to redeem Coupons. </strong></td></tr>\r\n<tr>\r\n<td class=\"main\">In case You have received a coupun via e-mail, You can: <br />1. Click on the link provided in the e-mail. If You do not have an account in this shop already, please create a personal account. <br />2. After having added a product to Your shopping cart, You can enter Your coupon code.</td></tr></tbody></table>\r\n<table cellSpacing=\"0\" cellPadding=\"0\">\r\n<tbody>\r\n<tr>\r\n<td class=\"main\"><strong>Problems?</strong></td></tr>\r\n<tr>\r\n<td class=\"main\">If You have trouble or problems in using Your coupons, please check back with us via our e-mail: you@yourdomain.com. Please describe the encountered problem as detailed as possible! We need the following information to process Your request quickly: Your user id, the coupon code, error messages the shop system returned to You, and the name of the web browser You are using (e.g. \"Internet Explorer 6\" or \"Firefox 1.5\"). </td></tr></tbody></table>',0,1,'',0,6,1,'','','','',1,0,'2019-02-05 19:42:11',NULL),(7,0,0,'',1,'Contact','Contact','Please enter your contact information.',0,1,'',1,7,0,'','','','',1,0,'2019-02-05 19:42:11',NULL),(8,0,0,'',1,'Sitemap','','',0,0,'sitemap.php',1,8,0,'','','','',1,0,'2019-02-05 19:42:11',NULL),(9,0,0,'',1,'Right of revocation &amp; revocation form','Right of revocation &amp; revocation form','<p><strong>Right of revocation<br /></strong><br />Add your right of revocation here.</p><p><strong>Revocation form</strong><br /><br />(Complete and return this form only if you wish to withdraw from the contract.)<br /><br />To<br />Max Mustermann / Muster GmbH<br />Musterstra&szlig;e 11<br />66666 Musterstadt<br />Fax: 000-777777<br />E-Mail:info@muster.de<br /><br />[enter the name, address and if appropriate, fax number and e-mail-address of the entrepreneur by the entrepreneur]:<br /><br />I/We* hereby give notice that I/We (*) withdraw from my/our (*) contract of sale of the following goods (*) / provision of the following service (*)<br />_______________________________________________<br />_______________________________________________<br /><br />Ordered on ___________________ (*)/received on _______________________(*)<br /><br />Name of the consumer(s) ______________________________________<br />Address of the consumer(s)<br />_________________________________<br />_________________________________<br />_________________________________<br /><br />_________&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; _____________________________________________________<br />Date&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; signature of the consumer(s) (only with message on paper)<br /><br />_____________________________________________________________________________________<br />(*) delete as applicable</p>',0,1,'',1,9,0,'','','','',1,0,'2019-02-05 19:42:11',NULL),(10,0,0,'',1,'Delivery time','Delivery time','The deadline for delivery begins when paying in advance on the day after the payment order to the remitting bank or for other payments on the day to run after the conclusion and ends with the expiry of the last day of the period. Falls on a Saturday, Sunday or a public holiday delivery nationally recognized, the last day of the period, as occurs, the next business day at the place of such a day.',0,1,'',1,10,0,'','','','',1,0,'2019-02-05 19:42:11',NULL),(11,0,0,'',1,'E-Mail Signature','','<b>Company</b><br />Address<br />Location<br />Homepage<br />E-mail:<br />Phone:<br />Fax:<br />CEO:<br />VAT Reg No:',0,1,'',0,11,0,'','','','',0,0,'2019-02-05 19:42:11',NULL),(12,0,0,'',1,'Invoice data','Company - Address - Code City','Company<br/>Address<br/>Code City<br/><br/>Phone: 0123456789<br/>E-Mail: info@shop.de<br/>www: www.shopurl.de<br/><br/>IBAN: DE123456789011<br/>BIC: BYLEMDNE1DE<br/><br/>You can change this in the content manager.',0,1,'',0,12,0,'','','','',0,0,'2019-02-05 19:42:11',NULL),(13,0,0,'',1,'My quick purchase','My quick purchase','<p>With &bdquo;My Quick purchase&ldquo; you can more easily and above all quickly place your order now.</p><p>You will find the button &bdquo;<strong>Activate my quick purchase</strong>&ldquo; on the detail page of every product below the Cart-Button, where you have to store the desired delivery method, payment method, shipping address and billing address to activate the function for the Quick purchase.<br />Afterwards you will find the button for &bdquo;<strong>My quick purchase</strong>&ldquo; ath the following locations:</p><ul><li>Product detail page</li><li>Shopping cart</li><li>Your Account &raquo; My Orders</li><li>Your Account &raquo; My Orders &raquo; Orders detail page</li></ul><p>To change the default settings for &bdquo;My quick purchase&ldquo;, go to &bdquo;Your Account&ldquo; &raquo; &bdquo;<strong>Display/change my quick purchase settings</strong>&ldquo;.</p>',0,1,'',0,13,1,'','','','',1,0,'2019-02-05 19:42:11',NULL),(14,0,0,'',2,'Zahlung &amp; Versand','Zahlung &amp; Versand','F&uuml;gen Sie hier Ihre Informationen &uuml;ber Zahlung &amp; Versand ein.',0,1,'',1,1,0,'','','','',1,0,'2019-02-05 19:42:11',NULL),(15,0,0,'',2,'Privatsph&auml;re und Datenschutz','Privatsph&auml;re und Datenschutz','F&uuml;gen Sie hier Ihre Informationen &uuml;ber Privatsph&auml;re und Datenschutz ein.',0,1,'',1,2,0,'','','','',1,0,'2019-02-05 19:42:11',NULL),(16,0,0,'',2,'Unsere AGB','Allgemeine Gesch&auml;ftsbedingungen','<strong>Allgemeine Gesch&auml;ftsbedingungen</strong><br /><br />F&uuml;gen Sie hier Ihre allgemeinen Gesch&auml;ftsbedingungen ein.<br /><br /><ol><li>Geltungsbereich</li><li>Vertragspartner</li><li>Angebot und Vertragsschluss</li><li>Widerrufsrecht, Widerrufsbelehrung, Widerrufsfolgen</li><li>Preise und Versandkosten</li><li>Lieferung</li><li>Zahlung</li><li>Eigentumsvorbehalt</li><li>Gew&auml;hrleistung</li><li>Informationen zur Online-Streitbeilegung</li></ol>...<br />...<br />...<h2>Informationen zur Online-Streitbeilegung</h2><p>Die EU-Kommission stellt im Internet unter folgendem Link eine Plattform zur Online-Streitbeilegung bereit: <a href=\"https://ec.europa.eu/consumers/odr/\" rel=\"nofollow noopener\" target=\"_blank\">https://ec.europa.eu/consumers/odr/</a></p><p>Diese Plattform dient als Anlaufstelle zur au&szlig;ergerichtlichen Beilegung von Streitigkeiten aus Online-Kauf- oder Dienstleistungsvertr&auml;gen, an denen ein Verbraucher beteiligt ist.</p><h2>Weitere Informationen</h2>...<br />...<br />...',0,1,'',1,3,0,'','','','',1,0,'2019-02-05 19:42:11',NULL),(17,0,0,'',2,'Impressum','Impressum','F&uuml;gen Sie hier Ihr Impressum ein.<br /><br />DemoShop GmbH<br />Gesch&auml;ftsf&uuml;hrer: Max Muster und Fritz Beispiel<br /><br />Max Muster Stra&szlig;e 21-23<br />D-0815 Musterhausen<br />E-Mail: max.muster@muster.de<br /><br />HRB 123456<br />Amtsgericht Musterhausen<br />UStid-Nr.: DE 000 111 222<br /><br />Plattform der EU-Kommission zur Online-Streitbeilegung: <a href=\"https://ec.europa.eu/consumers/odr/\" rel=\"nofollow noopener\" target=\"_blank\">https://ec.europa.eu/consumers/odr/</a>',0,1,'',1,4,0,'','','','',1,0,'2019-02-05 19:42:12',NULL),(18,0,0,'',2,'Index','Willkommen','{$greeting}<br /><br />Dies ist die Standardinstallation der <strong><span style=\"color:#B0347E;\">mod</span><span style=\"color:#6D6D6D;\">ified eCommerce Shopsoftware</span></strong>. Alle dargestellten Produkte dienen zur Demonstration der Funktionsweise. Wenn Sie Produkte bestellen, so werden diese weder ausgeliefert, noch in Rechnung gestellt.<br /><br />Sollten Sie daran interessiert sein das Programm, welches die Grundlage f&uuml;r diesen Shop bildet, einzusetzen, so besuchen Sie bitte die Webseite der <a href=\"https://www.modified-shop.org\" rel=\"nofollow noopener\" target=\"_blank\"><u><strong><span style=\"color:#B0347E;\">mod</span><span style=\"color:#6D6D6D;\">ified eCommerce Shopsoftware</span></strong></u></a>.<br /><br />Der hier dargestellte Text kann im Adminbereich unter <b>Content Manager</b> - Eintrag Index bearbeitet werden.',0,1,'',0,5,0,'','','','',1,0,'2019-02-05 19:42:12',NULL),(19,0,0,'',2,'Gutscheine','Gutscheine - Fragen und Antworten','<table cellSpacing=\"0\" cellPadding=\"0\">\r\n<tbody>\r\n<tr>\r\n<td class=\"main\"><strong>Gutscheine kaufen </strong></td></tr>\r\n<tr>\r\n<td class=\"main\">Gutscheine k&ouml;nnen, falls sie im Shop angeboten werden, wie normale Artikel gekauft werden. Sobald Sie einen Gutschein gekauft haben und dieser nach erfolgreicher Zahlung freigeschaltet wurde, erscheint der Betrag unter Ihrem Warenkorb. Nun k&ouml;nnen Sie &uuml;ber den Link \" Gutschein versenden \" den gew&uuml;nschten Betrag per E-Mail versenden.</td></tr></tbody></table>\r\n<table cellSpacing=\"0\" cellPadding=\"0\">\r\n<tbody>\r\n<tr>\r\n<td class=\"main\"><strong>Wie man Gutscheine versendet</strong></td></tr>\r\n<tr>\r\n<td class=\"main\">Um einen Gutschein zu versenden, klicken Sie bitte auf den Link \"Gutschein versenden\" in Ihrem Einkaufskorb. Um einen Gutschein zu versenden, ben&ouml;tigen wir folgende Angaben von Ihnen: Vor- und Nachname des Empf&auml;ngers. Eine g&uuml;ltige E-Mail Adresse des Empf&auml;ngers. Den gew&uuml;nschten Betrag (Sie k&ouml;nnen auch Teilbetr&auml;ge Ihres Guthabens versenden). Eine kurze Nachricht an den Empf&auml;nger. Bitte &uuml;berpr&uuml;fen Sie Ihre Angaben noch einmal vor dem Versenden. Sie haben vor dem Versenden jederzeit die M&ouml;glichkeit Ihre Angaben zu korrigieren.</td></tr></tbody></table>\r\n<table cellSpacing=\"0\" cellPadding=\"0\">\r\n<tbody>\r\n<tr>\r\n<td class=\"main\"><strong>Mit Gutscheinen einkaufen.</strong></td></tr>\r\n<tr>\r\n<td class=\"main\">Sobald Sie &uuml;ber ein Guthaben verf&uuml;gen, k&ouml;nnen Sie dieses zum Bezahlen Ihrer Bestellung verwenden. W&auml;hrend des Bestellvorganges haben Sie die M&ouml;glichkeit Ihr Guthaben einzul&ouml;sen. Falls das Guthaben unter dem Warenwert liegt m&uuml;ssen Sie Ihre bevorzugte Zahlungsweise f&uuml;r den Differenzbetrag w&auml;hlen. &Uuml;bersteigt Ihr Guthaben den Warenwert, steht Ihnen das Restguthaben selbstverst&auml;ndlich f&uuml;r Ihre n&auml;chste Bestellung zur Verf&uuml;gung.</td></tr></tbody></table>\r\n<table cellSpacing=\"0\" cellPadding=\"0\">\r\n<tbody>\r\n<tr>\r\n<td class=\"main\"><strong>Gutscheine verbuchen. </strong></td></tr>\r\n<tr>\r\n<td class=\"main\">Wenn Sie einen Gutschein per E-Mail erhalten haben, k&ouml;nnen Sie den Betrag wie folgt verbuchen: <br />1. Klicken Sie auf den in der E-Mail angegebenen Link. Falls Sie noch nicht &uuml;ber ein pers&ouml;nliches Kundenkonto verf&uuml;gen, haben Sie die M&ouml;glichkeit ein Konto zu er&ouml;ffnen. <br />2. Nachdem Sie ein Produkt in den Warenkorb gelegt haben, k&ouml;nnen Sie dort Ihren Gutscheincode eingeben.</td></tr></tbody></table>\r\n<table cellSpacing=\"0\" cellPadding=\"0\">\r\n<tbody>\r\n<tr>\r\n<td class=\"main\"><strong>Falls es zu Problemen kommen sollte:</strong></td></tr>\r\n<tr>\r\n<td class=\"main\">Falls es wider Erwarten zu Problemen mit einem Gutschein kommen sollte, kontaktieren Sie uns bitte per E-Mail: you@yourdomain.com. Bitte beschreiben Sie m&ouml;glichst genau das Problem, wichtige Angaben sind unter anderem: Ihre Kundennummer, der Gutscheincode, Fehlermeldungen des Systems sowie der von Ihnen benutzte Browser (z.B. \"Internet Explorer 6\" oder \"Firefox 1.5\"). </td></tr></tbody></table>',0,1,'',0,6,1,'','','','',1,0,'2019-02-05 19:42:12',NULL),(20,0,0,'',2,'Kontakt','Kontakt','Ihre Kontaktinformationen',0,1,'',1,7,0,'','','','',1,0,'2019-02-05 19:42:12',NULL),(21,0,0,'',2,'Sitemap','','',0,0,'sitemap.php',1,8,0,'','','','',1,0,'2019-02-05 19:42:12',NULL),(22,0,0,'',2,'Widerrufsrecht &amp; Widerrufsformular','Widerrufsrecht &amp; Widerrufsformular','<p><strong>Widerrufsrecht<br /></strong><br />F&uuml;gen Sie hier das Widerrufsrecht ein.</p><p><strong>Widerrufsformular</strong><br /><br />(Wenn Sie den Vertrag widerrufen wollen, dann f&uuml;llen Sie bitte dieses Formular aus und senden Sie es zur&uuml;ck.)<br /><br />An<br />Max Mustermann / Muster GmbH<br />Musterstra&szlig;e 11<br />66666 Musterstadt<br />Fax: 000-777777<br />E-Mail:info@muster.de<br /><br />[hier ist der Name, die Anschrift und gegebenenfalls die Telefaxnummer und E-Mail-Adresse des Unternehmers durch den Unternehmer einzuf&uuml;gen]:<br /><br />Hiermit widerrufe(n) ich/wir (*) den von mir/uns (*) abgeschlossenen Vertrag &uuml;ber den Kauf der folgenden Waren (*) / die Erbringung der folgenden Dienstleistung (*)<br />_______________________________________________<br />_______________________________________________<br /><br />Bestellt am ___________________ (*)/erhalten am _______________________(*)<br /><br />Name des/der Verbraucher(s) ______________________________________<br />Anschrift des/der Verbraucher(s)<br />_________________________________<br />_________________________________<br />_________________________________<br /><br />_________&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; _____________________________________________________<br />Datum&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Unterschrift des/der Verbraucher(s) (nur bei Mitteilung auf Papier)<br /><br />_____________________________________________________________________________________<br />(*) Unzutreffendes streichen</p>',0,1,'',1,9,0,'','','','',1,0,'2019-02-05 19:42:12',NULL),(23,0,0,'',2,'Lieferzeit','Lieferzeit','Die Frist f&uuml;r die Lieferung beginnt bei Zahlung per Vorkasse am Tag nach Erteilung des Zahlungsauftrags an das &uuml;berweisende Kreditinstitut bzw. bei anderen Zahlungsarten am Tag nach Vertragsschluss zu laufen und endet mit dem Ablauf des letzten Tages der Frist. F&auml;llt der letzte Tag der Frist auf einen Samstag, Sonntag oder einen am Lieferort staatlich anerkannten allgemeinen Feiertag, so tritt an die Stelle eines solchen Tages der n&auml;chste Werktag.',0,1,'',1,10,0,'','','','',1,0,'2019-02-05 19:42:12',NULL),(24,0,0,'',2,'E-Mail Signatur','','Firma<br />Adresse<br />Ort<br />Homepage<br />E-Mail:<br />Fon:<br />Fax:<br />USt-IdNr.:<br />Handelsregister<br />Gesch&auml;ftsf&uuml;hrer:',0,1,'',0,11,0,'','','','',0,0,'2019-02-05 19:42:12',NULL),(25,0,0,'',2,'Rechnungsdaten','Firma - Adresse - PLZ Stadt','Firma<br/>Adresse<br/>PLZ Stadt<br/><br/>Tel: 0123456789<br/>E-Mail: info@shop.de<br/>www: www.shopurl.de<br/><br/>IBAN: DE123456789011<br/>BIC: BYLEMDNE1DE<br/><br/>Diese Daten k&ouml;nnen im Content Manager ge&auml;ndert werden.',0,1,'',0,12,0,'','','','',0,0,'2019-02-05 19:42:12',NULL),(26,0,0,'',2,'Mein Schnellkauf','Mein Schnellkauf','<p>Mit &bdquo;Mein Schnellkauf&ldquo; k&ouml;nnen Sie Ihre Bestellung jetzt noch einfacher und vor allem schneller t&auml;tigen.</p><p>Sie finden auf der Detailseite eines jeden Artikels unterhalb des Warenkorb-Buttons die Schaltfl&auml;che &bdquo;<strong>Mein Schnellkauf aktivieren</strong>&ldquo;, wo Sie die f&uuml;r den Schnellkauf gew&uuml;nschte Versandart, Bezahlart, Versandadresse und Rechnungsadresse hinterlegen m&uuml;ssen um die Funktion zu aktivieren.<br />Anschlie&szlig;end finden Sie an den folgenden Stellen im Shop den Button zur Bestellung mit &bdquo;<strong>Mein Schnellkauf</strong>&ldquo;:</p><ul><li>Artikel-Detailseite</li><li>Warenkorb</li><li>Mein Konto &raquo; Meine Bestellungen</li><li>Mein Konto &raquo; Meine Bestellungen &raquo; Detailseite der Bestellung</li></ul><p>Um die Voreinstellungen f&uuml;r &bdquo;Mein Schnellkauf&ldquo; zu &auml;ndern, gehen Sie auf &bdquo;Mein Konto&ldquo; &raquo; &bdquo;<strong>Mein Schnellkauf bearbeiten</strong>&ldquo;.</p>',0,1,'',0,13,1,'','','','',1,0,'2019-02-05 19:42:12',NULL);
/*!40000 ALTER TABLE `content_manager` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `countries`
--

DROP TABLE IF EXISTS `countries`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `countries` (
  `countries_id` int(11) NOT NULL AUTO_INCREMENT,
  `countries_name` varchar(64) COLLATE latin1_german1_ci NOT NULL,
  `countries_iso_code_2` char(2) COLLATE latin1_german1_ci NOT NULL,
  `countries_iso_code_3` char(3) COLLATE latin1_german1_ci NOT NULL,
  `address_format_id` int(11) NOT NULL,
  `status` int(1) DEFAULT '1',
  `required_zones` int(1) DEFAULT '0',
  PRIMARY KEY (`countries_id`),
  UNIQUE KEY `idx_countries_iso_code_2` (`countries_iso_code_2`),
  UNIQUE KEY `idx_countries_iso_code_3` (`countries_iso_code_3`),
  KEY `idx_countries_name` (`countries_name`),
  KEY `idx_status` (`status`)
) ENGINE=MyISAM AUTO_INCREMENT=243 DEFAULT CHARSET=latin1 COLLATE=latin1_german1_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `countries`
--

LOCK TABLES `countries` WRITE;
/*!40000 ALTER TABLE `countries` DISABLE KEYS */;
INSERT INTO `countries` VALUES (1,'Afghanistan','AF','AFG',1,0,0),(2,'Albania','AL','ALB',1,0,0),(3,'Algeria','DZ','DZA',1,0,0),(4,'American Samoa','AS','ASM',1,0,0),(5,'Andorra','AD','AND',1,0,0),(6,'Angola','AO','AGO',1,0,0),(7,'Anguilla','AI','AIA',1,0,0),(8,'Antarctica','AQ','ATA',1,0,0),(9,'Antigua and Barbuda','AG','ATG',1,0,0),(10,'Argentina','AR','ARG',1,0,0),(11,'Armenia','AM','ARM',1,0,0),(12,'Aruba','AW','ABW',1,0,0),(13,'Australia','AU','AUD',1,0,0),(14,'Austria','AT','AUT',5,0,0),(15,'Azerbaijan','AZ','AZE',1,0,0),(16,'Bahamas','BS','BHS',1,0,0),(17,'Bahrain','BH','BHR',1,0,0),(18,'Bangladesh','BD','BGD',1,0,0),(19,'Barbados','BB','BRB',1,0,0),(20,'Belarus','BY','BLR',1,0,0),(21,'Belgium','BE','BEL',1,0,0),(22,'Belize','BZ','BLZ',1,0,0),(23,'Benin','BJ','BEN',1,0,0),(24,'Bermuda','BM','BMU',1,0,0),(25,'Bhutan','BT','BTN',1,0,0),(26,'Bolivia','BO','BOL',1,0,0),(27,'Bosnia and Herzegowina','BA','BIH',1,0,0),(28,'Botswana','BW','BWA',1,0,0),(29,'Bouvet Island','BV','BVT',1,0,0),(30,'Brazil','BR','BRA',1,0,0),(31,'British Indian Ocean Territory','IO','IOT',1,0,0),(32,'Brunei Darussalam','BN','BRN',1,0,0),(33,'Bulgaria','BG','BGR',1,0,0),(34,'Burkina Faso','BF','BFA',1,0,0),(35,'Burundi','BI','BDI',1,0,0),(36,'Cambodia','KH','KHM',1,0,0),(37,'Cameroon','CM','CMR',1,0,0),(38,'Canada','CA','CAN',1,0,0),(39,'Cape Verde','CV','CPV',1,0,0),(40,'Cayman Islands','KY','CYM',1,0,0),(41,'Central African Republic','CF','CAF',1,0,0),(42,'Chad','TD','TCD',1,0,0),(43,'Chile','CL','CHL',1,0,0),(44,'China','CN','CHN',7,0,0),(45,'Christmas Island','CX','CXR',1,0,0),(46,'Cocos (Keeling) Islands','CC','CCK',1,0,0),(47,'Colombia','CO','COL',1,0,0),(48,'Comoros','KM','COM',1,0,0),(49,'Congo','CG','COG',1,0,0),(50,'Cook Islands','CK','COK',1,0,0),(51,'Costa Rica','CR','CRI',1,0,0),(52,'Cote D\'Ivoire','CI','CIV',1,0,0),(53,'Croatia','HR','HRV',1,0,0),(54,'Cuba','CU','CUB',1,0,0),(55,'Cyprus','CY','CYP',1,0,0),(56,'Czech Republic','CZ','CZE',1,0,0),(57,'Denmark','DK','DNK',1,0,0),(58,'Djibouti','DJ','DJI',1,0,0),(59,'Dominica','DM','DMA',1,0,0),(60,'Dominican Republic','DO','DOM',1,0,0),(61,'East Timor','TP','TMP',1,0,0),(62,'Ecuador','EC','ECU',1,0,0),(63,'Egypt','EG','EGY',1,0,0),(64,'El Salvador','SV','SLV',1,0,0),(65,'Equatorial Guinea','GQ','GNQ',1,0,0),(66,'Eritrea','ER','ERI',1,0,0),(67,'Estonia','EE','EST',1,0,0),(68,'Ethiopia','ET','ETH',1,0,0),(69,'Falkland Islands (Malvinas)','FK','FLK',1,0,0),(70,'Faroe Islands','FO','FRO',1,0,0),(71,'Fiji','FJ','FJI',1,0,0),(72,'Finland','FI','FIN',1,0,0),(73,'France','FR','FRA',1,0,0),(75,'French Guiana','GF','GUF',1,0,0),(76,'French Polynesia','PF','PYF',1,0,0),(77,'French Southern Territories','TF','ATF',1,0,0),(78,'Gabon','GA','GAB',1,0,0),(79,'Gambia','GM','GMB',1,0,0),(80,'Georgia','GE','GEO',1,0,0),(81,'Germany','DE','DEU',5,1,0),(82,'Ghana','GH','GHA',1,0,0),(83,'Gibraltar','GI','GIB',1,0,0),(84,'Greece','GR','GRC',1,0,0),(85,'Greenland','GL','GRL',1,0,0),(86,'Grenada','GD','GRD',1,0,0),(87,'Guadeloupe','GP','GLP',1,0,0),(88,'Guam','GU','GUM',1,0,0),(89,'Guatemala','GT','GTM',1,0,0),(90,'Guinea','GN','GIN',1,0,0),(91,'Guinea-bissau','GW','GNB',1,0,0),(92,'Guyana','GY','GUY',1,0,0),(93,'Haiti','HT','HTI',1,0,0),(94,'Heard and Mc Donald Islands','HM','HMD',1,0,0),(95,'Honduras','HN','HND',1,0,0),(96,'Hong Kong','HK','HKG',1,0,0),(97,'Hungary','HU','HUN',1,0,0),(98,'Iceland','IS','ISL',1,0,0),(99,'India','IN','IND',1,0,0),(100,'Indonesia','ID','IDN',1,0,0),(101,'Iran (Islamic Republic of)','IR','IRN',1,0,0),(102,'Iraq','IQ','IRQ',1,0,0),(103,'Ireland','IE','IRL',6,0,0),(104,'Israel','IL','ISR',1,0,0),(105,'Italy','IT','ITA',1,0,0),(106,'Jamaica','JM','JAM',1,0,0),(107,'Japan','JP','JPN',1,0,0),(108,'Jordan','JO','JOR',1,0,0),(109,'Kazakhstan','KZ','KAZ',1,0,0),(110,'Kenya','KE','KEN',1,0,0),(111,'Kiribati','KI','KIR',1,0,0),(112,'Korea, Democratic People\'s Republic of','KP','PRK',1,0,0),(113,'Korea, Republic of','KR','KOR',1,0,0),(114,'Kuwait','KW','KWT',1,0,0),(115,'Kyrgyzstan','KG','KGZ',1,0,0),(116,'Lao People\'s Democratic Republic','LA','LAO',1,0,0),(117,'Latvia','LV','LVA',1,0,0),(118,'Lebanon','LB','LBN',1,0,0),(119,'Lesotho','LS','LSO',1,0,0),(120,'Liberia','LR','LBR',1,0,0),(121,'Libyan Arab Jamahiriya','LY','LBY',1,0,0),(122,'Liechtenstein','LI','LIE',1,0,0),(123,'Lithuania','LT','LTU',1,0,0),(124,'Luxembourg','LU','LUX',5,0,0),(125,'Macau','MO','MAC',1,0,0),(126,'Macedonia, The Former Yugoslav Republic of','MK','MKD',1,0,0),(127,'Madagascar','MG','MDG',1,0,0),(128,'Malawi','MW','MWI',1,0,0),(129,'Malaysia','MY','MYS',1,0,0),(130,'Maldives','MV','MDV',1,0,0),(131,'Mali','ML','MLI',1,0,0),(132,'Malta','MT','MLT',1,0,0),(133,'Marshall Islands','MH','MHL',1,0,0),(134,'Martinique','MQ','MTQ',1,0,0),(135,'Mauritania','MR','MRT',1,0,0),(136,'Mauritius','MU','MUS',1,0,0),(137,'Mayotte','YT','MYT',1,0,0),(138,'Mexico','MX','MEX',1,0,0),(139,'Micronesia, Federated States of','FM','FSM',1,0,0),(140,'Moldova, Republic of','MD','MDA',1,0,0),(141,'Monaco','MC','MCO',1,0,0),(142,'Mongolia','MN','MNG',1,0,0),(143,'Montserrat','MS','MSR',1,0,0),(144,'Morocco','MA','MAR',1,0,0),(145,'Mozambique','MZ','MOZ',1,0,0),(146,'Myanmar','MM','MMR',1,0,0),(147,'Namibia','NA','NAM',1,0,0),(148,'Nauru','NR','NRU',1,0,0),(149,'Nepal','NP','NPL',1,0,0),(150,'Netherlands','NL','NLD',1,0,0),(151,'Netherlands Antilles','AN','ANT',1,0,0),(152,'New Caledonia','NC','NCL',1,0,0),(153,'New Zealand','NZ','NZL',1,0,0),(154,'Nicaragua','NI','NIC',1,0,0),(155,'Niger','NE','NER',1,0,0),(156,'Nigeria','NG','NGA',1,0,0),(157,'Niue','NU','NIU',1,0,0),(158,'Norfolk Island','NF','NFK',1,0,0),(159,'Northern Mariana Islands','MP','MNP',1,0,0),(160,'Norway','NO','NOR',1,0,0),(161,'Oman','OM','OMN',1,0,0),(162,'Pakistan','PK','PAK',1,0,0),(163,'Palau','PW','PLW',1,0,0),(164,'Panama','PA','PAN',1,0,0),(165,'Papua New Guinea','PG','PNG',1,0,0),(166,'Paraguay','PY','PRY',1,0,0),(167,'Peru','PE','PER',1,0,0),(168,'Philippines','PH','PHL',1,0,0),(169,'Pitcairn','PN','PCN',1,0,0),(170,'Poland','PL','POL',1,0,0),(171,'Portugal','PT','PRT',1,0,0),(172,'Puerto Rico','PR','PRI',1,0,0),(173,'Qatar','QA','QAT',1,0,0),(174,'Reunion','RE','REU',1,0,0),(175,'Romania','RO','ROM',1,0,0),(176,'Russian Federation','RU','RUS',1,0,0),(177,'Rwanda','RW','RWA',1,0,0),(178,'Saint Kitts and Nevis','KN','KNA',1,0,0),(179,'Saint Lucia','LC','LCA',1,0,0),(180,'Saint Vincent and the Grenadines','VC','VCT',1,0,0),(181,'Samoa','WS','WSM',1,0,0),(182,'San Marino','SM','SMR',1,0,0),(183,'Sao Tome and Principe','ST','STP',1,0,0),(184,'Saudi Arabia','SA','SAU',1,0,0),(185,'Senegal','SN','SEN',1,0,0),(186,'Seychelles','SC','SYC',1,0,0),(187,'Sierra Leone','SL','SLE',1,0,0),(188,'Singapore','SG','SGP',4,0,0),(189,'Slovakia (Slovak Republic)','SK','SVK',1,0,0),(190,'Slovenia','SI','SVN',1,0,0),(191,'Solomon Islands','SB','SLB',1,0,0),(192,'Somalia','SO','SOM',1,0,0),(193,'South Africa','ZA','ZAF',1,0,0),(194,'South Georgia and the South Sandwich Islands','GS','SGS',1,0,0),(195,'Spain','ES','ESP',3,0,0),(196,'Sri Lanka','LK','LKA',1,0,0),(197,'St. Helena','SH','SHN',1,0,0),(198,'St. Pierre and Miquelon','PM','SPM',1,0,0),(199,'Sudan','SD','SDN',1,0,0),(200,'Suriname','SR','SUR',1,0,0),(201,'Svalbard and Jan Mayen Islands','SJ','SJM',1,0,0),(202,'Swaziland','SZ','SWZ',1,0,0),(203,'Sweden','SE','SWE',1,0,0),(204,'Switzerland','CH','CHE',5,0,0),(205,'Syrian Arab Republic','SY','SYR',1,0,0),(206,'Taiwan','TW','TWN',6,0,0),(207,'Tajikistan','TJ','TJK',1,0,0),(208,'Tanzania, United Republic of','TZ','TZA',1,0,0),(209,'Thailand','TH','THA',1,0,0),(210,'Togo','TG','TGO',1,0,0),(211,'Tokelau','TK','TKL',1,0,0),(212,'Tonga','TO','TON',1,0,0),(213,'Trinidad and Tobago','TT','TTO',1,0,0),(214,'Tunisia','TN','TUN',1,0,0),(215,'Turkey','TR','TUR',1,0,0),(216,'Turkmenistan','TM','TKM',1,0,0),(217,'Turks and Caicos Islands','TC','TCA',1,0,0),(218,'Tuvalu','TV','TUV',1,0,0),(219,'Uganda','UG','UGA',1,0,0),(220,'Ukraine','UA','UKR',1,0,0),(221,'United Arab Emirates','AE','ARE',1,0,0),(222,'United Kingdom','GB','GBR',8,0,0),(223,'United States','US','USA',2,0,0),(224,'United States Minor Outlying Islands','UM','UMI',1,0,0),(225,'Uruguay','UY','URY',1,0,0),(226,'Uzbekistan','UZ','UZB',1,0,0),(227,'Vanuatu','VU','VUT',1,0,0),(228,'Vatican City State (Holy See)','VA','VAT',1,0,0),(229,'Venezuela','VE','VEN',1,0,0),(230,'Viet Nam','VN','VNM',1,0,0),(231,'Virgin Islands (British)','VG','VGB',1,0,0),(232,'Virgin Islands (U.S.)','VI','VIR',1,0,0),(233,'Wallis and Futuna Islands','WF','WLF',1,0,0),(234,'Western Sahara','EH','ESH',1,0,0),(235,'Yemen','YE','YEM',1,0,0),(237,'Zaire','ZR','ZAR',1,0,0),(238,'Zambia','ZM','ZMB',1,0,0),(239,'Zimbabwe','ZW','ZWE',1,0,0),(240,'Serbia','RS','SRB',1,0,0),(241,'Montenegro','ME','MNE',1,0,0),(242,'Kosovo','CS','SCG',1,0,0);
/*!40000 ALTER TABLE `countries` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coupon_email_track`
--

DROP TABLE IF EXISTS `coupon_email_track`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coupon_email_track` (
  `unique_id` int(11) NOT NULL AUTO_INCREMENT,
  `coupon_id` int(11) NOT NULL DEFAULT '0',
  `customer_id_sent` int(11) NOT NULL DEFAULT '0',
  `sent_firstname` varchar(32) COLLATE latin1_german1_ci DEFAULT NULL,
  `sent_lastname` varchar(32) COLLATE latin1_german1_ci DEFAULT NULL,
  `emailed_to` varchar(255) COLLATE latin1_german1_ci DEFAULT NULL,
  `date_sent` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`unique_id`),
  UNIQUE KEY `idx_coupon_id` (`coupon_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_german1_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coupon_email_track`
--

LOCK TABLES `coupon_email_track` WRITE;
/*!40000 ALTER TABLE `coupon_email_track` DISABLE KEYS */;
/*!40000 ALTER TABLE `coupon_email_track` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coupon_gv_customer`
--

DROP TABLE IF EXISTS `coupon_gv_customer`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coupon_gv_customer` (
  `customer_id` int(5) NOT NULL DEFAULT '0',
  `amount` decimal(8,4) NOT NULL DEFAULT '0.0000',
  PRIMARY KEY (`customer_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_german1_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coupon_gv_customer`
--

LOCK TABLES `coupon_gv_customer` WRITE;
/*!40000 ALTER TABLE `coupon_gv_customer` DISABLE KEYS */;
/*!40000 ALTER TABLE `coupon_gv_customer` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coupon_gv_queue`
--

DROP TABLE IF EXISTS `coupon_gv_queue`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coupon_gv_queue` (
  `unique_id` int(5) NOT NULL AUTO_INCREMENT,
  `customer_id` int(5) NOT NULL DEFAULT '0',
  `order_id` int(5) NOT NULL DEFAULT '0',
  `amount` decimal(8,4) NOT NULL DEFAULT '0.0000',
  `date_created` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `ipaddr` varchar(50) COLLATE latin1_german1_ci NOT NULL DEFAULT '',
  `release_flag` char(1) COLLATE latin1_german1_ci NOT NULL DEFAULT 'N',
  PRIMARY KEY (`unique_id`),
  KEY `idx_customer_id` (`customer_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_german1_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coupon_gv_queue`
--

LOCK TABLES `coupon_gv_queue` WRITE;
/*!40000 ALTER TABLE `coupon_gv_queue` DISABLE KEYS */;
/*!40000 ALTER TABLE `coupon_gv_queue` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coupon_redeem_track`
--

DROP TABLE IF EXISTS `coupon_redeem_track`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coupon_redeem_track` (
  `unique_id` int(11) NOT NULL AUTO_INCREMENT,
  `coupon_id` int(11) NOT NULL DEFAULT '0',
  `customer_id` int(11) NOT NULL DEFAULT '0',
  `redeem_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `redeem_ip` varchar(50) COLLATE latin1_german1_ci NOT NULL DEFAULT '',
  `order_id` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`unique_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_german1_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coupon_redeem_track`
--

LOCK TABLES `coupon_redeem_track` WRITE;
/*!40000 ALTER TABLE `coupon_redeem_track` DISABLE KEYS */;
/*!40000 ALTER TABLE `coupon_redeem_track` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coupons`
--

DROP TABLE IF EXISTS `coupons`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coupons` (
  `coupon_id` int(11) NOT NULL AUTO_INCREMENT,
  `coupon_type` char(1) COLLATE latin1_german1_ci NOT NULL DEFAULT 'F',
  `coupon_code` varchar(32) COLLATE latin1_german1_ci NOT NULL DEFAULT '',
  `coupon_amount` decimal(8,4) NOT NULL DEFAULT '0.0000',
  `coupon_minimum_order` decimal(8,4) NOT NULL DEFAULT '0.0000',
  `coupon_start_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `coupon_expire_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `uses_per_coupon` int(5) NOT NULL DEFAULT '1',
  `uses_per_user` int(5) NOT NULL DEFAULT '0',
  `restrict_to_products` text COLLATE latin1_german1_ci,
  `restrict_to_categories` text COLLATE latin1_german1_ci,
  `restrict_to_customers` text COLLATE latin1_german1_ci,
  `coupon_active` char(1) COLLATE latin1_german1_ci NOT NULL DEFAULT 'Y',
  `date_created` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `date_modified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`coupon_id`),
  UNIQUE KEY `idx_coupon_code` (`coupon_code`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_german1_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coupons`
--

LOCK TABLES `coupons` WRITE;
/*!40000 ALTER TABLE `coupons` DISABLE KEYS */;
/*!40000 ALTER TABLE `coupons` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coupons_description`
--

DROP TABLE IF EXISTS `coupons_description`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coupons_description` (
  `coupon_id` int(11) NOT NULL DEFAULT '0',
  `language_id` int(11) NOT NULL,
  `coupon_name` varchar(32) COLLATE latin1_german1_ci NOT NULL DEFAULT '',
  `coupon_description` text COLLATE latin1_german1_ci,
  PRIMARY KEY (`coupon_id`,`language_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_german1_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coupons_description`
--

LOCK TABLES `coupons_description` WRITE;
/*!40000 ALTER TABLE `coupons_description` DISABLE KEYS */;
/*!40000 ALTER TABLE `coupons_description` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `currencies`
--

DROP TABLE IF EXISTS `currencies`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `currencies` (
  `currencies_id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(32) COLLATE latin1_german1_ci NOT NULL,
  `code` char(3) COLLATE latin1_german1_ci NOT NULL,
  `symbol_left` varchar(12) COLLATE latin1_german1_ci DEFAULT NULL,
  `symbol_right` varchar(12) COLLATE latin1_german1_ci DEFAULT NULL,
  `decimal_point` char(1) COLLATE latin1_german1_ci DEFAULT NULL,
  `thousands_point` char(1) COLLATE latin1_german1_ci DEFAULT NULL,
  `decimal_places` char(1) COLLATE latin1_german1_ci DEFAULT NULL,
  `value` float(13,8) DEFAULT NULL,
  `last_updated` datetime DEFAULT NULL,
  `status` int(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`currencies_id`),
  UNIQUE KEY `idx_code` (`code`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=latin1 COLLATE=latin1_german1_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `currencies`
--

LOCK TABLES `currencies` WRITE;
/*!40000 ALTER TABLE `currencies` DISABLE KEYS */;
INSERT INTO `currencies` VALUES (1,'Euro','EUR','','EUR',',','.','2',1.00000000,'2019-02-05 19:42:17',1),(2,'United States Dollar','USD','$','','.',',','2',1.29779994,'2019-02-05 19:42:17',0),(3,'Schweizer Franken','CHF','CHF','','.','','2',1.20439994,'2019-02-05 19:42:17',0),(4,'Great Britain Pound','GBP','','&pound;','.',',','2',0.80940002,'2019-02-05 19:42:17',0);
/*!40000 ALTER TABLE `currencies` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `customers`
--

DROP TABLE IF EXISTS `customers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `customers` (
  `customers_id` int(11) NOT NULL AUTO_INCREMENT,
  `customers_cid` varchar(32) COLLATE latin1_german1_ci DEFAULT NULL,
  `customers_vat_id` varchar(20) COLLATE latin1_german1_ci DEFAULT NULL,
  `customers_vat_id_status` int(2) NOT NULL DEFAULT '0',
  `customers_warning` varchar(32) COLLATE latin1_german1_ci DEFAULT NULL,
  `customers_status` int(5) NOT NULL DEFAULT '1',
  `customers_gender` char(1) COLLATE latin1_german1_ci NOT NULL,
  `customers_firstname` varchar(64) COLLATE latin1_german1_ci NOT NULL,
  `customers_lastname` varchar(64) COLLATE latin1_german1_ci NOT NULL,
  `customers_dob` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `customers_email_address` varchar(255) COLLATE latin1_german1_ci NOT NULL,
  `customers_default_address_id` int(11) NOT NULL,
  `customers_telephone` varchar(32) COLLATE latin1_german1_ci NOT NULL,
  `customers_fax` varchar(32) COLLATE latin1_german1_ci DEFAULT NULL,
  `customers_password` varchar(60) COLLATE latin1_german1_ci NOT NULL,
  `customers_newsletter` char(1) COLLATE latin1_german1_ci DEFAULT NULL,
  `customers_newsletter_mode` char(1) COLLATE latin1_german1_ci NOT NULL DEFAULT '0',
  `member_flag` char(1) COLLATE latin1_german1_ci NOT NULL DEFAULT '0',
  `delete_user` char(1) COLLATE latin1_german1_ci NOT NULL DEFAULT '1',
  `account_type` int(1) NOT NULL DEFAULT '0',
  `password_request_key` varchar(32) COLLATE latin1_german1_ci NOT NULL,
  `password_request_time` datetime DEFAULT '0000-00-00 00:00:00',
  `payment_unallowed` varchar(255) COLLATE latin1_german1_ci NOT NULL,
  `shipping_unallowed` varchar(255) COLLATE latin1_german1_ci NOT NULL,
  `refferers_id` varchar(32) COLLATE latin1_german1_ci NOT NULL DEFAULT '0',
  `customers_date_added` datetime DEFAULT '0000-00-00 00:00:00',
  `customers_last_modified` datetime DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`customers_id`),
  KEY `idx_customers_email_address` (`customers_email_address`),
  KEY `idx_customers_default_address_id` (`customers_default_address_id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1 COLLATE=latin1_german1_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `customers`
--

LOCK TABLES `customers` WRITE;
/*!40000 ALTER TABLE `customers` DISABLE KEYS */;
INSERT INTO `customers` VALUES (1,NULL,NULL,0,NULL,0,'','Fabian','Schwarzbauer','0000-00-00 00:00:00','m.foerster@brainsquad.de',1,'',NULL,'$2a$08$oVnQ9rIcGVWtwKX8A6rfB.xZ6kbQIGdzwCcuuI7KZH6S.Luo9vYji',NULL,'0','0','0',0,'','0000-00-00 00:00:00','','','0','2019-02-05 19:45:21','2019-02-05 19:45:21');
/*!40000 ALTER TABLE `customers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `customers_basket`
--

DROP TABLE IF EXISTS `customers_basket`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `customers_basket` (
  `customers_basket_id` int(11) NOT NULL AUTO_INCREMENT,
  `customers_id` int(11) NOT NULL,
  `products_id` tinytext COLLATE latin1_german1_ci NOT NULL,
  `customers_basket_quantity` int(2) NOT NULL,
  `final_price` decimal(15,4) NOT NULL,
  `customers_basket_date_added` datetime DEFAULT NULL,
  PRIMARY KEY (`customers_basket_id`),
  KEY `idx_customers_id` (`customers_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_german1_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `customers_basket`
--

LOCK TABLES `customers_basket` WRITE;
/*!40000 ALTER TABLE `customers_basket` DISABLE KEYS */;
/*!40000 ALTER TABLE `customers_basket` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `customers_basket_attributes`
--

DROP TABLE IF EXISTS `customers_basket_attributes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `customers_basket_attributes` (
  `customers_basket_attributes_id` int(11) NOT NULL AUTO_INCREMENT,
  `customers_id` int(11) NOT NULL,
  `products_id` tinytext COLLATE latin1_german1_ci NOT NULL,
  `products_options_id` int(11) NOT NULL,
  `products_options_value_id` int(11) NOT NULL,
  PRIMARY KEY (`customers_basket_attributes_id`),
  KEY `idx_customers_id` (`customers_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_german1_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `customers_basket_attributes`
--

LOCK TABLES `customers_basket_attributes` WRITE;
/*!40000 ALTER TABLE `customers_basket_attributes` DISABLE KEYS */;
/*!40000 ALTER TABLE `customers_basket_attributes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `customers_info`
--

DROP TABLE IF EXISTS `customers_info`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `customers_info` (
  `customers_info_id` int(11) NOT NULL,
  `customers_info_date_of_last_logon` datetime DEFAULT NULL,
  `customers_info_number_of_logons` int(5) DEFAULT NULL,
  `customers_info_date_account_created` datetime DEFAULT NULL,
  `customers_info_date_account_last_modified` datetime DEFAULT NULL,
  `global_product_notifications` int(1) DEFAULT '0',
  PRIMARY KEY (`customers_info_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_german1_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `customers_info`
--

LOCK TABLES `customers_info` WRITE;
/*!40000 ALTER TABLE `customers_info` DISABLE KEYS */;
INSERT INTO `customers_info` VALUES (1,'2019-02-07 11:23:03',3,'2019-02-05 19:45:21',NULL,0);
/*!40000 ALTER TABLE `customers_info` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `customers_ip`
--

DROP TABLE IF EXISTS `customers_ip`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `customers_ip` (
  `customers_ip_id` int(11) NOT NULL AUTO_INCREMENT,
  `customers_id` int(11) NOT NULL DEFAULT '0',
  `customers_ip` varchar(50) COLLATE latin1_german1_ci NOT NULL DEFAULT '',
  `customers_ip_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `customers_host` varchar(255) COLLATE latin1_german1_ci NOT NULL DEFAULT '',
  `customers_advertiser` varchar(30) COLLATE latin1_german1_ci DEFAULT NULL,
  `customers_referer_url` varchar(255) COLLATE latin1_german1_ci DEFAULT NULL,
  PRIMARY KEY (`customers_ip_id`),
  KEY `idx_customers_id` (`customers_id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=latin1 COLLATE=latin1_german1_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `customers_ip`
--

LOCK TABLES `customers_ip` WRITE;
/*!40000 ALTER TABLE `customers_ip` DISABLE KEYS */;
INSERT INTO `customers_ip` VALUES (1,1,'','2019-02-05 19:45:37','dev-ng.ascasa.de','','dev-ng.ascasa.de/'),(2,1,'','2019-02-07 11:23:03','ng.ascasa.de','','ng.ascasa.de/login.php');
/*!40000 ALTER TABLE `customers_ip` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `customers_login`
--

DROP TABLE IF EXISTS `customers_login`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `customers_login` (
  `customers_ip` varchar(50) COLLATE latin1_german1_ci DEFAULT NULL,
  `customers_email_address` varchar(255) COLLATE latin1_german1_ci DEFAULT NULL,
  `customers_login_tries` int(11) NOT NULL,
  KEY `idx_customers_ip` (`customers_ip`),
  KEY `idx_customers_email_address` (`customers_email_address`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_german1_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `customers_login`
--

LOCK TABLES `customers_login` WRITE;
/*!40000 ALTER TABLE `customers_login` DISABLE KEYS */;
/*!40000 ALTER TABLE `customers_login` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `customers_memo`
--

DROP TABLE IF EXISTS `customers_memo`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `customers_memo` (
  `memo_id` int(11) NOT NULL AUTO_INCREMENT,
  `customers_id` int(11) NOT NULL DEFAULT '0',
  `memo_date` date NOT NULL DEFAULT '0000-00-00',
  `memo_title` text COLLATE latin1_german1_ci NOT NULL,
  `memo_text` text COLLATE latin1_german1_ci NOT NULL,
  `poster_id` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`memo_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_german1_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `customers_memo`
--

LOCK TABLES `customers_memo` WRITE;
/*!40000 ALTER TABLE `customers_memo` DISABLE KEYS */;
/*!40000 ALTER TABLE `customers_memo` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `customers_status`
--

DROP TABLE IF EXISTS `customers_status`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `customers_status` (
  `customers_status_id` int(11) NOT NULL DEFAULT '0',
  `language_id` int(11) NOT NULL,
  `customers_status_name` varchar(32) COLLATE latin1_german1_ci NOT NULL DEFAULT '',
  `customers_status_public` int(1) NOT NULL DEFAULT '1',
  `customers_status_min_order` int(7) DEFAULT NULL,
  `customers_status_max_order` int(7) DEFAULT NULL,
  `customers_status_image` varchar(64) COLLATE latin1_german1_ci DEFAULT NULL,
  `customers_status_discount` decimal(4,2) DEFAULT '0.00',
  `customers_status_ot_discount_flag` char(1) COLLATE latin1_german1_ci NOT NULL DEFAULT '0',
  `customers_status_ot_discount` decimal(4,2) DEFAULT '0.00',
  `customers_status_graduated_prices` varchar(1) COLLATE latin1_german1_ci NOT NULL DEFAULT '0',
  `customers_status_show_price` int(1) NOT NULL DEFAULT '1',
  `customers_status_show_price_tax` int(1) NOT NULL DEFAULT '1',
  `customers_status_show_tax_total` int(7) DEFAULT '150',
  `customers_status_add_tax_ot` int(1) NOT NULL DEFAULT '0',
  `customers_status_payment_unallowed` varchar(255) COLLATE latin1_german1_ci NOT NULL,
  `customers_status_shipping_unallowed` varchar(255) COLLATE latin1_german1_ci NOT NULL,
  `customers_status_discount_attributes` int(1) NOT NULL DEFAULT '0',
  `customers_fsk18` int(1) NOT NULL DEFAULT '1',
  `customers_fsk18_display` int(1) NOT NULL DEFAULT '1',
  `customers_status_write_reviews` int(1) NOT NULL DEFAULT '1',
  `customers_status_read_reviews` int(1) NOT NULL DEFAULT '1',
  `customers_status_reviews_status` int(1) NOT NULL DEFAULT '1',
  `customers_status_specials` int(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`customers_status_id`,`language_id`),
  UNIQUE KEY `idx_customers_status_name` (`customers_status_name`,`language_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_german1_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `customers_status`
--

LOCK TABLES `customers_status` WRITE;
/*!40000 ALTER TABLE `customers_status` DISABLE KEYS */;
INSERT INTO `customers_status` VALUES (0,2,'Admin',1,NULL,NULL,'admin_status.gif',0.00,'1',0.00,'1',1,1,150,0,'','',0,1,1,1,1,1,1),(0,1,'Admin',1,NULL,NULL,'admin_status.gif',0.00,'1',0.00,'1',1,1,150,0,'','',0,1,1,1,1,1,1),(1,2,'Gast',1,NULL,NULL,'guest_status.gif',0.00,'0',0.00,'0',1,1,150,0,'','',0,1,1,0,1,0,1),(1,1,'Guest',1,NULL,NULL,'guest_status.gif',0.00,'0',0.00,'0',1,1,150,0,'','',0,1,1,0,1,0,1),(2,2,'Neuer Kunde',1,NULL,NULL,'customer_status.gif',0.00,'0',0.00,'0',1,1,150,0,'','',0,1,1,1,1,1,1),(2,1,'New Customer',1,NULL,NULL,'customer_status.gif',0.00,'0',0.00,'0',1,1,150,0,'','',0,1,1,1,1,1,1),(3,2,'Händler',1,NULL,NULL,'merchant_status.gif',0.00,'0',0.00,'1',1,0,150,1,'','',0,1,1,1,1,1,0),(3,1,'Merchant',1,NULL,NULL,'merchant_status.gif',0.00,'0',0.00,'1',1,0,150,1,'','',0,1,1,1,1,1,0),(4,2,'Händler EU',1,NULL,NULL,'merchant_status.gif',0.00,'0',0.00,'1',1,0,150,0,'','',0,1,1,1,1,1,0),(4,1,'Merchant EU',1,NULL,NULL,'merchant_status.gif',0.00,'0',0.00,'1',1,0,150,0,'','',0,1,1,1,1,1,0);
/*!40000 ALTER TABLE `customers_status` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `customers_status_history`
--

DROP TABLE IF EXISTS `customers_status_history`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `customers_status_history` (
  `customers_status_history_id` int(11) NOT NULL AUTO_INCREMENT,
  `customers_id` int(11) NOT NULL DEFAULT '0',
  `new_value` int(5) NOT NULL DEFAULT '0',
  `old_value` int(5) DEFAULT NULL,
  `date_added` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `customer_notified` int(1) DEFAULT '0',
  PRIMARY KEY (`customers_status_history_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_german1_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `customers_status_history`
--

LOCK TABLES `customers_status_history` WRITE;
/*!40000 ALTER TABLE `customers_status_history` DISABLE KEYS */;
/*!40000 ALTER TABLE `customers_status_history` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `database_version`
--

DROP TABLE IF EXISTS `database_version`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `database_version` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `version` varchar(32) COLLATE latin1_german1_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1 COLLATE=latin1_german1_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `database_version`
--

LOCK TABLES `database_version` WRITE;
/*!40000 ALTER TABLE `database_version` DISABLE KEYS */;
INSERT INTO `database_version` VALUES (1,'MOD_2.0.4.2');
/*!40000 ALTER TABLE `database_version` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `geo_zones`
--

DROP TABLE IF EXISTS `geo_zones`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `geo_zones` (
  `geo_zone_id` int(11) NOT NULL AUTO_INCREMENT,
  `geo_zone_name` varchar(32) COLLATE latin1_german1_ci NOT NULL,
  `geo_zone_description` varchar(255) COLLATE latin1_german1_ci NOT NULL,
  `geo_zone_info` int(1) DEFAULT '0',
  `last_modified` datetime DEFAULT NULL,
  `date_added` datetime NOT NULL,
  PRIMARY KEY (`geo_zone_id`),
  UNIQUE KEY `idx_geo_zone_name` (`geo_zone_name`)
) ENGINE=MyISAM AUTO_INCREMENT=8 DEFAULT CHARSET=latin1 COLLATE=latin1_german1_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `geo_zones`
--

LOCK TABLES `geo_zones` WRITE;
/*!40000 ALTER TABLE `geo_zones` DISABLE KEYS */;
INSERT INTO `geo_zones` VALUES (5,'Steuerzone EU','Steuerzone für EU',0,NULL,'2019-02-05 19:45:22'),(6,'Steuerzone Nicht-EU-Ausland','Steuerzone für Nicht-EU-Ausland',1,NULL,'2019-02-05 19:45:22'),(7,'Steuerzone B2B','Steuerzone für B2B',0,NULL,'2019-02-05 19:45:22');
/*!40000 ALTER TABLE `geo_zones` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `languages`
--

DROP TABLE IF EXISTS `languages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `languages` (
  `languages_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(32) COLLATE latin1_german1_ci NOT NULL,
  `code` char(5) COLLATE latin1_german1_ci NOT NULL,
  `image` varchar(64) COLLATE latin1_german1_ci DEFAULT NULL,
  `directory` varchar(32) COLLATE latin1_german1_ci DEFAULT NULL,
  `sort_order` int(3) DEFAULT NULL,
  `language_charset` text COLLATE latin1_german1_ci NOT NULL,
  `status` int(1) NOT NULL DEFAULT '1',
  `status_admin` int(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`languages_id`),
  UNIQUE KEY `idx_code` (`code`),
  KEY `idx_status` (`status`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=latin1 COLLATE=latin1_german1_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `languages`
--

LOCK TABLES `languages` WRITE;
/*!40000 ALTER TABLE `languages` DISABLE KEYS */;
INSERT INTO `languages` VALUES (1,'English','en','icon.gif','english',2,'iso-8859-15',1,1),(2,'Deutsch','de','icon.gif','german',1,'iso-8859-15',1,1);
/*!40000 ALTER TABLE `languages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `manufacturers`
--

DROP TABLE IF EXISTS `manufacturers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `manufacturers` (
  `manufacturers_id` int(11) NOT NULL AUTO_INCREMENT,
  `manufacturers_name` varchar(64) COLLATE latin1_german1_ci NOT NULL,
  `manufacturers_image` varchar(64) COLLATE latin1_german1_ci DEFAULT NULL,
  `date_added` datetime DEFAULT NULL,
  `last_modified` datetime DEFAULT NULL,
  PRIMARY KEY (`manufacturers_id`),
  KEY `idx_manufacturers_name` (`manufacturers_name`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_german1_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `manufacturers`
--

LOCK TABLES `manufacturers` WRITE;
/*!40000 ALTER TABLE `manufacturers` DISABLE KEYS */;
/*!40000 ALTER TABLE `manufacturers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `manufacturers_info`
--

DROP TABLE IF EXISTS `manufacturers_info`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `manufacturers_info` (
  `manufacturers_id` int(11) NOT NULL,
  `languages_id` int(11) NOT NULL,
  `manufacturers_description` text COLLATE latin1_german1_ci,
  `manufacturers_meta_title` text COLLATE latin1_german1_ci NOT NULL,
  `manufacturers_meta_description` text COLLATE latin1_german1_ci NOT NULL,
  `manufacturers_meta_keywords` text COLLATE latin1_german1_ci NOT NULL,
  `manufacturers_url` varchar(255) COLLATE latin1_german1_ci NOT NULL,
  `url_clicked` int(5) NOT NULL DEFAULT '0',
  `date_last_click` datetime DEFAULT NULL,
  PRIMARY KEY (`manufacturers_id`,`languages_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_german1_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `manufacturers_info`
--

LOCK TABLES `manufacturers_info` WRITE;
/*!40000 ALTER TABLE `manufacturers_info` DISABLE KEYS */;
/*!40000 ALTER TABLE `manufacturers_info` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `module_backup`
--

DROP TABLE IF EXISTS `module_backup`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `module_backup` (
  `configuration_id` int(11) NOT NULL AUTO_INCREMENT,
  `configuration_key` varchar(64) COLLATE latin1_german1_ci NOT NULL,
  `configuration_value` text COLLATE latin1_german1_ci NOT NULL,
  `last_modified` datetime DEFAULT NULL,
  PRIMARY KEY (`configuration_id`),
  UNIQUE KEY `idx_configuration_key` (`configuration_key`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_german1_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `module_backup`
--

LOCK TABLES `module_backup` WRITE;
/*!40000 ALTER TABLE `module_backup` DISABLE KEYS */;
/*!40000 ALTER TABLE `module_backup` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `module_newsletter`
--

DROP TABLE IF EXISTS `module_newsletter`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `module_newsletter` (
  `newsletter_id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) COLLATE latin1_german1_ci NOT NULL,
  `bc` text COLLATE latin1_german1_ci NOT NULL,
  `cc` text COLLATE latin1_german1_ci NOT NULL,
  `date` datetime DEFAULT NULL,
  `status` int(1) NOT NULL DEFAULT '0',
  `body` text COLLATE latin1_german1_ci NOT NULL,
  PRIMARY KEY (`newsletter_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_german1_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `module_newsletter`
--

LOCK TABLES `module_newsletter` WRITE;
/*!40000 ALTER TABLE `module_newsletter` DISABLE KEYS */;
/*!40000 ALTER TABLE `module_newsletter` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `newsfeed`
--

DROP TABLE IF EXISTS `newsfeed`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `newsfeed` (
  `news_id` int(11) NOT NULL AUTO_INCREMENT,
  `news_title` varchar(128) COLLATE latin1_german1_ci DEFAULT NULL,
  `news_text` text COLLATE latin1_german1_ci,
  `news_link` varchar(128) COLLATE latin1_german1_ci DEFAULT NULL,
  `news_date` int(11) DEFAULT NULL,
  PRIMARY KEY (`news_id`),
  UNIQUE KEY `idx_news_link` (`news_link`)
) ENGINE=MyISAM AUTO_INCREMENT=21 DEFAULT CHARSET=latin1 COLLATE=latin1_german1_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `newsfeed`
--

LOCK TABLES `newsfeed` WRITE;
/*!40000 ALTER TABLE `newsfeed` DISABLE KEYS */;
INSERT INTO `newsfeed` VALUES (11,'Dauerthema und Dilemma für viele Onlinehändler: Fehlende Informationen zu einer bestehenden Garantie','Garantiewerbung ist seit Jahren ein Thema und zugleich Fallstrick für Onlinehändler. Wer aktiv mit einer Garantie wirbt, kann sich oft in erhebliche Abmahngefahr begeben. Was viele nicht wissen: Auch das Verschweigen von bestehenden Garantien stellt einen abmahnbaren Wettbewerbsverstoß dar ? ein ?Teufelskreis? mit entsprechender Sprengkraft für den Ecommerce!<br /><br />Aus dem Inhalt<br /><ul class=\"bbc_list\"><li>Worum geht es?</li><li>Doppelte Problemstellung</li><li>Erhebliche Schadwirkung für den Onlinehandel</li><li>Problem Nummer 1: Die aktive Garantiewerbung</li><li>Problem Nummer 2: Die unterlassene Information über eine bestehende Garantie</li><li>Problem Nummer 3: Händler drehen sich im Kreis?</li><li>Die Rechtslage ist leider eindeutig</li><li>Problematik bereits im Jahre 2016 durch das LG München I entschieden</li><li>Erhebliche Praxis- und Rechtsprobleme</li><li>Wie sollten Händler sich nun verhalten?</li><li>Exkurs: Unterschied zwischen Garantie und Gewährleistung</li><li>Fazit</li></ul>1. Worum geht es?<br />Aktuell liegt der IT-Recht Kanzlei eine Abmahnung des IDO-Verbands aus Leverkusen hinsichtlich angeblich unlauterer Garantiewerbung vor.<br /><br />Der abgemahnte Händler hatte pauschal mit einer bestehenden Garantie für die angebotene Ware geworben, ohne weitere Informationen zu dieser Garantie zu erteilen.<br />Soweit nicht ungewöhnlich, mahnt der IDO das aktive Werben mit Garantien - werden dabei die rechtlichen Rahmenbedingungen nicht erfüllt - doch schon seit Jahren hundertfach ab.<br />Bei genauerem Blick zeigt sich jedoch: Es wurde hier ein neuer Kurs eingeschlagen.<br />Der IDO vertritt in seiner Abmahnung die Ansicht, dass der abgemahnte Händler ? der hier aktiv mit einer Herstellgarantie geworben hatte ? künftig die Garantie nicht einfach verschweigen darf. Schließlich handele es ja um ein wesentliches Merkmal der Ware, besteht für diese Ware eine Herstellgarantie.<br /><br />Den vollständigen Beitrag finden Sie <a href=\"https://www.modified-shop.org/forum/index.php?action=seored;u=aHR0cHMlM0ElMkYlMkZ3d3cuaXQtcmVjaHQta2FuemxlaS5kZSUyRmZlaGxlbmRlLWluZm9ybWF0aW9uLXp1LWJlc3RlaGVuZGVyLWdhcmFudGllLWFibWFobnVuZy5odG1sJTNGcGFydG5lcl9pZCUzRDIx\" rel=\"nofollow\" onClick=\"recordOutboundLink(this, \'Outbound Links\', \'https://www.it-recht-kanzlei.de/fehlende-information-zu-bestehender-garantie-abmahnung.html?partner_id=21\'); return false;\" class=\"bbc_link new_win\" target=\"_blank\">hier</a>.<br /><br /><span class=\"smalltext\">Linkback: https://www.modified-shop.org/forum/index.php?topic=39988.0</span>','https://www.modified-shop.org/forum/index.php?topic=39988.0',1549299412),(12,'Geoblocking FAQ','Am 03.12.2018 trat die Geoblocking-Verordnung in Kraft. Hier finden Sie die Antworten auf die häufigsten Fragen.<br /><br /><strong>Was ist Geoblocking?</strong><br />Unter Geoblocking versteht man ganz im Allgemeinen die Unmöglichkeit einen Geschäft aufgrund des Wohnsitzes oder der Staatsangehörigkeit abzuschließen.<br /><br />Beispiel für Geoblocking durch Sperrung:<br />Maria aus Spanien möchte auf eine belgische Seite zugreifen. Dabei erscheint der Text, dass dieser Service für Kunden aus ihrem Land leider nicht verfügbar ist.<br /><br />Beispiel für Geoblocking durch Weiterleitung:<br />Als Maria auf eine andere belgische Seite zugreifen möchte, wird sie automatisch auf eine spanische Domain weitergeleitet. Dort findet sie die Produkte zu einem teureren Preis.<br /><br />Beispiel für Geoblocking im Bestellvorgang:<br />Schließlich gelingt es Maria tatsächlich einen belgischen Shop zu finden, auf den sie auch tatsächlich zugreifen möchte. Nach Befüllen des Warenkorbs wählt sie als Zahlungsmethode das Lastschriftverfahren aus. Hier wartet aber bereits die nächste Hürde: Durch eine Voreinseinstellung kann sie lediglich belgische IBANs eingeben.<br /><br /><strong>Warum soll Geoblocking reguliert werden?</strong><br />Im Binnenmarkt soll Warenverkehr über die Landesgrenzen hinweg unproblematisch möglich sein. Es ist nicht mit dieser Freiheit vereinbar, dass Unternehmer im Internet Menschen aufgrund ihrer Staatsangehörigkeit oder ihres Wohnsitzes aussperren. Daher soll die Regulation von Geoblocking die Grenzen auch im virtuellen Raum fallen lassen. Daraus soll eine Stärkung des Binnenmarktes folgen.<br /><br /><strong>Für wen gilt sie?</strong><br />Die Verordnung gilt für Anbieter von Waren und Dienstleistern, sowie für Kunden. Das Besondere: Unter Kunden versteht man in diesem Sinn nicht nur Verbraucher, sondern auch Unternehmer, sofern sie Produkte erwerben, die nicht zum Weiterverkauf gedacht sind, wie zum Beispiel Büromaterial.<br /><br /><strong>Welche Länder sind betroffen?</strong><br />Die Geoblocking-Verordnung gilt für den europäischen Binnenmarkt, also für den Europäischen Wirtschaftsraum. Zu diesem Wirtschaftsraum zählen die Staaten der EU, zuzüglich Island, Liechtenstein und Norwegen.<br /><br /><strong>Gilt die Verordnung für alle Wirtschaftssektoren?</strong><br />Nein, die Geoblocking-Verordnung sieht zahlreiche Ausnahmen vor. Sie gilt nicht für:<br /><ul class=\"bbc_list\"><li>Finanzdienstleistungen</li><li>Gesundheitsleistungen</li><li>audiovisuelle Dienste, insb. Streaming- und Downloaddienste</li><li>Leiharbeit</li><li>Telekommunikation</li><li>soziale Dienste</li><li>Glücksspiel</li><li>Sicherheitsdienste</li></ul><strong>Welche Zahlungsmethoden muss ich anbieten?</strong><br />Die Verordnung verpflichtet Händler nicht dazu, jedes im Binnenmarkt vorkommende Zahlungsmittel anzunehmen. Sie sind weiterhin frei in der Wahl, <a href=\"https://www.modified-shop.org/forum/index.php?action=seored;u=aHR0cHMlM0ElMkYlMkZ3d3cub25saW5laGFlbmRsZXItbmV3cy5kZSUyRmUtcmVjaHQlMkZnZXNldHplJTJGMzI2NzctZ2VvYmxvY2tpbmctdmVyb3JkbnVuZy10ZWlsLTYtemFobHVuZ3NtZXRob2Rlbi16dXJ1ZWNrYmVoYWx0dW5nc3JlY2h0\" rel=\"nofollow\" onClick=\"recordOutboundLink(this, \'Outbound Links\', \'https://www.onlinehaendler-news.de/e-recht/gesetze/32677-geoblocking-verordnung-teil-6-zahlungsmethoden-zurueckbehaltungsrecht\'); return false;\" class=\"bbc_link new_win\" target=\"_blank\">welche Zahlungsmethoden sie anbieten</a>. Allerdings müssen die Bedingungen für alle gleich sein. Das bedeutet, dass eine Mastercard gleich eine Mastercard ist und zwar unabhängig davon, wo der Standort des Zahlungskontos ist, wo sich die Niederlassung des Zahlungsdienstleisters befindet oder welche Adresse der Ausstellungsort des Zahlungsinstrumentes hat.<br /><br />Zum Beispiel: Akzeptiert die Händlerin die Kreditkarte der Marke der A, muss sie nicht auch gleichzeitig die Debitkarte der Marke A oder die Kreditkarte der Marke B annehmen.<br /><br /><strong>Muss ich in jedes Land liefern?</strong><br />Nein! Händler dürfen weiterhin frei entscheiden, in welches Land sie zu welchen Bedingungen liefern. Allerdings darf einem Kunden, der nicht im Liefergebiet lebt, der Vertragsschluss nicht deswegen verweigert werden. Vielmehr ist der Kunde in der Pflicht, eine Lieferadresse anzugeben, an die der Händler eine Lieferung anbietet.<br /><br />Zum Beispiel: Maria aus Spanien bestellt in einem deutschen Shop eine Miniatur des Brandenburger Tors. Der Shop bietet keine Lieferung nach Spanien an. Maria gibt daher die Adresse einer in Deutschland lebenden Verwandten ein und organisiert von da aus den Rest der Lieferung selbst.<br /><br /><strong>Muss ich Abholstellen für Kunden einrichten, für die ich keinen Versand anbiete?</strong><br />Nein, hier gilt dasselbe wie bei den Lieferbedingungen: Der Händler ist nicht verpflichtet, eine Abholmöglichkeit zu schaffen. Bietet er aber ohnehin eine Selbstabholung an, so muss er dies für alle tun.<br /><br />Zum Beispiel: Maria bestellt in Frankreich einen Sessel. Der Shop liefert zwar nicht nach Spanien, bietet aber eine Selbstabholung an. Da sich das Logistikzentrum direkt an der Grenze befindet, holt sie die Ware selbst ab.<br /><br /><strong>Welche Adresse müssen Kunden angeben können?</strong><br />Händler dürfen bei der Lieferadresse Einschränkungen treffen, da sie nicht verpflichtet sind, in jedes Land des Europäischen Wirtschaftraums zu liefern. Anders sieht es aber bei der Rechnungsadresse aus: Da notwendiger Inhalt der Rechnung die Wohnanschrift des Kunden ist, muss es hier möglich sein, alle Anschriften aus dem Binnenmarkt angeben zu können.<br /><br /><strong>Was ist mit Weiterleitungen?</strong><br />Es ist gang und gäbe, für den internationalen Handel pro Land andere Domains vorzuhalten. Diese sind spezifisch auf die bestimmten Länder ausgerichtet. Händler dürfen auch weiterhin unterschiedliche Seiten vorhalten. Lediglich die automatische Weiterleitung ist verboten. Was aber erlaubt ist, ist die Weiterleitung mit Erlaubnis. Diese Erlaubnis kann sich der Händler über ein Popup-Fenster vom Seitenbesucher einholen. Stimmt der Kunde zu, darf diese Zustimmung als Einstellung im Kundenkonto hinterlegt werden. Wichtig ist nur, dass der Kunde seine Zustimmung jederzeit widerrufen kann.<br /><br /><strong>Welche Rechtsvorschriften finden Anwendung?</strong><br />Hier ist zu unterscheiden, ob ein Händler sein Geschäfts auf ein Land ausgerichtet hat. Unter Ausrichten versteht man kurz gesagt das Bemühen um Kunden aus dem jeweiligen Land. Bietet ein Händler eine Lieferung in ein bestimmtes Land an, so ist davon auszugehen, dass er <a href=\"https://www.modified-shop.org/forum/index.php?action=seored;u=aHR0cHMlM0ElMkYlMkZ3d3cub25saW5laGFlbmRsZXItbmV3cy5kZSUyRmUtcmVjaHQlMkZnZXNldHplJTJGMzI3MDQtZ2VvYmxvY2tpbmctdmVyb3JkbnVuZy10ZWlsLTctYXVzZ2VyaWNodGV0ZS1zaG9w\" rel=\"nofollow\" onClick=\"recordOutboundLink(this, \'Outbound Links\', \'https://www.onlinehaendler-news.de/e-recht/gesetze/32704-geoblocking-verordnung-teil-7-ausgerichtete-shop\'); return false;\" class=\"bbc_link new_win\" target=\"_blank\">sein Geschäft auch auf dieses Land ausgerichtet hat</a>.<br /><br />Bestellt ein Kunde aus einem Land, nach welchem der Händler sein Geschäft nicht ausgerichtet hat, so finden die nationalen Bestimmungen des Händlers Anwendung.<br /><br />Die nationalen Gesetze des Kunden werden erst dann relevant, wenn der Händler sein Geschäft auf dieses Land ausgerichtet hat.<br /><br /><strong>Muss ich alle meine Seiten mit dem gleichen Angebot bestücken?</strong><br />Nein. Die Verordnung erkennt an, dass Händler gute Gründe haben, in unterschiedlichen Ländern unterschiedliche Angebote zu gestalten. Kaufkraft und Nachfrage können stark variieren.<br /><br />Zum Beispiel wird die Nachfrage für erzgebirgische Handwerkskunst in Spanien anders sein als in Deutschland. Man kann einen anderen Preis verlangen und auch die Kaufkraft der spanischen Kunden ist vielleicht eine andere.<br /><br /><strong>Unter welchen Umständen ist Geoblocking gerechtfertigt?</strong><br />Manchmal ist Geoblocking aber auch notwendig, um nationale Bestimmungen einzuhalten. Dann handelt es sich um gerechtfertigtes Geoblocking.<br /><br />Erlaubtes Geoblocking wegen nationalen Verboten:<br />Eine Händlerin bietet europaweit Böller und Feuerwerkskörper an. Da der Verkauf nach Deutschland nur in einem bestimmten Zeitraum zu Silvester erlaubt ist, werden deutsche IP-Adressen den Rest des Jahres geblockt.<br /><br />Erlaubtes Geoblocking wegen notwendiger Preisgestaltung:<br />Ein Händler vertreibt europaweit Wein. In Schweden wird Alkohol aber ganz anders besteuert. Besucht ein Kunde mit schwedischer IP-Adresse den Shop, werden die Preise automatisch angepasst.<br /><br /><strong>Der Händlerbund hilft!</strong><br />Die rechtliche Absicherung ihrer Internetpräsenzen verursacht vielen Online-Händlern einen enormen Mehraufwand. Der Händlerbund steht Ihnen bei juristischen Fragen als kompetenter Partner zur Seite. Wenn Sie sich als Händler jetzt für die umfangreichen Rechtsdienstleistungen des Händlerbundes entscheiden, erhalten Sie mit dem <strong>Rabattcode P653#M1#2013</strong> einen <strong>Nachlass von 3 Monaten</strong> auf das Mitgliedschaftspaket Ihrer Wahl. <strong><a href=\"https://www.modified-shop.org/forum/index.php?action=seored;u=aHR0cHMlM0ElMkYlMkZ3d3cuaGFlbmRsZXJidW5kLmRlJTJGbW9kaWZpZWQ=\" rel=\"nofollow\" onClick=\"recordOutboundLink(this, \'Outbound Links\', \'https://www.haendlerbund.de/modified\'); return false;\" class=\"bbc_link new_win\" target=\"_blank\">Jetzt informieren!</a></strong><br /><br /><span class=\"smalltext\">Linkback: https://www.modified-shop.org/forum/index.php?topic=39889.0</span>','https://www.modified-shop.org/forum/index.php?topic=39889.0',1547028484),(13,'Gedrucktes \"Handbuch für Shopbetreiber\" in zweiter Auflage veröffentlicht','Im Oktober 2016 erschien das gedruckte \"Handbuch für Shopbetreiber\". Seitdem hat sich Einiges getan. Neue modified eCommerce Shopversionen wurden veröffentlicht und die Datenschutzgrundverordnung hat viele Shopbetreiber verunsichert.<br /><br />Aufgrund des Interesses und der guten Resonanz wurde die 2. Auflage des Handbuchs hinsichtlich einiger Shopfunktionen überarbeitet und erweitert. Es ist bereits seit einigen Wochen im Buchhandel unter der ISBN 978-3-746755-21-2 erhältlich. <br />Weiterhin eingeflossen sind die Recherchen der Autorin zur DSGVO. <br />Hinweis: Die Informationen hierzu stellen selbstverständlich keine Rechtsauskunft dar. Alle Angaben sind ohne Gewähr für Richtigkeit, Aktualität und Vollständigkeit und es besteht keinerlei Haftung für mögliche Rechtsfolgen.<br />Eine PDF-Datei mit einer Sammlung von vielen hilfreichen Informationsseiten und weiteren Information zum Thema steht beim Kauf direkt im Onlineshop der Autorin zum Download bereit.<br /><br />Auch die zweite Auflage des \"Handbuchs für Shopbetreiber\" richtet sich wieder speziell an alle aktuellen und zukünftigen Shopbetreiber, die modified eCommerce Shopsoftware im Detail kennenlernen möchten und eine fundierte Anleitung für die tägliche Arbeit mit dem Adminbereich wünschen. Wenn das Handbuch sukzessive durchgearbeitet wird, entsteht ein Shop mit allen Funktionen die das System bietet. Installation, Templatebearbeitung und Modulprogrammierung ist aufgrund dessen bewusst ausgeklammert.<br /><br />Die Druckausgabe beinhaltet 332 Seiten im Format DIN A5 hochkant, diverse Abbildungen und ist intuitiv aufgebaut.<br />Programmierkenntnisse sind nicht erforderlich. Installation, Programmierung etc. sind bewusst ausgeklammert.<br /><br />Das Buch ist im Buchhandel unter der ISBN: 978-3-746755-21-2 und direkt bei der Autorin erhältlich: <span class=\"bbc_u\"><strong><a href=\"https://www.modified-shop.org/forum/index.php?action=seored;u=aHR0cHMlM0ElMkYlMkZuZXctYnVzaW5lc3MtY29uc3VsdGluZy5kZSUyRnNob3AlMkZTaG9wYmV0cmVpYmVyLUhhbmRidWNoLW1vZGlmaWVkLWVDb21tZXJjZS0yLTAtMi1BdWZsYWdlJTJGSGFuZGJ1Y2gtZnVlci1TaG9wYmV0cmVpYmVyLTItQXVmbGFnZSUzQSUzQTE4Lmh0bWw=\" rel=\"nofollow\" onClick=\"recordOutboundLink(this, \'Outbound Links\', \'https://new-business-consulting.de/shop/Shopbetreiber-Handbuch-modified-eCommerce-2-0-2-Auflage/Handbuch-fuer-Shopbetreiber-2-Auflage::18.html\'); return false;\" class=\"bbc_link new_win\" target=\"_blank\">Klick mich!</a></strong></span><br /><br /><span class=\"smalltext\">Linkback: https://www.modified-shop.org/forum/index.php?topic=39683.0</span>','https://www.modified-shop.org/forum/index.php?topic=39683.0',1541674497),(14,'Online-Workshop und DSGVO compliance Schutzpaket','<div style=\"text-align: right;\"> [ Für Gäste sind keine Dateianhänge sichtbar ] </div><br /><img src=\"https://www.modified-shop.org/images/banner-to-topic/topic-id-39640-PS_dsgvo_workshop_banner.jpg\" alt=\"\" width=\"365\" height=\"164\" class=\"bbc_img resized\" /><br /><br /><strong>Liebe Leserinnen und Leser,</strong><br /><br />Seit dem 25. Mai 2018 ist die Datenschutzgrundverordnung (DSGVO) in Kraft. Es gab in der Anfangsphase viel Verunsicherung zu den Anforderungen an kleine Unternehmen, die sich inzwischen geklärt haben. Sollten Sie sich bisher immer noch nicht um das Verarbeitungsverzeichnis gekümmert haben, gelten jetzt keine Ausreden mehr, die Notwendigkeit dieser Dokumentation ist unbestritten.<br />Verpassen Sie nicht, noch dieses Jahr mit der Umsetzung anzufangen, um zu zeigen, dass Sie den Datenschutz ernst nehmen und um Bußgelder zu vermeiden.<br /><br /><strong>Das passende Angebot unseres Partners Protected Shops:</strong><br /><ul class=\"bbc_list\"><li>90 minütiger Online-Workshop ?Der einfache Weg zum Verzeichnis von Verarbeitungstätigkeiten?</li><li>3 Monate Zugriff auf Inhalte des DSGVO compliance Schutzpaket</li></ul><strong>für einmalig 249 Euro (zzgl. Ust.)</strong><br /><br /><em>Ab dem 4. Monat lediglich 9,90 Euro (zzgl. Ust.) monatlich bei jährlicher Zahlungsweise für Zugriff auf Inhalte des DSGVO compliance Schutzpaketes.</em><br /><br /><strong>Die nächsten freien Termine für einen Online-Workshop:</strong><br /><ul class=\"bbc_list\"><li>07.November 2018, 15:30 - 17:00 Uhr</li><li>16.November 2018, 10:30 - 12:00 Uhr</li><li>22.November 2018, 15:30 - 17:00 Uhr</li><li>28.November 2018, 10:30 - 12:00 Uhr</li></ul>Jetzt die Vorgaben der DSGVO komfortabel und rechtssicher umsetzen.<br /><br /><a href=\"https://www.modified-shop.org/forum/index.php?action=seored;u=aHR0cHMlM0ElMkYlMkZ3d3cucHJvdGVjdGVkc2hvcHMuZGUlMkZkc2d2byUyRmRzZ3ZvLWNvbXBsaWFuY2UtaW5rbHVzaXZlLW9ubGluZS13b3Jrc2hvcCUzRnNQYXJ0bmVyJTNEbW9kaWZpZWQ=\" rel=\"nofollow\" onClick=\"recordOutboundLink(this, \'Outbound Links\', \'https://www.protectedshops.de/dsgvo/dsgvo-compliance-inklusive-online-workshop?sPartner=modified\'); return false;\" class=\"bbc_link new_win\" target=\"_blank\">DSGVO compliance Schutzpaket inkl. Online-Workshop bestellen</a><br /><br /><strong>NEU:</strong> Für Kunden mit DSGVO compliance Paket bietet unser Partner Protected Shops nun DATENSCHUTZERKLÄRUNG und IMPRESSUM für Ihre \"Webseite OHNE Shop-Funktion\" gratis an. Nähere Informationen im persönlichen Kundenlogin von <a href=\"https://www.modified-shop.org/forum/index.php?action=seored;u=aHR0cHMlM0ElMkYlMkZ3d3cucHJvdGVjdGVkc2hvcHMuZGUlMkYlM0ZzUGFydG5lciUzRG1vZGlmaWVk\" rel=\"nofollow\" onClick=\"recordOutboundLink(this, \'Outbound Links\', \'https://www.protectedshops.de/?sPartner=modified\'); return false;\" class=\"bbc_link new_win\" target=\"_blank\">www.protectedshops.de</a> im Bereich \"DSGVO - Verzeichnis für Verarbeitungstätigkeiten\".<br /><br /><strong>Setzen Sie gemeinsam mit unserem Partner Protected Shops in wenigen Schritten wesentliche Vorgaben der DSGVO um</strong><br /><br />Erfüllen Sie mit dem Generator für das Verzeichnis von Verarbeitungstätigkeiten einfach und komfortabel die Dokumentationspflichten nach der DSGVO.<br /><strong>Beginnen Sie noch 2018</strong> (!), um ein aktives Führen des Verzeichnisses von Verarbeitungstätigkeiten lückenlos nachweisen zu können.<br />Mit dem exklusiven <strong>Online Workshop ?Der einfache Weg zum Verzeichnis für Verarbeitungstätigkeiten?</strong> hilft Ihnen unser Partner Protected Shops bei den ersten Schritten zum Anlegen des Verzeichnisses.<br /><br /><img src=\"https://www.modified-shop.org/images/banner-to-topic/topic-id-39640-PS_workshop_grafik.png\" alt=\"\" width=\"365\" height=\"202\" class=\"bbc_img resized\" /><br /><br /><em>Der Online-Workshop ist nur Teilnehmern zugänglich, welche das Schutzpaket ?DSGVO compliance inkl. Online-Workshop? gebucht haben.</em><br /><br />In kleinen Gruppen werden offene Fragen geklärt und das Erstellen des Verarbeitungsverzeichnisses wird mit dem Protected Shops Generator so einfach wie möglich.<br /><br /><strong>Interaktiver Workshop:</strong><br /><ul class=\"bbc_list\"><li>maximal 10 Teilnehmer</li><li>Markus Kluge, Geschäftsführer der Protected Shops, führt Sie persönlich durch das Thema Erstellung des Verarbeitungsverzeichnisses</li><li>Ca. 90 Minuten Online-Workshop zu den Hintergründen und zur Bedienung des Generators</li><li>Erste gemeinsame Schritte zum Anlegen des eigenen Verzeichnisses</li><li>Klärung individueller Fragen</li></ul>Jetzt die Vorgaben der DSGVO komfortabel und rechtssicher umsetzen.<br /><br /><a href=\"https://www.modified-shop.org/forum/index.php?action=seored;u=aHR0cHMlM0ElMkYlMkZ3d3cucHJvdGVjdGVkc2hvcHMuZGUlMkZkc2d2byUyRmRzZ3ZvLWNvbXBsaWFuY2UtaW5rbHVzaXZlLW9ubGluZS13b3Jrc2hvcCUzRnNQYXJ0bmVyJTNEbW9kaWZpZWQ=\" rel=\"nofollow\" onClick=\"recordOutboundLink(this, \'Outbound Links\', \'https://www.protectedshops.de/dsgvo/dsgvo-compliance-inklusive-online-workshop?sPartner=modified\'); return false;\" class=\"bbc_link new_win\" target=\"_blank\">DSGVO compliance Schutzpaket inkl. Online-Workshop bestellen</a><br /><br /><strong>DSGVO compliance Paket inklusive Online-Workshop</strong><br /><br /><img src=\"https://www.modified-shop.org/images/banner-to-topic/topic-id-39640-PS_dsgvo_compliance_workshop_paket.png\" alt=\"\" width=\"365\" height=\"387\" class=\"bbc_img resized\" /><br /><br /><ul class=\"bbc_list\"><li>Generelle Prüfung der DSGVO compliance des Onlinehändlers durch entwickelten ?Self-Audit?.</li><li>Einzelne Verfahren werden mittels eines intuitiven Erstellungsprozesses individuell erstellt.</li><li>Rechtssicherheit durch kontinuierliche Pflege und Erweiterung durch Rechtsdienstleister Protected Shops.</li><li>Mit vorgefertigten Vorlagen (ständig erweitertes Portfolio) für gängige Verarbeitungstätigkeiten zur Webanalyse, Bestellabwicklung oder zum Newsletter-Versand wird Ihnen das Anlegen des Verzeichnisses für Verarbeitungstätigkeiten leicht gemacht.</li><li>Mit Online-Workshop ?Der einfache Weg zum Verarbeitungsverzeichnis? hilft Ihnen unser Partner Protected Shops das Verzeichnis schnell, komfortabel und rechtssicher anzulegen. Dabei wird auf Ihre individuellen Situationen und Fragen eingegangen.</li></ul><a href=\"https://www.modified-shop.org/forum/index.php?action=seored;u=aHR0cHMlM0ElMkYlMkZ3d3cucHJvdGVjdGVkc2hvcHMuZGUlMkZkc2d2byUyRmRzZ3ZvLWNvbXBsaWFuY2UtaW5rbHVzaXZlLW9ubGluZS13b3Jrc2hvcCUzRnNQYXJ0bmVyJTNEbW9kaWZpZWQ=\" rel=\"nofollow\" onClick=\"recordOutboundLink(this, \'Outbound Links\', \'https://www.protectedshops.de/dsgvo/dsgvo-compliance-inklusive-online-workshop?sPartner=modified\'); return false;\" class=\"bbc_link new_win\" target=\"_blank\">DSGVO compliance Schutzpaket inkl. Online-Workshop bestellen</a><br /><br /><em>Sie erhalten für 249¤ (zzgl. Ust.) dreimonatigen Zugriff auf die Inhalte des DSGVO compliance Paketes inklusive Online-Workshop.<br />Sofern innerhalb der ersten drei Monaten keine Kündigung eingeht, wandelt sich der Vertrag in ein einjähriges Schutzpaket um, welcher drei Monate zum Vertragsjahresende gekündigt werden kann und sich ansonsten um jeweils ein weiteres Jahr verlängert. Ab dem 4. Monat kostet das Schutzpaket 9,90¤ monatlich zzgl. Ust. bei jährlicher Zahlungsweise.</em><br /><br /><strong>Rechtstexte für Ihre \"Webseite ohne Shop-Funktion\" jetzt gratis!</strong><br /><br /><img src=\"https://www.modified-shop.org/images/banner-to-topic/topic-id-39640-PS_rechtstexte_basis.png\" alt=\"\" width=\"305\" height=\"439\" class=\"bbc_img resized\" /><br /><br />Für Kunden unseres Partner Protected Shops mit DSGVO compliance Paket bietet unser Partner nun <strong>DATENSCHUTZERKLÄRUNG</strong> und <strong>IMPRESSUM</strong> für Ihre <strong>\"Webseite OHNE Shop-Funktion\"</strong> gratis an. Nach Bestellung mit speziellem Gutschein-Code finden Sie die Rechtstexte unter Start -> Rechtstexte -> Rechtstextkonfigurator.<br /><br /><a href=\"https://www.modified-shop.org/forum/index.php?action=seored;u=aHR0cHMlM0ElMkYlMkZ3d3cucHJvdGVjdGVkc2hvcHMuZGUlMkZhY2NvdW50JTJGbG9naW4lM0ZzUGFydG5lciUzRG1vZGlmaWVk\" rel=\"nofollow\" onClick=\"recordOutboundLink(this, \'Outbound Links\', \'https://www.protectedshops.de/account/login?sPartner=modified\'); return false;\" class=\"bbc_link new_win\" target=\"_blank\">Nähere Informationen im persönlichen Kundenlogin von Protected Shops im Bereich \"DSGVO - Verzeichnis für Verarbeitungstätigkeiten\".</a><br /><br />Kunden ohne DSGVO compliance Schutzpaket können die Rechtstexte für \"Webseiten OHNE Shop-Funktion\" regulär für 5,90 Euro monatlich zzgl. Ust. bei jährlicher Zahlweise erwerben.<br /><br />Inklusive ist die Haftungsübernahmegarantie und kostenfreie Updates während der Laufzeit bei Änderung der rechtlichen Gegebenheiten.<br /><br /><a href=\"https://www.modified-shop.org/forum/index.php?action=seored;u=aHR0cHMlM0ElMkYlMkZ3d3cucHJvdGVjdGVkc2hvcHMuZGUlMkZkZXRhaWwlMkZpbmRleCUyRnNBcnRpY2xlJTJGOTElM0ZzUGFydG5lciUzRG1vZGlmaWVk\" rel=\"nofollow\" onClick=\"recordOutboundLink(this, \'Outbound Links\', \'https://www.protectedshops.de/detail/index/sArticle/91?sPartner=modified\'); return false;\" class=\"bbc_link new_win\" target=\"_blank\">Rechtstexte für \"Webseiten OHNE Shopfunktion\" - regulär</a><br /><br /><span class=\"smalltext\">Linkback: https://www.modified-shop.org/forum/index.php?topic=39640.0</span>','https://www.modified-shop.org/forum/index.php?topic=39640.0',1540912077),(15,'Leitfaden: E-Mail-Marketing in Zeiten der DSGVO','Auch in DSGVO-Zeiten hat das Versenden von Werbe-E-Mails nichts an Bedeutung eingebüßt. Diese immer noch äußerst effektive und vor allem kostengünstige Form der Werbung erfreut sich weiterhin großer Beliebtheit. Welche Vorgaben gilt es allerdings zu beachten? Was ist unter Geltung der DSGVO noch möglich und wie kann ein Online-Händler seinem Pflichtenprogramm bestmöglich nachkommen? Die IT-Recht Kanzlei hat einen Leitfaden erstellt und sowohl die aktuelle Rechtsprechung, als auch die besonderen gesetzlichen Anforderungen einmal kompakt zusammengefasst.<br /><br />Aus dem Inhalt:<br /><ul class=\"bbc_list\"><li>E-Mail-Marketing rechtssicher gestalten ? ein kurzer Überblick</li><li>DSGVO: Was ändert sich in Bezug auf die E-Mail-Werbung?<br /><ul class=\"bbc_list\"><li>Datenschutz nur bei personenbezogenen Daten</li><li>Rechtfertigung der Datenerhebung</li><li>KEINE datenschutzrechtliche Einwilligung bei E-Mail-Werbung erforderlich, aber ?</li></ul></li><li>Grundregel für E-Mail-Marketing: Vorherige ausdrückliche Einwilligung erforderlich<br /><ul class=\"bbc_list\"><li>Welche Voraussetzungen muss eine wirksame Einwilligungserklärung erfüllen?</li><li>Einwilligungserklärung für verschiedene Werbekanäle</li><li>Wer trägt die Beweislast für das Vorliegen der Einwilligung?</li><li>Wie lange gelten Einwilligungen in zeitlicher Hinsicht?</li><li>Erteilte Einwilligungen (vor Geltung der DSGVO) behalten (grundsätzlich) ihre Gültigkeit</li></ul></li><li>Ausnahme von der Grundregel: Einwilligung kann nach § 7 Abs. 3 UWG bei Bestandskunden entbehrlich sein<br /><ul class=\"bbc_list\"><li>Erhebung der E-Mail-Adresse in Zusammenhang mit einem Produktverkauf</li><li>Verwendung für eigene ähnliche Produkte</li><li>Kein Widerspruch des Empfängers</li><li>Information über die Widerspruchsmöglichkeit des Empfängers</li><li>Alle Voraussetzungen des § 7 Abs. 3 UWG müssen vorliegen</li></ul></li><li>Erforderlich: Informationen in der eigenen Datenschutzerklärung</li><li>Was muss beim E-Mail-Marketing bei der inhaltlichen Ausgestaltung der Mails beachtet werden?<br /><ul class=\"bbc_list\"><li>Gebot der Identifizierbarkeit</li><li>Impressumspflicht in der Werbe-E-Mail (z.B. Newsletter)</li><li>Transparenz in Sachen Preisangaben und Lieferkosten</li></ul></li><li>Einzelfragen und-probleme<br /><ul class=\"bbc_list\"><li>Weiterempfehlung durch Freunde (tell-a-friend-Funktion)</li><li>Kundenzufriedenheitsanfrage (sog. Feedback-Anfrage) grundsätzlich nur mit Opt-In</li><li>Werbung in Double-Opt-In- und Auto-Reply-Nachrichten nur mit Opt-In</li><li>Sonderfall: Produkt-Upgrade-Mail an registrierte Nutzer</li></ul></li><li>Was droht bei Verstößen?</li><li>Fazit</li></ul>Den vollständigen Beitrag finden Sie <a href=\"https://www.modified-shop.org/forum/index.php?action=seored;u=aHR0cHMlM0ElMkYlMkZ3d3cuaXQtcmVjaHQta2FuemxlaS5kZSUyRnJlY2h0c3NpY2hlcmUtZS1tYWlsLXdlcmJ1bmcuaHRtbCUzRnBhcnRuZXJfaWQlM0QyMQ==\" rel=\"nofollow\" onClick=\"recordOutboundLink(this, \'Outbound Links\', \'https://www.it-recht-kanzlei.de/rechtssichere-e-mail-werbung.html?partner_id=21\'); return false;\" class=\"bbc_link new_win\" target=\"_blank\">hier</a>.<br /><br /><span class=\"smalltext\">Linkback: https://www.modified-shop.org/forum/index.php?topic=39582.0</span>','https://www.modified-shop.org/forum/index.php?topic=39582.0',1539869743),(16,'?Ratenkauf ist nicht gleich Ratenkauf.? ? jetzt kostenfrei testen!','<a href=\"https://www.modified-shop.org/forum/index.php?action=seored;u=aHR0cHMlM0ElMkYlMkZ3d3cuZWFzeWNyZWRpdC1yYXRlbmthdWYuZGUlMkZyZWdpc3RyaWVydW5nLW1vZGlmaWVkLmh0bSUzRnV0bV9zb3VyY2UlM0RwYXJ0bmVyc2VpdGUlMjZhbXAlM0J1dG1fbWVkaXVtJTNEbGluayUyNmFtcCUzQnV0bV9jYW1wYWlnbiUzRE1vZGlmaWVk\" rel=\"nofollow\" onClick=\"recordOutboundLink(this, \'Outbound Links\', \'https://www.easycredit-ratenkauf.de/registrierung-modified.htm?utm_source=partnerseite&utm_medium=link&utm_campaign=Modified\'); return false;\" class=\"bbc_link new_win\" target=\"_blank\"><img src=\"https://www.modified-shop.org/images/banner-to-topic/topic-id-39520-365x228_ratenkauf_by_easycredit.png\" alt=\"\" width=\"365\" height=\"228\" class=\"bbc_img resized\" /></a><br /><br />Einen Ratenkauf im Onlineshop anzubieten gehört für viele Händler zum Standard-Zahlungsmix dazu ? schlicht und ergreifend deshalb, weil Kunden ihn mittlerweile fordern. Doch häufig bringt dies ein finanzielles Risiko für den Händler mit sich und externe Lösungen sind so komplex konstruiert, dass der Check-out für den Kunden eher zum Albtraum, als zum Erlebnis wird.<br />Die TeamBank AG, der Anbieter von ratenkauf by easyCredit, hat eine Lösung entwickelt, die nicht ohne Grund verspricht, die ?einfachste Teilzahlungslösung Deutschlands? zu sein.<br /><br /><strong>Schlanker Bestellprozess, höhere Warenkörbe, weniger Kaufabbrüche</strong><br /><br />Der Bestellprozess ist einer der wichtigsten Prozesse für einen Händler und unterliegt ständiger Optimierung. Besonders ärgerlich ist es also, einen Kunden durch die falschen oder komplizierten Zahlungsarten zu verlieren. Der schlanke Bestellprozess von ratenkauf by easyCredit ohne PostIdent und mit verbindlicher Sofortzusage macht es dem Kunden ganz einfach. Hat der Händler die notwendigen Stammdaten des Kunden eingeholt, kann die TeamBank AG mit lediglich vier persönlichen Angaben entscheiden, ob ein Ratenkauf möglich ist. Durch den einfachen Aufbau sorgt die für alle Endgeräte optimierte Web-Anwendung dafür, dass deutlich weniger Kunden den Kauf abbrechen. Und diese Kunden schätzen die Zahlung in bequemen Monatsraten und greifen somit gerne zu höherpreisigen Produkten. Somit steigt der durchschnittliche Warenkorb. Das beste dabei: Der Händler kann sich vollkommen auf den Verkauf seiner Ware konzentrieren, denn das komplette Bonitätsrisiko trägt die TeamBank AG.<br /><br /><strong>Nach dem Kauf ist vor dem Kauf ? mit Service Stammkunden gewinnen</strong><br /><br />Eine Kundenbeziehung im E-Commerce aufrechtzuerhalten bedeutet eine Menge Arbeit und viel Pflege. Jeder Händler verwendet einen nicht unerheblichen Anteil seiner Ressourcen damit, die Customer Journey für den Kunden so attraktiv wie möglich zu gestalten. Umso wichtiger ist es, den richtigen Teilzahlungs-Partner zu finden, der den Kunden mit einem guten Serviceangebot über die gesamte Laufzeit fair, flexibel und vor allem individuell begleitet. Genau das bietet die TeamBank AG mit ratenkauf by easyCredit. Schließlich kann es vorkommen, dass durch ein unvorhergesehenes Ereignis mal eine Rate ausgesetzt oder angepasst werden muss.<br /><br /><strong>ratenkauf by easyCredit verlängert den Sommer</strong><br /><br />Für alle modified-Kunden gibt es von ratenkauf by easyCredit zum Sommerfinale noch ein exklusives Angebot: <strong>Testen Sie jetzt ratenkauf by easyCredit bis zum Jahresende ganz ohne Risiko und vor allem kostenlos</strong>. Weitere Informationen und Details zum einfachsten Ratenkauf Deutschlands finden Sie <a href=\"https://www.modified-shop.org/forum/index.php?action=seored;u=aHR0cHMlM0ElMkYlMkZ3d3cuZWFzeWNyZWRpdC1yYXRlbmthdWYuZGUlMkZyZWdpc3RyaWVydW5nLW1vZGlmaWVkLmh0bSUzRnV0bV9zb3VyY2UlM0RwYXJ0bmVyc2VpdGUlMjZhbXAlM0J1dG1fbWVkaXVtJTNEbGluayUyNmFtcCUzQnV0bV9jYW1wYWlnbiUzRE1vZGlmaWVk\" rel=\"nofollow\" onClick=\"recordOutboundLink(this, \'Outbound Links\', \'https://www.easycredit-ratenkauf.de/registrierung-modified.htm?utm_source=partnerseite&utm_medium=link&utm_campaign=Modified\'); return false;\" class=\"bbc_link new_win\" target=\"_blank\">hier</a>.<br /><br /><span class=\"smalltext\">Linkback: https://www.modified-shop.org/forum/index.php?topic=39520.0</span>','https://www.modified-shop.org/forum/index.php?topic=39520.0',1537879705),(17,'Erleichtern Sie sich Ihren Händleralltag mit PayPal PLUS','<a href=\"https://www.modified-shop.org/forum/index.php?action=seored;u=aHR0cHMlM0ElMkYlMkZ3d3cucGF5cGFsLmRlJTJGcGF5cGFsLXBsdXMtY2VudGVyJTJG\" rel=\"nofollow\" onClick=\"recordOutboundLink(this, \'Outbound Links\', \'https://www.paypal.de/paypal-plus-center/\'); return false;\" class=\"bbc_link new_win\" target=\"_blank\"><img src=\"https://www.modified-shop.org/images/banner-to-topic/topic-id-39500-PayPalPLUS_Incentive_300x250px_01_Q3-2018.jpg\" alt=\"\" width=\"300\" height=\"250\" class=\"bbc_img resized\" /></a><br /><br />Wie viel Zeit muss man als Händler heutzutage eigentlich noch für die Buchhaltung opfern? Gibt es keine praktische Komplettlösung für Online-Shop-Betreiber? Lesen Sie in diesem Beitrag, welche Vorteile PayPal PLUS für Sie hat und wie viel Aufwand Ihnen ein vertrauenswürdiger Partner abnehmen kann.<br /><br />Mit PayPal als Vertragspartner hat man es als Online-Shop-Betreiber einfach, denn Händler können ihren Kunden die vier beliebtesten Zahlarten* PayPal, Lastschrift, Kreditkarte und den Kauf auf Rechnung ermöglichen und gleichzeitig wird die Buchhaltung ungemein vereinfacht. Es war noch nie so leicht, den Überblick über Zahlungseingänge unterschiedlicher Zahlarten zu behalten, denn bei PayPal PLUS gibt es nur einen Vertragspartner und damit nur eine Kontoübersicht. Egal, mit welcher Zahlart Kunden bezahlen, das Geld erhalten Händler immer unmittelbar nach Kaufabschluss ? sogar beim Kauf auf Rechnung. Und mit einer einheitlichen Transaktionsgebühr rundet PayPal sein Händlerangebot ab.<br /><br />Im nächsten Quartal lohnt es sich übrigens besonders, PayPal PLUS zu integrieren, da Sie mit Ihrem Teilnahmecode PLUSPARTNER2018 die bis zum 10.12.2018 anfallenden Gebühren zurückerstattet bekommen. Seien Sie schnell, denn Sie können so bis zu 500 Euro sparen.<br /><br />Die Teilnahmebedingungen für die PayPal PLUS Aktion haben wir hier für Sie zusammengefasst:<br /><ul class=\"bbc_list\" style=\"list-style-type: decimal;\"><li>Gehen Sie auf <a href=\"https://www.modified-shop.org/forum/index.php?action=seored;u=aHR0cCUzQSUyRiUyRnd3dy5wYXlwYWwuZGUlMkZwYXlwYWwtcGx1cy1jZW50ZXI=\" rel=\"nofollow\" onClick=\"recordOutboundLink(this, \'Outbound Links\', \'http://www.paypal.de/paypal-plus-center\'); return false;\" class=\"bbc_link new_win\" target=\"_blank\">www.paypal.de/paypal-plus-center</a></li><li>Code PLUSPARTNER2018 eingeben und anmelden</li><li>Integrieren Sie PayPal PLUS</li><li>Generieren Sie mindestens eine Transaktion</li><li>Erhalten Sie bis zum 10.12.2018 alle Transaktionsgebühren zurück</li></ul>Es hängt also von Ihnen ab, wie viel Geld Sie zurückerstattet bekommen. Wenn Sie noch heute PayPal PLUS integrieren, sparen Sie mehr. Integrieren Sie erst im Dezember, sparen Sie weniger.<br />Weitere Informationen, um Ihren Händleralltag zu vereinfachen und alles rund um die Komplettlösung für Ihre Onlinezahlungen finden Sie unter <a href=\"https://www.modified-shop.org/forum/index.php?action=seored;u=aHR0cCUzQSUyRiUyRnd3dy5wYXlwYWwuZGUlMkZwYXlwYWwtcGx1cw==\" rel=\"nofollow\" onClick=\"recordOutboundLink(this, \'Outbound Links\', \'http://www.paypal.de/paypal-plus\'); return false;\" class=\"bbc_link new_win\" target=\"_blank\">www.paypal.de/paypal-plus</a><br /><br />* ECC Köln: ECC-Payment-Studie Vol. 22<br /><br /><span class=\"smalltext\">Linkback: https://www.modified-shop.org/forum/index.php?topic=39500.0</span>','https://www.modified-shop.org/forum/index.php?topic=39500.0',1537197731),(18,'modified eCommerce Shopsoftware 2.0.4.2 rev 11374 veröffentlicht','<div style=\"text-align: right;\"> [ Für Gäste sind keine Dateianhänge sichtbar ] </div><br />Die Shopversion 2.0.4.2 rev 11374 ist das zweite Bugfix-Update der Shopversion 2.0.4.0 rev 11204 bzw. 2.0.4.1 rev 11327, da es immer noch Probleme mit dem neuen Installer gab.<br /><br /><strong>Wenn euch unser Engagement und die Shopsoftware gefällt, dann freuen wir uns über eine finanzielle Unterstützung, da diese in der Vergangenheit doch sehr stark zurück gegangen ist!</strong><br /><a href=\"http://www.modified-shop.org/spenden\" class=\"bbc_link new_win\"><img src=\"https://www.modified-shop.org/images/content/btn_donateCC_LS.png\" alt=\"\" class=\"bbc_img\" /></a><br /><br />Folgende Änderungen sind enthalten (Auszug aus dem Changelog):<br /><br /><div class=\"quoteheader\"><div class=\"topslice_quote\">Zitat</div></div><blockquote class=\"bbc_standard_quote\">Seit modified eCommerce Shopsoftware 2.0.4.2<br />- Fix #1462 Fehler in customers_status.sql (Kundengruppe \"Admin\" wird nicht in deutscher Sprache angelegt)<br />- Fix #1468 eingeschalteter Cache führt zu Problemen bei Listingfiltern und Rezensionen<br />- Fix #1497 Umlaute in Kundengruppen werden bei Installation in UTF-8 nicht korrekt angelegt</blockquote><div class=\"quotefooter\"><div class=\"botslice_quote\"></div></div><br /><strong><span style=\"color: red;\" class=\"bbc_color\">Achtung:</span></strong> Seit Shopversion 2.0.4.0 rev 11204 setzen wir <strong>mindestens</strong> PHP 5.6 voraus! <img src=\"//www.modified-shop.org/forum/Smileys/greensmilies/icon_callsign.gif\" alt=\":!:\" title=\"icon_callsign\" class=\"smiley\" /><br /><br />An dieser Stelle sei auch nochmal an unser gedrucktes Handbuch für Shopbetreiber erinnert:<br /><br /><div class=\"quoteheader\"><div class=\"topslice_quote\"><a href=\"https://www.modified-shop.org/forum/index.php?topic=35955.msg327808#msg327808\">Zitat von: Tomcraft am 28. Oktober 2016, 15:55:18</a></div></div><blockquote class=\"bbc_standard_quote\">Das Handbuch richtet sich an alle aktuellen und zukünftigen Shopbetreiber, die modified eCommerce Shopsoftware im Detail kennenlernen möchten und eine fundierte Anleitung für die tägliche Arbeit mit dem Adminbereich wünschen.<br /><br />Mit dem Kauf dieses Handbuchs bekommt der Leser eine detaillierte, intuitive Anleitung, einen Demoshop Schritt für Schritt selbst zu erkunden und unterstützt damit gleichzeitig das Projekt. Programmierkenntnisse sind für das Verständnis dieses Handbuchs nicht erforderlich.<br /><br />Die Autorin (christel-pohl.de) arbeitet seit mehr als 14 Jahren freiberuflich als Layouter und Betreuerin von Gewerbetreibenden mit Internetshops. Durch die Erfahrung aus dieser Arbeit legt sie Wert auf einen leicht verständlichen Schreibstil mit möglichst wenig Fachausdrücken, damit auch Laien schnell zu einem Erfolgserlebnis gelangen.<br /><br />Die Druckausgabe beinhaltet 324 Seiten im Format DIN A5 Softcover.<br /><br />Das Buch ist im Buchhandel unter der ISBN: 978-3-7418-5676-1 und direkt bei der Autorin erhältlich: <span class=\"bbc_u\"><strong><a href=\"https://www.modified-shop.org/forum/index.php?action=seored;u=aHR0cCUzQSUyRiUyRnd3dy5uZXctYnVzaW5lc3MtY29uc3VsdGluZy5kZSUyRnNob3A=\" rel=\"nofollow\" onClick=\"recordOutboundLink(this, \'Outbound Links\', \'http://www.new-business-consulting.de/shop\'); return false;\" class=\"bbc_link new_win\" target=\"_blank\">Klick mich!</a></strong></span><br /></blockquote><div class=\"quotefooter\"><div class=\"botslice_quote\"></div></div><br />Quelle: <a href=\"http://www.modified-shop.org/forum/index.php?topic=35955.0\" class=\"bbc_link new_win\">Gedrucktes \"Handbuch für Shopbetreiber\" veröffentlicht</a><br /><br />Helft uns, diese Meldung zu verbreiten, und teilt es auf Facebook, twittert, blogt oder emailt es euren Freunden und Bekannten.<br /><br />Ein responsive Template kann für 149¤ netto über das <a href=\"http://www.modified-shop.org/kontakt\" class=\"bbc_link new_win\">Kontaktformular</a> angefragt werden.<br /><br />Wer vorab schon mal einen Blick auf das Responsive Template machen möchte kann im <a href=\"http://dev.modified-shop.org/\" class=\"bbc_link new_win\">Dev Demoshop</a> schauen.<br /><br />Wir wünschen euch viel Spaß mit der neuen Version und freuen uns auf euer Feedback.<br /><br />Bitte beachtet die Textdateien im Ordner \"bitte_erst_lesen\"!<br /><br />Der Download ist wie gewohnt auf der <a href=\"http://www.modified-shop.org/download\" class=\"bbc_link new_win\">Download-Seite</a> zu finden.<br /><br />Bitte <strong>bewertet unsere modified eCommerce Shopsoftware</strong> bei <a href=\"https://www.modified-shop.org/forum/index.php?action=seored;u=aHR0cHMlM0ElMkYlMkZ3d3cuaGVpc2UuZGUlMkZkb3dubG9hZCUyRnByb2R1Y3QlMkZtb2RpZmllZC1lY29tbWVyY2Utc2hvcHNvZnR3YXJlLTc5NTIy\" rel=\"nofollow\" onClick=\"recordOutboundLink(this, \'Outbound Links\', \'https://www.heise.de/download/product/modified-ecommerce-shopsoftware-79522\'); return false;\" class=\"bbc_link new_win\" target=\"_blank\">heise.de</a>.<br /><br />Wenn euch die Shopsoftware gefällt, dann freuen wir uns über <strong>ein wenig finanzielle Unterstützung</strong>. <a href=\"http://www.modified-shop.org/spenden\" class=\"bbc_link new_win\"><img src=\"https://www.modified-shop.org/images/content/btn_donateCC_LS.png\" alt=\"\" class=\"bbc_img\" /></a><br /><br />Wir wünschen euch viel Erfolg bei der Umsetzung eurer Shop-Projekte mit der modified eCommerce Shopsoftware.<br /><br />Das modified eCommerce Shopsoftware Team<br /><br /><span class=\"smalltext\">Linkback: https://www.modified-shop.org/forum/index.php?topic=39337.0</span>','https://www.modified-shop.org/forum/index.php?topic=39337.0',1532342992),(19,'modified eCommerce Shopsoftware 2.0.4.1 rev 11327 veröffentlicht','<div style=\"text-align: right;\"> [ Für Gäste sind keine Dateianhänge sichtbar ] </div><br />Die Shopversion 2.0.4.1 rev 11327 ist das erste Bugfix-Update der Shopversion 2.0.4.0 rev 11204.<br /><br /><strong>Wenn euch unser Engagement und die Shopsoftware gefällt, dann freuen wir uns über eine finanzielle Unterstützung, da diese in der Vergangenheit doch sehr stark zurück gegangen ist!</strong><br /><a href=\"http://www.modified-shop.org/spenden\" class=\"bbc_link new_win\"><img src=\"https://www.modified-shop.org/images/content/btn_donateCC_LS.png\" alt=\"\" class=\"bbc_img\" /></a><br /><br />Folgende Änderungen sind enthalten (Auszug aus dem Changelog):<br /><br /><div class=\"quoteheader\"><div class=\"topslice_quote\">Zitat</div></div><blockquote class=\"bbc_standard_quote\">Seit modified eCommerce Shopsoftware 2.0.4.1<br />- Fix #1072 Updater um Datenbank-Backup Möglichkeit erweitern<br />- Fix #1462 Fehler in customers_status.sql (Kundengruppe \"Admin\" wird nicht in deutscher Sprache angelegt)<br />- Fix #1464 Weisse Seite bei aktiviertem Cache<br />- Fix #1468 eingeschalteter Cache führt zu Problemem bei Listingfiltern und Rezensionen<br />- Fix #1470 Neuer Installer scheint Probleme auf Strato Servern zu haben<br />- Fix #1461 Passwort in Klartext im neuen Installer<br />- Fix #1467 Installer überarbeiten</blockquote><div class=\"quotefooter\"><div class=\"botslice_quote\"></div></div><br /><strong><span style=\"color: red;\" class=\"bbc_color\">Achtung:</span></strong> Seit Shopversion 2.0.4.0 rev 11204 setzen wir <strong>mindestens</strong> PHP 5.6 voraus! <img src=\"//www.modified-shop.org/forum/Smileys/greensmilies/icon_callsign.gif\" alt=\":!:\" title=\"icon_callsign\" class=\"smiley\" /><br /><br />An dieser Stelle sei auch nochmal an unser gedrucktes Handbuch für Shopbetreiber erinnert:<br /><br /><div class=\"quoteheader\"><div class=\"topslice_quote\"><a href=\"https://www.modified-shop.org/forum/index.php?topic=35955.msg327808#msg327808\">Zitat von: Tomcraft am 28. Oktober 2016, 15:55:18</a></div></div><blockquote class=\"bbc_standard_quote\">Das Handbuch richtet sich an alle aktuellen und zukünftigen Shopbetreiber, die modified eCommerce Shopsoftware im Detail kennenlernen möchten und eine fundierte Anleitung für die tägliche Arbeit mit dem Adminbereich wünschen.<br /><br />Mit dem Kauf dieses Handbuchs bekommt der Leser eine detaillierte, intuitive Anleitung, einen Demoshop Schritt für Schritt selbst zu erkunden und unterstützt damit gleichzeitig das Projekt. Programmierkenntnisse sind für das Verständnis dieses Handbuchs nicht erforderlich.<br /><br />Die Autorin (christel-pohl.de) arbeitet seit mehr als 14 Jahren freiberuflich als Layouter und Betreuerin von Gewerbetreibenden mit Internetshops. Durch die Erfahrung aus dieser Arbeit legt sie Wert auf einen leicht verständlichen Schreibstil mit möglichst wenig Fachausdrücken, damit auch Laien schnell zu einem Erfolgserlebnis gelangen.<br /><br />Die Druckausgabe beinhaltet 324 Seiten im Format DIN A5 Softcover.<br /><br />Das Buch ist im Buchhandel unter der ISBN: 978-3-7418-5676-1 und direkt bei der Autorin erhältlich: <span class=\"bbc_u\"><strong><a href=\"https://www.modified-shop.org/forum/index.php?action=seored;u=aHR0cCUzQSUyRiUyRnd3dy5uZXctYnVzaW5lc3MtY29uc3VsdGluZy5kZSUyRnNob3A=\" rel=\"nofollow\" onClick=\"recordOutboundLink(this, \'Outbound Links\', \'http://www.new-business-consulting.de/shop\'); return false;\" class=\"bbc_link new_win\" target=\"_blank\">Klick mich!</a></strong></span><br /></blockquote><div class=\"quotefooter\"><div class=\"botslice_quote\"></div></div><br />Quelle: <a href=\"http://www.modified-shop.org/forum/index.php?topic=35955.0\" class=\"bbc_link new_win\">Gedrucktes \"Handbuch für Shopbetreiber\" veröffentlicht</a><br /><br />Helft uns, diese Meldung zu verbreiten, und teilt es auf Facebook, twittert, blogt oder emailt es euren Freunden und Bekannten.<br /><br />Ein responsive Template kann für 149¤ netto über das <a href=\"http://www.modified-shop.org/kontakt\" class=\"bbc_link new_win\">Kontaktformular</a> angefragt werden.<br /><br />Wer vorab schon mal einen Blick auf das Responsive Template machen möchte kann im <a href=\"http://dev.modified-shop.org/\" class=\"bbc_link new_win\">Dev Demoshop</a> schauen.<br /><br />Wir wünschen euch viel Spaß mit der neuen Version und freuen uns auf euer Feedback.<br /><br />Bitte beachtet die Textdateien im Ordner \"bitte_erst_lesen\"!<br /><br />Der Download ist wie gewohnt auf der <a href=\"http://www.modified-shop.org/download\" class=\"bbc_link new_win\">Download-Seite</a> zu finden.<br /><br />Bitte <strong>bewertet unsere modified eCommerce Shopsoftware</strong> bei <a href=\"https://www.modified-shop.org/forum/index.php?action=seored;u=aHR0cHMlM0ElMkYlMkZ3d3cuaGVpc2UuZGUlMkZkb3dubG9hZCUyRnByb2R1Y3QlMkZtb2RpZmllZC1lY29tbWVyY2Utc2hvcHNvZnR3YXJlLTc5NTIy\" rel=\"nofollow\" onClick=\"recordOutboundLink(this, \'Outbound Links\', \'https://www.heise.de/download/product/modified-ecommerce-shopsoftware-79522\'); return false;\" class=\"bbc_link new_win\" target=\"_blank\">heise.de</a>.<br /><br />Wenn euch die Shopsoftware gefällt, dann freuen wir uns über <strong>ein wenig finanzielle Unterstützung</strong>. <a href=\"http://www.modified-shop.org/spenden\" class=\"bbc_link new_win\"><img src=\"https://www.modified-shop.org/images/content/btn_donateCC_LS.png\" alt=\"\" class=\"bbc_img\" /></a><br /><br />Wir wünschen euch viel Erfolg bei der Umsetzung eurer Shop-Projekte mit der modified eCommerce Shopsoftware.<br /><br />Das modified eCommerce Shopsoftware Team<br /><br /><span class=\"smalltext\">Linkback: https://www.modified-shop.org/forum/index.php?topic=39279.0</span>','https://www.modified-shop.org/forum/index.php?topic=39279.0',1530278305),(20,'Facebook Fanpages & Datennutzung: Was das EuGH-Urteil für Unternehmen bedeutet','Für moderne Unternehmen ist Facebook heutzutage schier unerlässlich: Auf den sogenannten ?Facebook Fanpages? können sie sich nicht nur adäquat präsentieren, sondern auch mit Kunden und interessierten Nutzern in Verbindung treten. Entsprechend wichtig ist das Portal für die Kundenbindung und den -service. Und gerade, weil die Fanpages für den Unternehmensalltag so überaus relevant sind, war das Aufsehen groß, als der Europäische Gerichtshof vor wenigen Wochen ein weitreichendes Urteil fällte.<br /><br /><strong>Urteil rückt Datenverarbeitung auf Facebook in den Blick</strong><br />In dem Urteil, das in der gesamten Online-Branche für große Schlagzeilen sorgte, entschied der EuGH darüber, wer für die Datennutzung und -verarbeitung auf Facebook überhaupt verantwortlich ist und dementsprechend haftet. Konkret ging es um die Wirtschaftsakademie Schleswig-Holstein, deren Facebook Fanpage-Nutzung vom Unabhängigen Landeszentrum für Datenschutz angekreidet wurde.<br /><br />Dabei kam das Gericht zu dem Schluss, dass sowohl Facebook als auch die Tochtergesellschaft Facebook Ireland als ?Verantwortliche? zu betrachten sind. Doch auch die Unternehmen selbst werden dabei nicht aus der Verantwortung genommen, ganz im Gegenteil: Nach Ansicht des Europäischen Gerichtshofes tragen die Betreiber der Facebook Fanpages ebenfalls eine Mitverantwortung für den Datenschutz. Diese Verantwortung ergibt sich unter anderem daraus, dass die Unternehmen an der Entscheidung beteiligt sind, wie und wozu die Nutzerdaten verarbeitet werden, und ebenfalls von diesen Daten profitieren.<br /><br /><strong>EuGH-Urteil: Wo liegt nun die Problematik?</strong><br />Eine gemeinsame Verantwortung von Facebook und den Unternehmen, die selbst Facebook Fanpages betreiben, hört sich vielleicht erst einmal recht unspektakulär an. Doch aus dem Urteil ergeben sich wichtige Änderungen für Händler, Dienstleister und alle anderen Unternehmen: Denn aus der Entscheidung resultiert die praxisrelevante Pflicht, bei Facebook Fanpages eine Datenschutzerklärung zu hinterlegen, in der sie die Nutzer im Detail darüber aufklären müssen, welche Daten gesammelt, wie und zu welchem Zweck verarbeitet und auch gespeichert werden.<br /><br />Das Problem ist offensichtlich: Kein Unternehmen weiß, auf welche Nutzerdaten Facebook genau Zugriff hat, welche Daten wie verarbeitet werden und an welche dritten Parteien Facebook diese Daten in welchem Umfang eventuell noch weiter gibt. Aus diesem Grund ist es Unternehmen nicht möglich, die Besucher ihrer Fanpages umfassend über die Datensammlung, -verarbeitung und -speicherung zu informieren.<br /><br />Kurz gesagt: Unternehmen haben keine Handhabe über die Datennutzung durch Facebook. Und genau aus diesem Grund wird das Urteil des Europäischen Gerichtshofes in der Branche auch als realitätsfern wahrgenommen, denn die Mithaftung stellt die Unternehmen vor eine kaum zu überwindende Hürde.<br /><br /><strong>Facebook muss transparenter werden</strong><br />Was bedeutet das Urteil nun für Unternehmen und Betreiber von Facebook Fanpages? Die Richter sahen es im Rahmen ihrer Entscheidung als unumgänglich an, dass Facebook künftig mehr Mithilfe leisten muss. Der Netzwerkgigant müsse künftig transparenter arbeiten, um Nutzer explizit und transparent über die verwendeten Daten informieren zu können. Dies bestätigte mittlerweile auch die Datenschutzkonferenz (DSK). Und grundsätzlich sei hier angemerkt, dass auch Facebook selbst an einer Lösung des Problems interessiert sein dürfte, schließlich verdient der Konzern mit der Verarbeitung und Verwendung der Nutzerdaten Geld und profitiert dementsprechend auch von Unternehmensauftritten und Fanpages.<br /><br />Während sich Facebook kurz nach dem EuGH-Urteil noch ?enttäuscht? zeigt, aber eher ?keine unmittelbaren Auswirkungen? auf Unternehmen sah, gibt es inzwischen erfreulichere Nachrichten für Unternehmen. Denn Facebook scheint sich mittlerweile der Bedeutung und eigenen Verantwortung bewusst zu sein und wolle nach Angaben eines öffentlichen Blogposts ?notwendige Schritte? einleiten, die es den Betreibern der Facebook Fanpages ermöglichen sollen, ?ihren rechtlichen Verpflichtungen nachzukommen?.<br /><br />Konkret werde man die ?Nutzungsbedingungen bzw. Richtlinien für Seiten aktualisieren, um die Verantwortlichkeiten sowohl von Facebook als auch von Seitenbetreibern klarzustellen?. Weitere Details zu den geplanten Änderungen sind bis dato nicht bekannt.<br /><br /><strong>Der Händlerbund hilft</strong><br />Für Unternehmen heißt es aktuell, nicht den Kopf zu verlieren und Ruhe zu bewahren. Unternehmen, die nicht auf ihren Facebook-Auftritt verzichten können oder wollen, sollten sich in jedem Fall dringend Rat von fachkundigen Juristen einzuholen. Auch der Händlerbund bietet seinen Mitgliedern eine entsprechende Datenschutzerklärung für Facebook an, sodass sie ihren Informationspflichten bestmöglich nachkommen können. Darüber hinaus können Händlerbund Mitglieder auf konkrete Handlungsempfehlungen zum Einstellen der Datenschutzerklärung auf der Facebook Fanpage zurückgreifen. Mit dem <strong>Rabattcode Modified0618</strong> sparen modified-Kunden <strong>4 Monate auf alle Pakete</strong>. <strong><a href=\"https://www.modified-shop.org/forum/index.php?action=seored;u=aHR0cHMlM0ElMkYlMkZ3d3cuaGFlbmRsZXJidW5kLmRlJTJGbW9kaWZpZWQ=\" rel=\"nofollow\" onClick=\"recordOutboundLink(this, \'Outbound Links\', \'https://www.haendlerbund.de/modified\'); return false;\" class=\"bbc_link new_win\" target=\"_blank\">Jetzt informieren!</a></strong><br /><br /><span class=\"smalltext\">Linkback: https://www.modified-shop.org/forum/index.php?topic=39270.0</span>','https://www.modified-shop.org/forum/index.php?topic=39270.0',1530186470);
/*!40000 ALTER TABLE `newsfeed` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `newsletter_recipients`
--

DROP TABLE IF EXISTS `newsletter_recipients`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `newsletter_recipients` (
  `mail_id` int(11) NOT NULL AUTO_INCREMENT,
  `customers_email_address` varchar(255) COLLATE latin1_german1_ci NOT NULL DEFAULT '',
  `customers_id` int(11) NOT NULL DEFAULT '0',
  `customers_status` int(5) NOT NULL DEFAULT '0',
  `customers_firstname` varchar(64) COLLATE latin1_german1_ci NOT NULL DEFAULT '',
  `customers_lastname` varchar(64) COLLATE latin1_german1_ci NOT NULL DEFAULT '',
  `mail_status` int(1) NOT NULL DEFAULT '0',
  `mail_key` varchar(32) COLLATE latin1_german1_ci NOT NULL DEFAULT '',
  `date_added` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `ip_date_added` varchar(50) COLLATE latin1_german1_ci DEFAULT NULL,
  `date_confirmed` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `ip_date_confirmed` varchar(50) COLLATE latin1_german1_ci DEFAULT NULL,
  PRIMARY KEY (`mail_id`),
  UNIQUE KEY `idx_customers_email_address` (`customers_email_address`),
  KEY `idx_mail_key` (`mail_key`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_german1_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `newsletter_recipients`
--

LOCK TABLES `newsletter_recipients` WRITE;
/*!40000 ALTER TABLE `newsletter_recipients` DISABLE KEYS */;
/*!40000 ALTER TABLE `newsletter_recipients` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `newsletters`
--

DROP TABLE IF EXISTS `newsletters`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `newsletters` (
  `newsletters_id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) COLLATE latin1_german1_ci NOT NULL,
  `content` text COLLATE latin1_german1_ci NOT NULL,
  `module` varchar(255) COLLATE latin1_german1_ci NOT NULL,
  `date_added` datetime NOT NULL,
  `date_sent` datetime DEFAULT NULL,
  `status` int(1) DEFAULT NULL,
  `locked` int(1) DEFAULT '0',
  PRIMARY KEY (`newsletters_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_german1_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `newsletters`
--

LOCK TABLES `newsletters` WRITE;
/*!40000 ALTER TABLE `newsletters` DISABLE KEYS */;
/*!40000 ALTER TABLE `newsletters` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `newsletters_history`
--

DROP TABLE IF EXISTS `newsletters_history`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `newsletters_history` (
  `news_hist_id` int(11) NOT NULL DEFAULT '0',
  `news_hist_cs` int(11) NOT NULL DEFAULT '0',
  `news_hist_cs_date_sent` date DEFAULT NULL,
  PRIMARY KEY (`news_hist_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_german1_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `newsletters_history`
--

LOCK TABLES `newsletters_history` WRITE;
/*!40000 ALTER TABLE `newsletters_history` DISABLE KEYS */;
/*!40000 ALTER TABLE `newsletters_history` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `orders`
--

DROP TABLE IF EXISTS `orders`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `orders` (
  `orders_id` int(11) NOT NULL AUTO_INCREMENT,
  `customers_id` int(11) NOT NULL,
  `customers_cid` varchar(32) COLLATE latin1_german1_ci DEFAULT NULL,
  `customers_vat_id` varchar(20) COLLATE latin1_german1_ci DEFAULT NULL,
  `customers_status` int(11) DEFAULT NULL,
  `customers_status_name` varchar(32) COLLATE latin1_german1_ci NOT NULL,
  `customers_status_image` varchar(64) COLLATE latin1_german1_ci DEFAULT NULL,
  `customers_status_discount` decimal(4,2) DEFAULT NULL,
  `customers_name` varchar(128) COLLATE latin1_german1_ci NOT NULL,
  `customers_firstname` varchar(64) COLLATE latin1_german1_ci NOT NULL,
  `customers_lastname` varchar(64) COLLATE latin1_german1_ci NOT NULL,
  `customers_gender` char(1) COLLATE latin1_german1_ci NOT NULL,
  `customers_company` varchar(64) COLLATE latin1_german1_ci DEFAULT NULL,
  `customers_street_address` varchar(64) COLLATE latin1_german1_ci NOT NULL,
  `customers_suburb` varchar(32) COLLATE latin1_german1_ci DEFAULT NULL,
  `customers_city` varchar(64) COLLATE latin1_german1_ci NOT NULL,
  `customers_postcode` varchar(10) COLLATE latin1_german1_ci NOT NULL,
  `customers_state` varchar(64) COLLATE latin1_german1_ci DEFAULT NULL,
  `customers_country` varchar(64) COLLATE latin1_german1_ci NOT NULL,
  `customers_telephone` varchar(32) COLLATE latin1_german1_ci NOT NULL,
  `customers_email_address` varchar(255) COLLATE latin1_german1_ci NOT NULL,
  `customers_address_format_id` int(5) NOT NULL,
  `customers_country_iso_code_2` varchar(2) COLLATE latin1_german1_ci NOT NULL,
  `delivery_name` varchar(128) COLLATE latin1_german1_ci NOT NULL,
  `delivery_firstname` varchar(64) COLLATE latin1_german1_ci NOT NULL,
  `delivery_lastname` varchar(64) COLLATE latin1_german1_ci NOT NULL,
  `delivery_gender` char(1) COLLATE latin1_german1_ci NOT NULL,
  `delivery_company` varchar(64) COLLATE latin1_german1_ci DEFAULT NULL,
  `delivery_street_address` varchar(64) COLLATE latin1_german1_ci NOT NULL,
  `delivery_suburb` varchar(32) COLLATE latin1_german1_ci DEFAULT NULL,
  `delivery_city` varchar(64) COLLATE latin1_german1_ci NOT NULL,
  `delivery_postcode` varchar(10) COLLATE latin1_german1_ci NOT NULL,
  `delivery_state` varchar(64) COLLATE latin1_german1_ci DEFAULT NULL,
  `delivery_country` varchar(64) COLLATE latin1_german1_ci NOT NULL,
  `delivery_country_iso_code_2` char(2) COLLATE latin1_german1_ci NOT NULL,
  `delivery_address_format_id` int(5) NOT NULL,
  `billing_name` varchar(128) COLLATE latin1_german1_ci NOT NULL,
  `billing_firstname` varchar(64) COLLATE latin1_german1_ci NOT NULL,
  `billing_lastname` varchar(64) COLLATE latin1_german1_ci NOT NULL,
  `billing_gender` char(1) COLLATE latin1_german1_ci NOT NULL,
  `billing_company` varchar(64) COLLATE latin1_german1_ci DEFAULT NULL,
  `billing_street_address` varchar(64) COLLATE latin1_german1_ci NOT NULL,
  `billing_suburb` varchar(32) COLLATE latin1_german1_ci DEFAULT NULL,
  `billing_city` varchar(64) COLLATE latin1_german1_ci NOT NULL,
  `billing_postcode` varchar(10) COLLATE latin1_german1_ci NOT NULL,
  `billing_state` varchar(64) COLLATE latin1_german1_ci DEFAULT NULL,
  `billing_country` varchar(64) COLLATE latin1_german1_ci NOT NULL,
  `billing_country_iso_code_2` char(2) COLLATE latin1_german1_ci NOT NULL,
  `billing_address_format_id` int(5) NOT NULL,
  `payment_method` varchar(128) COLLATE latin1_german1_ci NOT NULL,
  `comments` text COLLATE latin1_german1_ci,
  `last_modified` datetime DEFAULT NULL,
  `date_purchased` datetime DEFAULT NULL,
  `orders_status` int(5) NOT NULL,
  `orders_date_finished` datetime DEFAULT NULL,
  `currency` char(3) COLLATE latin1_german1_ci DEFAULT NULL,
  `currency_value` decimal(14,6) DEFAULT NULL,
  `account_type` int(1) NOT NULL DEFAULT '0',
  `payment_class` varchar(64) COLLATE latin1_german1_ci NOT NULL,
  `shipping_method` varchar(128) COLLATE latin1_german1_ci NOT NULL,
  `shipping_class` varchar(32) COLLATE latin1_german1_ci NOT NULL,
  `customers_ip` varchar(50) COLLATE latin1_german1_ci NOT NULL,
  `language` varchar(32) COLLATE latin1_german1_ci NOT NULL,
  `languages_id` int(11) NOT NULL,
  `afterbuy_success` int(1) NOT NULL DEFAULT '0',
  `afterbuy_id` int(32) NOT NULL DEFAULT '0',
  `refferers_id` varchar(32) COLLATE latin1_german1_ci NOT NULL,
  `conversion_type` int(1) NOT NULL DEFAULT '0',
  `orders_ident_key` varchar(128) COLLATE latin1_german1_ci DEFAULT NULL,
  PRIMARY KEY (`orders_id`),
  KEY `idx_customers_id` (`customers_id`),
  KEY `idx_orders_status` (`orders_status`),
  KEY `idx_date_purchased` (`date_purchased`),
  KEY `idx_payment_class` (`payment_class`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_german1_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `orders`
--

LOCK TABLES `orders` WRITE;
/*!40000 ALTER TABLE `orders` DISABLE KEYS */;
/*!40000 ALTER TABLE `orders` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `orders_products`
--

DROP TABLE IF EXISTS `orders_products`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `orders_products` (
  `orders_products_id` int(11) NOT NULL AUTO_INCREMENT,
  `orders_id` int(11) NOT NULL,
  `products_id` int(11) NOT NULL,
  `products_model` varchar(64) COLLATE latin1_german1_ci DEFAULT NULL,
  `products_ean` varchar(128) COLLATE latin1_german1_ci DEFAULT NULL,
  `products_name` varchar(255) COLLATE latin1_german1_ci NOT NULL,
  `products_price` decimal(15,4) NOT NULL,
  `products_price_origin` decimal(15,4) NOT NULL,
  `products_discount_made` decimal(4,2) DEFAULT NULL,
  `products_shipping_time` varchar(255) COLLATE latin1_german1_ci DEFAULT NULL,
  `final_price` decimal(15,4) NOT NULL,
  `products_tax` decimal(7,4) NOT NULL,
  `products_quantity` int(2) NOT NULL,
  `allow_tax` int(1) NOT NULL,
  `products_order_description` text COLLATE latin1_german1_ci,
  `products_weight` decimal(6,3) NOT NULL,
  PRIMARY KEY (`orders_products_id`),
  KEY `idx_orders_id` (`orders_id`),
  KEY `idx_products_id` (`products_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_german1_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `orders_products`
--

LOCK TABLES `orders_products` WRITE;
/*!40000 ALTER TABLE `orders_products` DISABLE KEYS */;
/*!40000 ALTER TABLE `orders_products` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `orders_products_attributes`
--

DROP TABLE IF EXISTS `orders_products_attributes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `orders_products_attributes` (
  `orders_products_attributes_id` int(11) NOT NULL AUTO_INCREMENT,
  `orders_id` int(11) NOT NULL,
  `orders_products_id` int(11) NOT NULL,
  `products_options` varchar(255) COLLATE latin1_german1_ci NOT NULL,
  `products_options_values` varchar(255) COLLATE latin1_german1_ci NOT NULL,
  `attributes_model` varchar(64) COLLATE latin1_german1_ci DEFAULT NULL,
  `attributes_ean` varchar(128) COLLATE latin1_german1_ci DEFAULT NULL,
  `options_values_price` decimal(15,4) NOT NULL,
  `price_prefix` char(1) COLLATE latin1_german1_ci NOT NULL,
  `orders_products_options_id` int(11) NOT NULL,
  `orders_products_options_values_id` int(11) NOT NULL,
  `options_values_weight` decimal(15,4) NOT NULL,
  `weight_prefix` char(1) COLLATE latin1_german1_ci NOT NULL,
  PRIMARY KEY (`orders_products_attributes_id`),
  KEY `idx_orders_id` (`orders_id`),
  KEY `idx_orders_products_id` (`orders_products_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_german1_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `orders_products_attributes`
--

LOCK TABLES `orders_products_attributes` WRITE;
/*!40000 ALTER TABLE `orders_products_attributes` DISABLE KEYS */;
/*!40000 ALTER TABLE `orders_products_attributes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `orders_products_download`
--

DROP TABLE IF EXISTS `orders_products_download`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `orders_products_download` (
  `orders_products_download_id` int(11) NOT NULL AUTO_INCREMENT,
  `orders_id` int(11) NOT NULL DEFAULT '0',
  `orders_products_id` int(11) NOT NULL DEFAULT '0',
  `orders_products_filename` varchar(255) COLLATE latin1_german1_ci NOT NULL DEFAULT '',
  `download_maxdays` int(2) NOT NULL DEFAULT '0',
  `download_count` int(2) NOT NULL DEFAULT '0',
  `download_key` varchar(32) COLLATE latin1_german1_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`orders_products_download_id`),
  KEY `idx_orders_id` (`orders_id`),
  KEY `idx_orders_products_id` (`orders_products_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_german1_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `orders_products_download`
--

LOCK TABLES `orders_products_download` WRITE;
/*!40000 ALTER TABLE `orders_products_download` DISABLE KEYS */;
/*!40000 ALTER TABLE `orders_products_download` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `orders_recalculate`
--

DROP TABLE IF EXISTS `orders_recalculate`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `orders_recalculate` (
  `orders_recalculate_id` int(11) NOT NULL AUTO_INCREMENT,
  `orders_id` int(11) NOT NULL DEFAULT '0',
  `n_price` decimal(15,4) NOT NULL DEFAULT '0.0000',
  `b_price` decimal(15,4) NOT NULL DEFAULT '0.0000',
  `tax` decimal(15,4) NOT NULL DEFAULT '0.0000',
  `tax_rate` decimal(7,4) NOT NULL DEFAULT '0.0000',
  `class` varchar(32) COLLATE latin1_german1_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`orders_recalculate_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_german1_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `orders_recalculate`
--

LOCK TABLES `orders_recalculate` WRITE;
/*!40000 ALTER TABLE `orders_recalculate` DISABLE KEYS */;
/*!40000 ALTER TABLE `orders_recalculate` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `orders_status`
--

DROP TABLE IF EXISTS `orders_status`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `orders_status` (
  `orders_status_id` int(11) NOT NULL DEFAULT '0',
  `language_id` int(11) NOT NULL,
  `orders_status_name` varchar(64) COLLATE latin1_german1_ci NOT NULL,
  `sort_order` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`orders_status_id`,`language_id`),
  KEY `idx_orders_status_name` (`orders_status_name`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_german1_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `orders_status`
--

LOCK TABLES `orders_status` WRITE;
/*!40000 ALTER TABLE `orders_status` DISABLE KEYS */;
INSERT INTO `orders_status` VALUES (1,1,'Pending',1),(1,2,'Offen',1),(2,1,'Processing',2),(2,2,'In Bearbeitung',2),(3,1,'Shipped',3),(3,2,'Versendet',3),(4,1,'Canceled',4),(4,2,'Storniert',4);
/*!40000 ALTER TABLE `orders_status` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `orders_status_history`
--

DROP TABLE IF EXISTS `orders_status_history`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `orders_status_history` (
  `orders_status_history_id` int(11) NOT NULL AUTO_INCREMENT,
  `orders_id` int(11) NOT NULL,
  `orders_status_id` int(5) NOT NULL,
  `date_added` datetime NOT NULL,
  `customer_notified` int(1) DEFAULT '0',
  `comments` text COLLATE latin1_german1_ci,
  `comments_sent` int(1) DEFAULT '0',
  PRIMARY KEY (`orders_status_history_id`),
  KEY `idx_orders_id` (`orders_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_german1_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `orders_status_history`
--

LOCK TABLES `orders_status_history` WRITE;
/*!40000 ALTER TABLE `orders_status_history` DISABLE KEYS */;
/*!40000 ALTER TABLE `orders_status_history` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `orders_total`
--

DROP TABLE IF EXISTS `orders_total`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `orders_total` (
  `orders_total_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `orders_id` int(11) NOT NULL,
  `title` varchar(255) COLLATE latin1_german1_ci NOT NULL,
  `text` varchar(255) COLLATE latin1_german1_ci NOT NULL,
  `value` decimal(15,4) NOT NULL,
  `class` varchar(32) COLLATE latin1_german1_ci NOT NULL,
  `sort_order` int(11) NOT NULL,
  PRIMARY KEY (`orders_total_id`),
  KEY `idx_orders_id` (`orders_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_german1_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `orders_total`
--

LOCK TABLES `orders_total` WRITE;
/*!40000 ALTER TABLE `orders_total` DISABLE KEYS */;
/*!40000 ALTER TABLE `orders_total` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `orders_tracking`
--

DROP TABLE IF EXISTS `orders_tracking`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `orders_tracking` (
  `tracking_id` int(11) NOT NULL AUTO_INCREMENT,
  `orders_id` int(11) NOT NULL,
  `carrier_id` int(11) NOT NULL,
  `parcel_id` varchar(80) COLLATE latin1_german1_ci NOT NULL,
  `date_added` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`tracking_id`),
  KEY `idx_orders_id` (`orders_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_german1_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `orders_tracking`
--

LOCK TABLES `orders_tracking` WRITE;
/*!40000 ALTER TABLE `orders_tracking` DISABLE KEYS */;
/*!40000 ALTER TABLE `orders_tracking` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `payment_moneybookers`
--

DROP TABLE IF EXISTS `payment_moneybookers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `payment_moneybookers` (
  `mb_TRID` varchar(255) COLLATE latin1_german1_ci NOT NULL DEFAULT '',
  `mb_ERRNO` smallint(3) unsigned NOT NULL DEFAULT '0',
  `mb_ERRTXT` varchar(255) COLLATE latin1_german1_ci NOT NULL DEFAULT '',
  `mb_DATE` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `mb_MBTID` bigint(18) unsigned NOT NULL DEFAULT '0',
  `mb_STATUS` tinyint(1) NOT NULL DEFAULT '0',
  `mb_ORDERID` int(11) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`mb_TRID`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_german1_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `payment_moneybookers`
--

LOCK TABLES `payment_moneybookers` WRITE;
/*!40000 ALTER TABLE `payment_moneybookers` DISABLE KEYS */;
/*!40000 ALTER TABLE `payment_moneybookers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `personal_offers_by_customers_status_0`
--

DROP TABLE IF EXISTS `personal_offers_by_customers_status_0`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `personal_offers_by_customers_status_0` (
  `price_id` int(11) NOT NULL AUTO_INCREMENT,
  `products_id` int(11) NOT NULL,
  `quantity` int(11) DEFAULT NULL,
  `personal_offer` decimal(15,4) DEFAULT NULL,
  PRIMARY KEY (`price_id`),
  KEY `idx_products_id` (`products_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_german1_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `personal_offers_by_customers_status_0`
--

LOCK TABLES `personal_offers_by_customers_status_0` WRITE;
/*!40000 ALTER TABLE `personal_offers_by_customers_status_0` DISABLE KEYS */;
/*!40000 ALTER TABLE `personal_offers_by_customers_status_0` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `personal_offers_by_customers_status_1`
--

DROP TABLE IF EXISTS `personal_offers_by_customers_status_1`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `personal_offers_by_customers_status_1` (
  `price_id` int(11) NOT NULL AUTO_INCREMENT,
  `products_id` int(11) NOT NULL,
  `quantity` int(11) DEFAULT NULL,
  `personal_offer` decimal(15,4) DEFAULT NULL,
  PRIMARY KEY (`price_id`),
  KEY `idx_products_id` (`products_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_german1_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `personal_offers_by_customers_status_1`
--

LOCK TABLES `personal_offers_by_customers_status_1` WRITE;
/*!40000 ALTER TABLE `personal_offers_by_customers_status_1` DISABLE KEYS */;
/*!40000 ALTER TABLE `personal_offers_by_customers_status_1` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `personal_offers_by_customers_status_2`
--

DROP TABLE IF EXISTS `personal_offers_by_customers_status_2`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `personal_offers_by_customers_status_2` (
  `price_id` int(11) NOT NULL AUTO_INCREMENT,
  `products_id` int(11) NOT NULL,
  `quantity` int(11) DEFAULT NULL,
  `personal_offer` decimal(15,4) DEFAULT NULL,
  PRIMARY KEY (`price_id`),
  KEY `idx_products_id` (`products_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_german1_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `personal_offers_by_customers_status_2`
--

LOCK TABLES `personal_offers_by_customers_status_2` WRITE;
/*!40000 ALTER TABLE `personal_offers_by_customers_status_2` DISABLE KEYS */;
/*!40000 ALTER TABLE `personal_offers_by_customers_status_2` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `personal_offers_by_customers_status_3`
--

DROP TABLE IF EXISTS `personal_offers_by_customers_status_3`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `personal_offers_by_customers_status_3` (
  `price_id` int(11) NOT NULL AUTO_INCREMENT,
  `products_id` int(11) NOT NULL,
  `quantity` int(11) DEFAULT NULL,
  `personal_offer` decimal(15,4) DEFAULT NULL,
  PRIMARY KEY (`price_id`),
  KEY `idx_products_id` (`products_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_german1_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `personal_offers_by_customers_status_3`
--

LOCK TABLES `personal_offers_by_customers_status_3` WRITE;
/*!40000 ALTER TABLE `personal_offers_by_customers_status_3` DISABLE KEYS */;
/*!40000 ALTER TABLE `personal_offers_by_customers_status_3` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `personal_offers_by_customers_status_4`
--

DROP TABLE IF EXISTS `personal_offers_by_customers_status_4`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `personal_offers_by_customers_status_4` (
  `price_id` int(11) NOT NULL AUTO_INCREMENT,
  `products_id` int(11) NOT NULL,
  `quantity` int(11) DEFAULT NULL,
  `personal_offer` decimal(15,4) DEFAULT NULL,
  PRIMARY KEY (`price_id`),
  KEY `idx_products_id` (`products_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_german1_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `personal_offers_by_customers_status_4`
--

LOCK TABLES `personal_offers_by_customers_status_4` WRITE;
/*!40000 ALTER TABLE `personal_offers_by_customers_status_4` DISABLE KEYS */;
/*!40000 ALTER TABLE `personal_offers_by_customers_status_4` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `products`
--

DROP TABLE IF EXISTS `products`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `products` (
  `products_id` int(11) NOT NULL AUTO_INCREMENT,
  `products_ean` varchar(128) COLLATE latin1_german1_ci DEFAULT NULL,
  `products_quantity` int(4) NOT NULL,
  `products_shippingtime` int(4) NOT NULL,
  `products_model` varchar(64) COLLATE latin1_german1_ci DEFAULT NULL,
  `group_permission_0` tinyint(1) NOT NULL,
  `group_permission_1` tinyint(1) NOT NULL,
  `group_permission_2` tinyint(1) NOT NULL,
  `group_permission_3` tinyint(1) NOT NULL,
  `group_permission_4` tinyint(1) NOT NULL,
  `products_sort` int(4) NOT NULL DEFAULT '0',
  `products_image` varchar(254) COLLATE latin1_german1_ci NOT NULL,
  `products_price` decimal(15,4) NOT NULL,
  `products_discount_allowed` decimal(4,2) NOT NULL DEFAULT '0.00',
  `products_date_added` datetime NOT NULL,
  `products_last_modified` datetime DEFAULT NULL,
  `products_date_available` datetime DEFAULT NULL,
  `products_weight` decimal(6,3) NOT NULL,
  `products_status` int(1) NOT NULL,
  `products_tax_class_id` int(11) NOT NULL,
  `product_template` varchar(64) COLLATE latin1_german1_ci DEFAULT NULL,
  `options_template` varchar(64) COLLATE latin1_german1_ci DEFAULT NULL,
  `manufacturers_id` int(11) DEFAULT NULL,
  `products_manufacturers_model` varchar(64) COLLATE latin1_german1_ci DEFAULT NULL,
  `products_ordered` int(11) NOT NULL DEFAULT '0',
  `products_fsk18` int(1) NOT NULL DEFAULT '0',
  `products_vpe` int(11) NOT NULL,
  `products_vpe_status` int(1) NOT NULL DEFAULT '0',
  `products_vpe_value` decimal(15,4) NOT NULL,
  `products_startpage` int(1) NOT NULL DEFAULT '0',
  `products_startpage_sort` int(4) NOT NULL DEFAULT '0',
  PRIMARY KEY (`products_id`),
  KEY `idx_products_date_added` (`products_date_added`),
  KEY `idx_products_model` (`products_model`),
  KEY `idx_products_status` (`products_status`),
  KEY `idx_manufacturers_id` (`manufacturers_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_german1_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `products`
--

LOCK TABLES `products` WRITE;
/*!40000 ALTER TABLE `products` DISABLE KEYS */;
/*!40000 ALTER TABLE `products` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `products_attributes`
--

DROP TABLE IF EXISTS `products_attributes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `products_attributes` (
  `products_attributes_id` int(11) NOT NULL AUTO_INCREMENT,
  `products_id` int(11) NOT NULL,
  `options_id` int(11) NOT NULL,
  `options_values_id` int(11) NOT NULL,
  `options_values_price` decimal(15,4) NOT NULL,
  `price_prefix` char(1) COLLATE latin1_german1_ci NOT NULL,
  `attributes_model` varchar(64) COLLATE latin1_german1_ci DEFAULT NULL,
  `attributes_stock` int(4) DEFAULT NULL,
  `options_values_weight` decimal(15,4) NOT NULL,
  `weight_prefix` char(1) COLLATE latin1_german1_ci NOT NULL,
  `sortorder` int(11) DEFAULT NULL,
  `attributes_ean` varchar(64) COLLATE latin1_german1_ci DEFAULT NULL,
  `attributes_vpe_id` int(11) NOT NULL,
  `attributes_vpe_value` decimal(15,4) NOT NULL,
  PRIMARY KEY (`products_attributes_id`),
  KEY `idx_products_id` (`products_id`),
  KEY `idx_options` (`options_id`,`options_values_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_german1_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `products_attributes`
--

LOCK TABLES `products_attributes` WRITE;
/*!40000 ALTER TABLE `products_attributes` DISABLE KEYS */;
/*!40000 ALTER TABLE `products_attributes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `products_attributes_download`
--

DROP TABLE IF EXISTS `products_attributes_download`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `products_attributes_download` (
  `products_attributes_id` int(11) NOT NULL,
  `products_attributes_filename` varchar(255) COLLATE latin1_german1_ci NOT NULL DEFAULT '',
  `products_attributes_maxdays` int(2) DEFAULT '0',
  `products_attributes_maxcount` int(2) DEFAULT '0',
  PRIMARY KEY (`products_attributes_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_german1_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `products_attributes_download`
--

LOCK TABLES `products_attributes_download` WRITE;
/*!40000 ALTER TABLE `products_attributes_download` DISABLE KEYS */;
/*!40000 ALTER TABLE `products_attributes_download` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `products_content`
--

DROP TABLE IF EXISTS `products_content`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `products_content` (
  `content_id` int(11) NOT NULL AUTO_INCREMENT,
  `products_id` int(11) NOT NULL DEFAULT '0',
  `group_ids` text COLLATE latin1_german1_ci,
  `content_name` varchar(255) COLLATE latin1_german1_ci NOT NULL DEFAULT '',
  `content_file` varchar(255) COLLATE latin1_german1_ci NOT NULL,
  `content_link` text COLLATE latin1_german1_ci NOT NULL,
  `languages_id` int(11) NOT NULL,
  `content_read` int(11) NOT NULL DEFAULT '0',
  `file_comment` text COLLATE latin1_german1_ci NOT NULL,
  PRIMARY KEY (`content_id`),
  KEY `idx_products_id` (`products_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_german1_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `products_content`
--

LOCK TABLES `products_content` WRITE;
/*!40000 ALTER TABLE `products_content` DISABLE KEYS */;
/*!40000 ALTER TABLE `products_content` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `products_description`
--

DROP TABLE IF EXISTS `products_description`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `products_description` (
  `products_id` int(11) NOT NULL,
  `language_id` int(11) NOT NULL,
  `products_name` varchar(255) COLLATE latin1_german1_ci NOT NULL DEFAULT '',
  `products_description` text COLLATE latin1_german1_ci,
  `products_short_description` text COLLATE latin1_german1_ci,
  `products_keywords` varchar(255) COLLATE latin1_german1_ci DEFAULT NULL,
  `products_meta_title` text COLLATE latin1_german1_ci NOT NULL,
  `products_meta_description` text COLLATE latin1_german1_ci NOT NULL,
  `products_meta_keywords` text COLLATE latin1_german1_ci NOT NULL,
  `products_url` varchar(255) COLLATE latin1_german1_ci DEFAULT NULL,
  `products_viewed` int(5) DEFAULT '0',
  `products_order_description` text COLLATE latin1_german1_ci,
  PRIMARY KEY (`products_id`,`language_id`),
  KEY `idx_products_name` (`products_name`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_german1_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `products_description`
--

LOCK TABLES `products_description` WRITE;
/*!40000 ALTER TABLE `products_description` DISABLE KEYS */;
/*!40000 ALTER TABLE `products_description` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `products_graduated_prices`
--

DROP TABLE IF EXISTS `products_graduated_prices`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `products_graduated_prices` (
  `products_id` int(11) NOT NULL DEFAULT '0',
  `quantity` int(11) NOT NULL DEFAULT '0',
  `unitprice` decimal(15,4) NOT NULL DEFAULT '0.0000',
  KEY `idx_products_id` (`products_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_german1_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `products_graduated_prices`
--

LOCK TABLES `products_graduated_prices` WRITE;
/*!40000 ALTER TABLE `products_graduated_prices` DISABLE KEYS */;
/*!40000 ALTER TABLE `products_graduated_prices` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `products_images`
--

DROP TABLE IF EXISTS `products_images`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `products_images` (
  `image_id` int(11) NOT NULL AUTO_INCREMENT,
  `products_id` int(11) NOT NULL,
  `image_nr` smallint(6) NOT NULL,
  `image_name` varchar(254) COLLATE latin1_german1_ci NOT NULL,
  PRIMARY KEY (`image_id`),
  KEY `idx_products_id` (`products_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_german1_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `products_images`
--

LOCK TABLES `products_images` WRITE;
/*!40000 ALTER TABLE `products_images` DISABLE KEYS */;
/*!40000 ALTER TABLE `products_images` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `products_notifications`
--

DROP TABLE IF EXISTS `products_notifications`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `products_notifications` (
  `products_id` int(11) NOT NULL,
  `customers_id` int(11) NOT NULL,
  `date_added` datetime NOT NULL,
  PRIMARY KEY (`products_id`,`customers_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_german1_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `products_notifications`
--

LOCK TABLES `products_notifications` WRITE;
/*!40000 ALTER TABLE `products_notifications` DISABLE KEYS */;
/*!40000 ALTER TABLE `products_notifications` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `products_options`
--

DROP TABLE IF EXISTS `products_options`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `products_options` (
  `products_options_id` int(11) NOT NULL DEFAULT '0',
  `language_id` int(11) NOT NULL,
  `products_options_name` varchar(255) COLLATE latin1_german1_ci NOT NULL DEFAULT '',
  `products_options_sortorder` int(11) NOT NULL,
  PRIMARY KEY (`products_options_id`,`language_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_german1_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `products_options`
--

LOCK TABLES `products_options` WRITE;
/*!40000 ALTER TABLE `products_options` DISABLE KEYS */;
/*!40000 ALTER TABLE `products_options` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `products_options_values`
--

DROP TABLE IF EXISTS `products_options_values`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `products_options_values` (
  `products_options_values_id` int(11) NOT NULL DEFAULT '0',
  `language_id` int(11) NOT NULL,
  `products_options_values_name` varchar(255) COLLATE latin1_german1_ci NOT NULL DEFAULT '',
  `products_options_values_sortorder` int(11) NOT NULL,
  PRIMARY KEY (`products_options_values_id`,`language_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_german1_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `products_options_values`
--

LOCK TABLES `products_options_values` WRITE;
/*!40000 ALTER TABLE `products_options_values` DISABLE KEYS */;
/*!40000 ALTER TABLE `products_options_values` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `products_options_values_to_products_options`
--

DROP TABLE IF EXISTS `products_options_values_to_products_options`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `products_options_values_to_products_options` (
  `products_options_values_to_products_options_id` int(11) NOT NULL AUTO_INCREMENT,
  `products_options_id` int(11) NOT NULL,
  `products_options_values_id` int(11) NOT NULL,
  PRIMARY KEY (`products_options_values_to_products_options_id`),
  KEY `idx_products_options_id` (`products_options_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_german1_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `products_options_values_to_products_options`
--

LOCK TABLES `products_options_values_to_products_options` WRITE;
/*!40000 ALTER TABLE `products_options_values_to_products_options` DISABLE KEYS */;
/*!40000 ALTER TABLE `products_options_values_to_products_options` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `products_tags`
--

DROP TABLE IF EXISTS `products_tags`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `products_tags` (
  `products_id` int(11) NOT NULL,
  `options_id` int(11) NOT NULL,
  `values_id` int(11) NOT NULL,
  `products_options_id` int(11) NOT NULL DEFAULT '0',
  `products_options_values_id` int(11) NOT NULL DEFAULT '0',
  KEY `idx_products_options_values` (`products_id`,`options_id`,`values_id`),
  KEY `idx_products_options_id` (`products_options_id`),
  KEY `idx_options_id` (`options_id`),
  KEY `idx_values_id` (`values_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_german1_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `products_tags`
--

LOCK TABLES `products_tags` WRITE;
/*!40000 ALTER TABLE `products_tags` DISABLE KEYS */;
/*!40000 ALTER TABLE `products_tags` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `products_tags_options`
--

DROP TABLE IF EXISTS `products_tags_options`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `products_tags_options` (
  `options_id` int(11) NOT NULL,
  `options_name` varchar(128) COLLATE latin1_german1_ci NOT NULL,
  `options_description` text COLLATE latin1_german1_ci NOT NULL,
  `options_content_group` int(11) DEFAULT NULL,
  `sort_order` int(11) NOT NULL DEFAULT '0',
  `languages_id` int(11) NOT NULL,
  `status` int(1) NOT NULL DEFAULT '1',
  `filter` int(1) NOT NULL DEFAULT '1',
  `last_modified` datetime DEFAULT NULL,
  `date_added` datetime NOT NULL,
  `products_options_id` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`options_id`,`languages_id`),
  KEY `idx_products_options_id` (`products_options_id`),
  KEY `idx_filter` (`filter`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_german1_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `products_tags_options`
--

LOCK TABLES `products_tags_options` WRITE;
/*!40000 ALTER TABLE `products_tags_options` DISABLE KEYS */;
/*!40000 ALTER TABLE `products_tags_options` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `products_tags_values`
--

DROP TABLE IF EXISTS `products_tags_values`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `products_tags_values` (
  `values_id` int(11) NOT NULL,
  `options_id` int(11) NOT NULL,
  `values_name` varchar(128) COLLATE latin1_german1_ci NOT NULL,
  `values_description` text COLLATE latin1_german1_ci NOT NULL,
  `values_image` varchar(128) COLLATE latin1_german1_ci NOT NULL,
  `values_content_group` int(11) DEFAULT NULL,
  `sort_order` int(11) NOT NULL DEFAULT '0',
  `languages_id` int(11) NOT NULL,
  `status` int(1) NOT NULL DEFAULT '1',
  `filter` int(1) NOT NULL DEFAULT '1',
  `last_modified` datetime DEFAULT NULL,
  `date_added` datetime NOT NULL,
  `products_options_values_id` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`values_id`,`languages_id`),
  KEY `idx_options_id` (`options_id`),
  KEY `idx_products_options_values_id` (`products_options_values_id`),
  KEY `idx_filter` (`filter`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_german1_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `products_tags_values`
--

LOCK TABLES `products_tags_values` WRITE;
/*!40000 ALTER TABLE `products_tags_values` DISABLE KEYS */;
/*!40000 ALTER TABLE `products_tags_values` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `products_to_categories`
--

DROP TABLE IF EXISTS `products_to_categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `products_to_categories` (
  `products_id` int(11) NOT NULL,
  `categories_id` int(11) NOT NULL,
  PRIMARY KEY (`products_id`,`categories_id`),
  KEY `idx_categories_id` (`categories_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_german1_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `products_to_categories`
--

LOCK TABLES `products_to_categories` WRITE;
/*!40000 ALTER TABLE `products_to_categories` DISABLE KEYS */;
/*!40000 ALTER TABLE `products_to_categories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `products_vpe`
--

DROP TABLE IF EXISTS `products_vpe`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `products_vpe` (
  `products_vpe_id` int(11) NOT NULL DEFAULT '0',
  `language_id` int(11) NOT NULL,
  `products_vpe_name` varchar(32) COLLATE latin1_german1_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`products_vpe_id`,`language_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_german1_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `products_vpe`
--

LOCK TABLES `products_vpe` WRITE;
/*!40000 ALTER TABLE `products_vpe` DISABLE KEYS */;
/*!40000 ALTER TABLE `products_vpe` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `products_xsell`
--

DROP TABLE IF EXISTS `products_xsell`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `products_xsell` (
  `ID` int(10) NOT NULL AUTO_INCREMENT,
  `products_id` int(10) unsigned NOT NULL DEFAULT '1',
  `products_xsell_grp_name_id` int(10) unsigned NOT NULL DEFAULT '1',
  `xsell_id` int(10) unsigned NOT NULL DEFAULT '1',
  `sort_order` int(10) unsigned NOT NULL DEFAULT '1',
  PRIMARY KEY (`ID`),
  KEY `idx_xsell_id` (`xsell_id`),
  KEY `idx_products_id` (`products_id`),
  KEY `idx_products_xsell_grp_name_id` (`products_xsell_grp_name_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_german1_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `products_xsell`
--

LOCK TABLES `products_xsell` WRITE;
/*!40000 ALTER TABLE `products_xsell` DISABLE KEYS */;
/*!40000 ALTER TABLE `products_xsell` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `products_xsell_grp_name`
--

DROP TABLE IF EXISTS `products_xsell_grp_name`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `products_xsell_grp_name` (
  `products_xsell_grp_name_id` int(10) NOT NULL,
  `xsell_sort_order` int(10) NOT NULL DEFAULT '0',
  `language_id` int(11) NOT NULL,
  `groupname` varchar(255) COLLATE latin1_german1_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`products_xsell_grp_name_id`,`language_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_german1_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `products_xsell_grp_name`
--

LOCK TABLES `products_xsell_grp_name` WRITE;
/*!40000 ALTER TABLE `products_xsell_grp_name` DISABLE KEYS */;
/*!40000 ALTER TABLE `products_xsell_grp_name` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `reviews`
--

DROP TABLE IF EXISTS `reviews`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `reviews` (
  `reviews_id` int(11) NOT NULL AUTO_INCREMENT,
  `products_id` int(11) NOT NULL,
  `customers_id` int(11) DEFAULT NULL,
  `customers_name` varchar(64) COLLATE latin1_german1_ci NOT NULL,
  `reviews_rating` int(1) DEFAULT NULL,
  `date_added` datetime DEFAULT NULL,
  `last_modified` datetime DEFAULT NULL,
  `reviews_read` int(5) NOT NULL DEFAULT '0',
  `reviews_status` int(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`reviews_id`),
  KEY `idx_products_id` (`products_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_german1_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `reviews`
--

LOCK TABLES `reviews` WRITE;
/*!40000 ALTER TABLE `reviews` DISABLE KEYS */;
/*!40000 ALTER TABLE `reviews` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `reviews_description`
--

DROP TABLE IF EXISTS `reviews_description`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `reviews_description` (
  `reviews_id` int(11) NOT NULL,
  `languages_id` int(11) NOT NULL,
  `reviews_text` text COLLATE latin1_german1_ci NOT NULL,
  PRIMARY KEY (`reviews_id`,`languages_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_german1_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `reviews_description`
--

LOCK TABLES `reviews_description` WRITE;
/*!40000 ALTER TABLE `reviews_description` DISABLE KEYS */;
/*!40000 ALTER TABLE `reviews_description` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sessions`
--

DROP TABLE IF EXISTS `sessions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sessions` (
  `sesskey` varchar(32) COLLATE latin1_german1_ci NOT NULL,
  `expiry` int(11) unsigned NOT NULL,
  `value` longtext COLLATE latin1_german1_ci NOT NULL,
  `flag` varchar(5) COLLATE latin1_german1_ci DEFAULT NULL,
  PRIMARY KEY (`sesskey`),
  KEY `idx_expiry` (`expiry`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_german1_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sessions`
--

LOCK TABLES `sessions` WRITE;
/*!40000 ALTER TABLE `sessions` DISABLE KEYS */;
INSERT INTO `sessions` VALUES ('kqme55snk7qhkjgo85eai8pa04',1549608554,'dHJhY2tpbmd8YTo1OntzOjI6ImlwIjtzOjE1OiIxNzguMjM4LjIzOS4yNDYiO3M6MTI6Imh0dHBfcmVmZXJlciI7YTozOntzOjY6InNjaGVtZSI7czo1OiJodHRwcyI7czo0OiJob3N0IjtzOjE2OiJkZXYtbmcuYXNjYXNhLmRlIjtzOjQ6InBhdGgiO3M6MToiLyI7fXM6NDoiZGF0ZSI7czoxOToiMjAxOS0wMi0wOCAwNzoyNDoyMCI7czo3OiJicm93c2VyIjtzOjc3OiJNb3ppbGxhLzUuMCAoV2luZG93cyBOVCA2LjE7IFdpbjY0OyB4NjQ7IHJ2OjYwLjApIEdlY2tvLzIwMTAwMTAxIEZpcmVmb3gvNjAuMCI7czoxNjoicGFnZXZpZXdfaGlzdG9yeSI7YToxOntpOjA7YTozOntzOjY6InNjaGVtZSI7czo1OiJodHRwcyI7czo0OiJob3N0IjtzOjE2OiJkZXYtbmcuYXNjYXNhLmRlIjtzOjQ6InBhdGgiO3M6MToiLyI7fX19bGFuZ3VhZ2V8czo2OiJnZXJtYW4iO2xhbmd1YWdlc19pZHxzOjE6IjIiO2xhbmd1YWdlX2NoYXJzZXR8czoxMToiaXNvLTg4NTktMTUiO2xhbmd1YWdlX2NvZGV8czoyOiJkZSI7Y3VycmVuY3l8czozOiJFVVIiO2N1c3RvbWVyc19zdGF0dXN8YToyNTp7czoxOToiY3VzdG9tZXJzX3N0YXR1c19pZCI7czoxOiIxIjtzOjExOiJsYW5ndWFnZV9pZCI7czoxOiIyIjtzOjIxOiJjdXN0b21lcnNfc3RhdHVzX25hbWUiO3M6NDoiR2FzdCI7czoyMzoiY3VzdG9tZXJzX3N0YXR1c19wdWJsaWMiO3M6MToiMSI7czoyNjoiY3VzdG9tZXJzX3N0YXR1c19taW5fb3JkZXIiO047czoyNjoiY3VzdG9tZXJzX3N0YXR1c19tYXhfb3JkZXIiO047czoyMjoiY3VzdG9tZXJzX3N0YXR1c19pbWFnZSI7czoxNjoiZ3Vlc3Rfc3RhdHVzLmdpZiI7czoyNToiY3VzdG9tZXJzX3N0YXR1c19kaXNjb3VudCI7czo0OiIwLjAwIjtzOjMzOiJjdXN0b21lcnNfc3RhdHVzX290X2Rpc2NvdW50X2ZsYWciO3M6MToiMCI7czoyODoiY3VzdG9tZXJzX3N0YXR1c19vdF9kaXNjb3VudCI7czo0OiIwLjAwIjtzOjMzOiJjdXN0b21lcnNfc3RhdHVzX2dyYWR1YXRlZF9wcmljZXMiO3M6MToiMCI7czoyNzoiY3VzdG9tZXJzX3N0YXR1c19zaG93X3ByaWNlIjtzOjE6IjEiO3M6MzE6ImN1c3RvbWVyc19zdGF0dXNfc2hvd19wcmljZV90YXgiO3M6MToiMSI7czozMToiY3VzdG9tZXJzX3N0YXR1c19zaG93X3RheF90b3RhbCI7czozOiIxNTAiO3M6Mjc6ImN1c3RvbWVyc19zdGF0dXNfYWRkX3RheF9vdCI7czoxOiIwIjtzOjM0OiJjdXN0b21lcnNfc3RhdHVzX3BheW1lbnRfdW5hbGxvd2VkIjtzOjA6IiI7czozNToiY3VzdG9tZXJzX3N0YXR1c19zaGlwcGluZ191bmFsbG93ZWQiO3M6MDoiIjtzOjM2OiJjdXN0b21lcnNfc3RhdHVzX2Rpc2NvdW50X2F0dHJpYnV0ZXMiO3M6MToiMCI7czoxNToiY3VzdG9tZXJzX2ZzazE4IjtzOjE6IjEiO3M6MjM6ImN1c3RvbWVyc19mc2sxOF9kaXNwbGF5IjtzOjE6IjEiO3M6MzA6ImN1c3RvbWVyc19zdGF0dXNfd3JpdGVfcmV2aWV3cyI7czoxOiIwIjtzOjI5OiJjdXN0b21lcnNfc3RhdHVzX3JlYWRfcmV2aWV3cyI7czoxOiIxIjtzOjMxOiJjdXN0b21lcnNfc3RhdHVzX3Jldmlld3Nfc3RhdHVzIjtzOjE6IjAiO3M6MjU6ImN1c3RvbWVyc19zdGF0dXNfc3BlY2lhbHMiO3M6MToiMSI7czoxNjoiY3VzdG9tZXJzX3N0YXR1cyI7czoxOiIxIjt9Y2FydHxPOjEyOiJzaG9wcGluZ0NhcnQiOjEyOntzOjg6ImNvbnRlbnRzIjthOjA6e31zOjU6InRvdGFsIjtpOjA7czo2OiJ3ZWlnaHQiO2k6MDtzOjY6ImNhcnRJRCI7TjtzOjEyOiJjb250ZW50X3R5cGUiO3M6ODoicGh5c2ljYWwiO3M6MTA6ImF0dHJfcHJpY2UiO2k6MDtzOjExOiJhdHRyX3dlaWdodCI7aTowO3M6NDoidHlwZSI7czo0OiJjYXJ0IjtzOjEyOiJ0YWJsZV9iYXNrZXQiO3M6MTY6ImN1c3RvbWVyc19iYXNrZXQiO3M6MjM6InRhYmxlX2Jhc2tldF9hdHRyaWJ1dGVzIjtzOjI3OiJjdXN0b21lcnNfYmFza2V0X2F0dHJpYnV0ZXMiO3M6MTk6InNob3BwaW5nQ2FydE1vZHVsZXMiO086MTk6InNob3BwaW5nQ2FydE1vZHVsZXMiOjA6e31zOjM6InRheCI7aTowO31hY2NvdW50X3R5cGV8czoxOiIwIjtDYXRQYXRofHM6NzoiODA1XzgwNiI7YWN0dWFsX2NvbnRlbnR8YToxOntpOjA7YToxOntzOjM6InF0eSI7aTowO319',''),('1hnd373av7t42gapapkh9es7m4',1549708334,'dHJhY2tpbmd8YTo1OntzOjI6ImlwIjtzOjE1OiIxNzguMjM4LjIzOS4yNDYiO3M6MTI6Imh0dHBfcmVmZXJlciI7YToyOntzOjQ6InBhdGgiO3M6MTc6ImRldi1uZy5hc2Nhc2EuZGUvIjtzOjQ6Imhvc3QiO3M6MTY6ImRldi1uZy5hc2Nhc2EuZGUiO31zOjQ6ImRhdGUiO3M6MTk6IjIwMTktMDItMDkgMTE6MDc6MzEiO3M6NzoiYnJvd3NlciI7czo3NzoiTW96aWxsYS81LjAgKFdpbmRvd3MgTlQgNi4xOyBXaW42NDsgeDY0OyBydjo2MC4wKSBHZWNrby8yMDEwMDEwMSBGaXJlZm94LzYwLjAiO3M6MTY6InBhZ2V2aWV3X2hpc3RvcnkiO2E6Mjp7aTowO2E6MTp7czo0OiJwYXRoIjtzOjE3OiJkZXYtbmcuYXNjYXNhLmRlLyI7fWk6MTthOjE6e3M6NDoicGF0aCI7czoyODoiZGV2LW5nLmFzY2FzYS5kZS9mYXZpY29uLmljbyI7fX19bGFuZ3VhZ2V8czo2OiJnZXJtYW4iO2xhbmd1YWdlc19pZHxzOjE6IjIiO2xhbmd1YWdlX2NoYXJzZXR8czoxMToiaXNvLTg4NTktMTUiO2xhbmd1YWdlX2NvZGV8czoyOiJkZSI7Y3VycmVuY3l8czozOiJFVVIiO2N1c3RvbWVyc19zdGF0dXN8YToyNTp7czoxOToiY3VzdG9tZXJzX3N0YXR1c19pZCI7czoxOiIxIjtzOjExOiJsYW5ndWFnZV9pZCI7czoxOiIyIjtzOjIxOiJjdXN0b21lcnNfc3RhdHVzX25hbWUiO3M6NDoiR2FzdCI7czoyMzoiY3VzdG9tZXJzX3N0YXR1c19wdWJsaWMiO3M6MToiMSI7czoyNjoiY3VzdG9tZXJzX3N0YXR1c19taW5fb3JkZXIiO047czoyNjoiY3VzdG9tZXJzX3N0YXR1c19tYXhfb3JkZXIiO047czoyMjoiY3VzdG9tZXJzX3N0YXR1c19pbWFnZSI7czoxNjoiZ3Vlc3Rfc3RhdHVzLmdpZiI7czoyNToiY3VzdG9tZXJzX3N0YXR1c19kaXNjb3VudCI7czo0OiIwLjAwIjtzOjMzOiJjdXN0b21lcnNfc3RhdHVzX290X2Rpc2NvdW50X2ZsYWciO3M6MToiMCI7czoyODoiY3VzdG9tZXJzX3N0YXR1c19vdF9kaXNjb3VudCI7czo0OiIwLjAwIjtzOjMzOiJjdXN0b21lcnNfc3RhdHVzX2dyYWR1YXRlZF9wcmljZXMiO3M6MToiMCI7czoyNzoiY3VzdG9tZXJzX3N0YXR1c19zaG93X3ByaWNlIjtzOjE6IjEiO3M6MzE6ImN1c3RvbWVyc19zdGF0dXNfc2hvd19wcmljZV90YXgiO3M6MToiMSI7czozMToiY3VzdG9tZXJzX3N0YXR1c19zaG93X3RheF90b3RhbCI7czozOiIxNTAiO3M6Mjc6ImN1c3RvbWVyc19zdGF0dXNfYWRkX3RheF9vdCI7czoxOiIwIjtzOjM0OiJjdXN0b21lcnNfc3RhdHVzX3BheW1lbnRfdW5hbGxvd2VkIjtzOjA6IiI7czozNToiY3VzdG9tZXJzX3N0YXR1c19zaGlwcGluZ191bmFsbG93ZWQiO3M6MDoiIjtzOjM2OiJjdXN0b21lcnNfc3RhdHVzX2Rpc2NvdW50X2F0dHJpYnV0ZXMiO3M6MToiMCI7czoxNToiY3VzdG9tZXJzX2ZzazE4IjtzOjE6IjEiO3M6MjM6ImN1c3RvbWVyc19mc2sxOF9kaXNwbGF5IjtzOjE6IjEiO3M6MzA6ImN1c3RvbWVyc19zdGF0dXNfd3JpdGVfcmV2aWV3cyI7czoxOiIwIjtzOjI5OiJjdXN0b21lcnNfc3RhdHVzX3JlYWRfcmV2aWV3cyI7czoxOiIxIjtzOjMxOiJjdXN0b21lcnNfc3RhdHVzX3Jldmlld3Nfc3RhdHVzIjtzOjE6IjAiO3M6MjU6ImN1c3RvbWVyc19zdGF0dXNfc3BlY2lhbHMiO3M6MToiMSI7czoxNjoiY3VzdG9tZXJzX3N0YXR1cyI7czoxOiIxIjt9Y2FydHxPOjEyOiJzaG9wcGluZ0NhcnQiOjEyOntzOjg6ImNvbnRlbnRzIjthOjA6e31zOjU6InRvdGFsIjtpOjA7czo2OiJ3ZWlnaHQiO2k6MDtzOjY6ImNhcnRJRCI7TjtzOjEyOiJjb250ZW50X3R5cGUiO3M6ODoicGh5c2ljYWwiO3M6MTA6ImF0dHJfcHJpY2UiO2k6MDtzOjExOiJhdHRyX3dlaWdodCI7aTowO3M6NDoidHlwZSI7czo0OiJjYXJ0IjtzOjEyOiJ0YWJsZV9iYXNrZXQiO3M6MTY6ImN1c3RvbWVyc19iYXNrZXQiO3M6MjM6InRhYmxlX2Jhc2tldF9hdHRyaWJ1dGVzIjtzOjI3OiJjdXN0b21lcnNfYmFza2V0X2F0dHJpYnV0ZXMiO3M6MTk6InNob3BwaW5nQ2FydE1vZHVsZXMiO086MTk6InNob3BwaW5nQ2FydE1vZHVsZXMiOjA6e31zOjM6InRheCI7aTowO31hY2NvdW50X3R5cGV8czoxOiIwIjthY3R1YWxfY29udGVudHxhOjE6e2k6MDthOjE6e3M6MzoicXR5IjtpOjA7fX0=',''),('neliofgdpmc0gp843hrepkthmr',1549608497,'dHJhY2tpbmd8YTo1OntzOjI6ImlwIjtzOjE1OiIxNzguMjM4LjIzOS4yNDYiO3M6MTI6Imh0dHBfcmVmZXJlciI7YToyOntzOjQ6InBhdGgiO3M6MTc6ImRldi1uZy5hc2Nhc2EuZGUvIjtzOjQ6Imhvc3QiO3M6MTY6ImRldi1uZy5hc2Nhc2EuZGUiO31zOjQ6ImRhdGUiO3M6MTk6IjIwMTktMDItMDggMDc6MjQ6MTQiO3M6NzoiYnJvd3NlciI7czo3NzoiTW96aWxsYS81LjAgKFdpbmRvd3MgTlQgNi4xOyBXaW42NDsgeDY0OyBydjo2MC4wKSBHZWNrby8yMDEwMDEwMSBGaXJlZm94LzYwLjAiO3M6MTY6InBhZ2V2aWV3X2hpc3RvcnkiO2E6MTp7aTowO2E6MTp7czo0OiJwYXRoIjtzOjE3OiJkZXYtbmcuYXNjYXNhLmRlLyI7fX19bGFuZ3VhZ2V8czo2OiJnZXJtYW4iO2xhbmd1YWdlc19pZHxzOjE6IjIiO2xhbmd1YWdlX2NoYXJzZXR8czoxMToiaXNvLTg4NTktMTUiO2xhbmd1YWdlX2NvZGV8czoyOiJkZSI7Y3VycmVuY3l8czozOiJFVVIiO2N1c3RvbWVyc19zdGF0dXN8YToyNTp7czoxOToiY3VzdG9tZXJzX3N0YXR1c19pZCI7czoxOiIxIjtzOjExOiJsYW5ndWFnZV9pZCI7czoxOiIyIjtzOjIxOiJjdXN0b21lcnNfc3RhdHVzX25hbWUiO3M6NDoiR2FzdCI7czoyMzoiY3VzdG9tZXJzX3N0YXR1c19wdWJsaWMiO3M6MToiMSI7czoyNjoiY3VzdG9tZXJzX3N0YXR1c19taW5fb3JkZXIiO047czoyNjoiY3VzdG9tZXJzX3N0YXR1c19tYXhfb3JkZXIiO047czoyMjoiY3VzdG9tZXJzX3N0YXR1c19pbWFnZSI7czoxNjoiZ3Vlc3Rfc3RhdHVzLmdpZiI7czoyNToiY3VzdG9tZXJzX3N0YXR1c19kaXNjb3VudCI7czo0OiIwLjAwIjtzOjMzOiJjdXN0b21lcnNfc3RhdHVzX290X2Rpc2NvdW50X2ZsYWciO3M6MToiMCI7czoyODoiY3VzdG9tZXJzX3N0YXR1c19vdF9kaXNjb3VudCI7czo0OiIwLjAwIjtzOjMzOiJjdXN0b21lcnNfc3RhdHVzX2dyYWR1YXRlZF9wcmljZXMiO3M6MToiMCI7czoyNzoiY3VzdG9tZXJzX3N0YXR1c19zaG93X3ByaWNlIjtzOjE6IjEiO3M6MzE6ImN1c3RvbWVyc19zdGF0dXNfc2hvd19wcmljZV90YXgiO3M6MToiMSI7czozMToiY3VzdG9tZXJzX3N0YXR1c19zaG93X3RheF90b3RhbCI7czozOiIxNTAiO3M6Mjc6ImN1c3RvbWVyc19zdGF0dXNfYWRkX3RheF9vdCI7czoxOiIwIjtzOjM0OiJjdXN0b21lcnNfc3RhdHVzX3BheW1lbnRfdW5hbGxvd2VkIjtzOjA6IiI7czozNToiY3VzdG9tZXJzX3N0YXR1c19zaGlwcGluZ191bmFsbG93ZWQiO3M6MDoiIjtzOjM2OiJjdXN0b21lcnNfc3RhdHVzX2Rpc2NvdW50X2F0dHJpYnV0ZXMiO3M6MToiMCI7czoxNToiY3VzdG9tZXJzX2ZzazE4IjtzOjE6IjEiO3M6MjM6ImN1c3RvbWVyc19mc2sxOF9kaXNwbGF5IjtzOjE6IjEiO3M6MzA6ImN1c3RvbWVyc19zdGF0dXNfd3JpdGVfcmV2aWV3cyI7czoxOiIwIjtzOjI5OiJjdXN0b21lcnNfc3RhdHVzX3JlYWRfcmV2aWV3cyI7czoxOiIxIjtzOjMxOiJjdXN0b21lcnNfc3RhdHVzX3Jldmlld3Nfc3RhdHVzIjtzOjE6IjAiO3M6MjU6ImN1c3RvbWVyc19zdGF0dXNfc3BlY2lhbHMiO3M6MToiMSI7czoxNjoiY3VzdG9tZXJzX3N0YXR1cyI7czoxOiIxIjt9Y2FydHxPOjEyOiJzaG9wcGluZ0NhcnQiOjExOntzOjg6ImNvbnRlbnRzIjthOjA6e31zOjU6InRvdGFsIjtpOjA7czo2OiJ3ZWlnaHQiO2k6MDtzOjEyOiJjb250ZW50X3R5cGUiO2I6MDtzOjEwOiJhdHRyX3ByaWNlIjtpOjA7czoxMToiYXR0cl93ZWlnaHQiO2k6MDtzOjQ6InR5cGUiO3M6NDoiY2FydCI7czoxMjoidGFibGVfYmFza2V0IjtzOjE2OiJjdXN0b21lcnNfYmFza2V0IjtzOjIzOiJ0YWJsZV9iYXNrZXRfYXR0cmlidXRlcyI7czoyNzoiY3VzdG9tZXJzX2Jhc2tldF9hdHRyaWJ1dGVzIjtzOjE5OiJzaG9wcGluZ0NhcnRNb2R1bGVzIjtPOjE5OiJzaG9wcGluZ0NhcnRNb2R1bGVzIjowOnt9czozOiJ0YXgiO2k6MDt9YWNjb3VudF90eXBlfHM6MToiMCI7YWN0dWFsX2NvbnRlbnR8YToxOntpOjA7YToxOntzOjM6InF0eSI7aTowO319',''),('ujhjj4sq306un9l68hrmkc77ns',1549708923,'dHJhY2tpbmd8YTo1OntzOjI6ImlwIjtzOjEzOiI5My4yNTUuNDkuMTYxIjtzOjEyOiJodHRwX3JlZmVyZXIiO2E6Mjp7czo0OiJwYXRoIjtzOjI4OiJkZXYtbmcuYXNjYXNhLmRlL2Zhdmljb24uaWNvIjtzOjQ6Imhvc3QiO3M6MTY6ImRldi1uZy5hc2Nhc2EuZGUiO31zOjQ6ImRhdGUiO3M6MTk6IjIwMTktMDItMDkgMTE6MTc6NDMiO3M6NzoiYnJvd3NlciI7czo3ODoiTW96aWxsYS81LjAgKFdpbmRvd3MgTlQgMTAuMDsgV2luNjQ7IHg2NDsgcnY6NjAuMCkgR2Vja28vMjAxMDAxMDEgRmlyZWZveC82MC4wIjtzOjE2OiJwYWdldmlld19oaXN0b3J5IjthOjE6e2k6MDthOjE6e3M6NDoicGF0aCI7czoyODoiZGV2LW5nLmFzY2FzYS5kZS9mYXZpY29uLmljbyI7fX19bGFuZ3VhZ2V8czo2OiJnZXJtYW4iO2xhbmd1YWdlc19pZHxzOjE6IjIiO2xhbmd1YWdlX2NoYXJzZXR8czoxMToiaXNvLTg4NTktMTUiO2xhbmd1YWdlX2NvZGV8czoyOiJkZSI7Y3VycmVuY3l8czozOiJFVVIiO2N1c3RvbWVyc19zdGF0dXN8YToyNTp7czoxOToiY3VzdG9tZXJzX3N0YXR1c19pZCI7czoxOiIxIjtzOjExOiJsYW5ndWFnZV9pZCI7czoxOiIyIjtzOjIxOiJjdXN0b21lcnNfc3RhdHVzX25hbWUiO3M6NDoiR2FzdCI7czoyMzoiY3VzdG9tZXJzX3N0YXR1c19wdWJsaWMiO3M6MToiMSI7czoyNjoiY3VzdG9tZXJzX3N0YXR1c19taW5fb3JkZXIiO047czoyNjoiY3VzdG9tZXJzX3N0YXR1c19tYXhfb3JkZXIiO047czoyMjoiY3VzdG9tZXJzX3N0YXR1c19pbWFnZSI7czoxNjoiZ3Vlc3Rfc3RhdHVzLmdpZiI7czoyNToiY3VzdG9tZXJzX3N0YXR1c19kaXNjb3VudCI7czo0OiIwLjAwIjtzOjMzOiJjdXN0b21lcnNfc3RhdHVzX290X2Rpc2NvdW50X2ZsYWciO3M6MToiMCI7czoyODoiY3VzdG9tZXJzX3N0YXR1c19vdF9kaXNjb3VudCI7czo0OiIwLjAwIjtzOjMzOiJjdXN0b21lcnNfc3RhdHVzX2dyYWR1YXRlZF9wcmljZXMiO3M6MToiMCI7czoyNzoiY3VzdG9tZXJzX3N0YXR1c19zaG93X3ByaWNlIjtzOjE6IjEiO3M6MzE6ImN1c3RvbWVyc19zdGF0dXNfc2hvd19wcmljZV90YXgiO3M6MToiMSI7czozMToiY3VzdG9tZXJzX3N0YXR1c19zaG93X3RheF90b3RhbCI7czozOiIxNTAiO3M6Mjc6ImN1c3RvbWVyc19zdGF0dXNfYWRkX3RheF9vdCI7czoxOiIwIjtzOjM0OiJjdXN0b21lcnNfc3RhdHVzX3BheW1lbnRfdW5hbGxvd2VkIjtzOjA6IiI7czozNToiY3VzdG9tZXJzX3N0YXR1c19zaGlwcGluZ191bmFsbG93ZWQiO3M6MDoiIjtzOjM2OiJjdXN0b21lcnNfc3RhdHVzX2Rpc2NvdW50X2F0dHJpYnV0ZXMiO3M6MToiMCI7czoxNToiY3VzdG9tZXJzX2ZzazE4IjtzOjE6IjEiO3M6MjM6ImN1c3RvbWVyc19mc2sxOF9kaXNwbGF5IjtzOjE6IjEiO3M6MzA6ImN1c3RvbWVyc19zdGF0dXNfd3JpdGVfcmV2aWV3cyI7czoxOiIwIjtzOjI5OiJjdXN0b21lcnNfc3RhdHVzX3JlYWRfcmV2aWV3cyI7czoxOiIxIjtzOjMxOiJjdXN0b21lcnNfc3RhdHVzX3Jldmlld3Nfc3RhdHVzIjtzOjE6IjAiO3M6MjU6ImN1c3RvbWVyc19zdGF0dXNfc3BlY2lhbHMiO3M6MToiMSI7czoxNjoiY3VzdG9tZXJzX3N0YXR1cyI7czoxOiIxIjt9Y2FydHxPOjEyOiJzaG9wcGluZ0NhcnQiOjExOntzOjg6ImNvbnRlbnRzIjthOjA6e31zOjU6InRvdGFsIjtpOjA7czo2OiJ3ZWlnaHQiO2k6MDtzOjEyOiJjb250ZW50X3R5cGUiO2I6MDtzOjEwOiJhdHRyX3ByaWNlIjtpOjA7czoxMToiYXR0cl93ZWlnaHQiO2k6MDtzOjQ6InR5cGUiO3M6NDoiY2FydCI7czoxMjoidGFibGVfYmFza2V0IjtzOjE2OiJjdXN0b21lcnNfYmFza2V0IjtzOjIzOiJ0YWJsZV9iYXNrZXRfYXR0cmlidXRlcyI7czoyNzoiY3VzdG9tZXJzX2Jhc2tldF9hdHRyaWJ1dGVzIjtzOjE5OiJzaG9wcGluZ0NhcnRNb2R1bGVzIjtPOjE5OiJzaG9wcGluZ0NhcnRNb2R1bGVzIjowOnt9czozOiJ0YXgiO2k6MDt9YWNjb3VudF90eXBlfHM6MToiMCI7YWN0dWFsX2NvbnRlbnR8YToxOntpOjA7YToxOntzOjM6InF0eSI7aTowO319',''),('42uoq0o3et4lgtqqadp6tonco1',1549708924,'dHJhY2tpbmd8YTo1OntzOjI6ImlwIjtzOjEzOiI5My4yNTUuNDkuMTYxIjtzOjEyOiJodHRwX3JlZmVyZXIiO2E6Mjp7czo0OiJwYXRoIjtzOjI4OiJkZXYtbmcuYXNjYXNhLmRlL2Zhdmljb24uaWNvIjtzOjQ6Imhvc3QiO3M6MTY6ImRldi1uZy5hc2Nhc2EuZGUiO31zOjQ6ImRhdGUiO3M6MTk6IjIwMTktMDItMDkgMTE6MTc6NDMiO3M6NzoiYnJvd3NlciI7czo3ODoiTW96aWxsYS81LjAgKFdpbmRvd3MgTlQgMTAuMDsgV2luNjQ7IHg2NDsgcnY6NjAuMCkgR2Vja28vMjAxMDAxMDEgRmlyZWZveC82MC4wIjtzOjE2OiJwYWdldmlld19oaXN0b3J5IjthOjE6e2k6MDthOjE6e3M6NDoicGF0aCI7czoyODoiZGV2LW5nLmFzY2FzYS5kZS9mYXZpY29uLmljbyI7fX19bGFuZ3VhZ2V8czo2OiJnZXJtYW4iO2xhbmd1YWdlc19pZHxzOjE6IjIiO2xhbmd1YWdlX2NoYXJzZXR8czoxMToiaXNvLTg4NTktMTUiO2xhbmd1YWdlX2NvZGV8czoyOiJkZSI7Y3VycmVuY3l8czozOiJFVVIiO2N1c3RvbWVyc19zdGF0dXN8YToyNTp7czoxOToiY3VzdG9tZXJzX3N0YXR1c19pZCI7czoxOiIxIjtzOjExOiJsYW5ndWFnZV9pZCI7czoxOiIyIjtzOjIxOiJjdXN0b21lcnNfc3RhdHVzX25hbWUiO3M6NDoiR2FzdCI7czoyMzoiY3VzdG9tZXJzX3N0YXR1c19wdWJsaWMiO3M6MToiMSI7czoyNjoiY3VzdG9tZXJzX3N0YXR1c19taW5fb3JkZXIiO047czoyNjoiY3VzdG9tZXJzX3N0YXR1c19tYXhfb3JkZXIiO047czoyMjoiY3VzdG9tZXJzX3N0YXR1c19pbWFnZSI7czoxNjoiZ3Vlc3Rfc3RhdHVzLmdpZiI7czoyNToiY3VzdG9tZXJzX3N0YXR1c19kaXNjb3VudCI7czo0OiIwLjAwIjtzOjMzOiJjdXN0b21lcnNfc3RhdHVzX290X2Rpc2NvdW50X2ZsYWciO3M6MToiMCI7czoyODoiY3VzdG9tZXJzX3N0YXR1c19vdF9kaXNjb3VudCI7czo0OiIwLjAwIjtzOjMzOiJjdXN0b21lcnNfc3RhdHVzX2dyYWR1YXRlZF9wcmljZXMiO3M6MToiMCI7czoyNzoiY3VzdG9tZXJzX3N0YXR1c19zaG93X3ByaWNlIjtzOjE6IjEiO3M6MzE6ImN1c3RvbWVyc19zdGF0dXNfc2hvd19wcmljZV90YXgiO3M6MToiMSI7czozMToiY3VzdG9tZXJzX3N0YXR1c19zaG93X3RheF90b3RhbCI7czozOiIxNTAiO3M6Mjc6ImN1c3RvbWVyc19zdGF0dXNfYWRkX3RheF9vdCI7czoxOiIwIjtzOjM0OiJjdXN0b21lcnNfc3RhdHVzX3BheW1lbnRfdW5hbGxvd2VkIjtzOjA6IiI7czozNToiY3VzdG9tZXJzX3N0YXR1c19zaGlwcGluZ191bmFsbG93ZWQiO3M6MDoiIjtzOjM2OiJjdXN0b21lcnNfc3RhdHVzX2Rpc2NvdW50X2F0dHJpYnV0ZXMiO3M6MToiMCI7czoxNToiY3VzdG9tZXJzX2ZzazE4IjtzOjE6IjEiO3M6MjM6ImN1c3RvbWVyc19mc2sxOF9kaXNwbGF5IjtzOjE6IjEiO3M6MzA6ImN1c3RvbWVyc19zdGF0dXNfd3JpdGVfcmV2aWV3cyI7czoxOiIwIjtzOjI5OiJjdXN0b21lcnNfc3RhdHVzX3JlYWRfcmV2aWV3cyI7czoxOiIxIjtzOjMxOiJjdXN0b21lcnNfc3RhdHVzX3Jldmlld3Nfc3RhdHVzIjtzOjE6IjAiO3M6MjU6ImN1c3RvbWVyc19zdGF0dXNfc3BlY2lhbHMiO3M6MToiMSI7czoxNjoiY3VzdG9tZXJzX3N0YXR1cyI7czoxOiIxIjt9Y2FydHxPOjEyOiJzaG9wcGluZ0NhcnQiOjExOntzOjg6ImNvbnRlbnRzIjthOjA6e31zOjU6InRvdGFsIjtpOjA7czo2OiJ3ZWlnaHQiO2k6MDtzOjEyOiJjb250ZW50X3R5cGUiO2I6MDtzOjEwOiJhdHRyX3ByaWNlIjtpOjA7czoxMToiYXR0cl93ZWlnaHQiO2k6MDtzOjQ6InR5cGUiO3M6NDoiY2FydCI7czoxMjoidGFibGVfYmFza2V0IjtzOjE2OiJjdXN0b21lcnNfYmFza2V0IjtzOjIzOiJ0YWJsZV9iYXNrZXRfYXR0cmlidXRlcyI7czoyNzoiY3VzdG9tZXJzX2Jhc2tldF9hdHRyaWJ1dGVzIjtzOjE5OiJzaG9wcGluZ0NhcnRNb2R1bGVzIjtPOjE5OiJzaG9wcGluZ0NhcnRNb2R1bGVzIjowOnt9czozOiJ0YXgiO2k6MDt9YWNjb3VudF90eXBlfHM6MToiMCI7YWN0dWFsX2NvbnRlbnR8YToxOntpOjA7YToxOntzOjM6InF0eSI7aTowO319','');
/*!40000 ALTER TABLE `sessions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `shipping_status`
--

DROP TABLE IF EXISTS `shipping_status`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `shipping_status` (
  `shipping_status_id` int(11) NOT NULL DEFAULT '0',
  `language_id` int(11) NOT NULL,
  `shipping_status_name` varchar(32) COLLATE latin1_german1_ci NOT NULL,
  `shipping_status_image` varchar(32) COLLATE latin1_german1_ci NOT NULL,
  `sort_order` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`shipping_status_id`,`language_id`),
  KEY `idx_shipping_status_name` (`shipping_status_name`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_german1_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `shipping_status`
--

LOCK TABLES `shipping_status` WRITE;
/*!40000 ALTER TABLE `shipping_status` DISABLE KEYS */;
INSERT INTO `shipping_status` VALUES (1,1,'3-4 Days','',1),(1,2,'3-4 Tage','',1),(2,1,'1 Week','',2),(2,2,'1 Woche','',2),(3,1,'2 Weeks','',3),(3,2,'2 Wochen','',3);
/*!40000 ALTER TABLE `shipping_status` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `shop_configuration`
--

DROP TABLE IF EXISTS `shop_configuration`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `shop_configuration` (
  `configuration_id` int(11) NOT NULL AUTO_INCREMENT,
  `configuration_key` varchar(255) COLLATE latin1_german1_ci NOT NULL DEFAULT '',
  `configuration_value` text COLLATE latin1_german1_ci NOT NULL,
  PRIMARY KEY (`configuration_id`),
  KEY `idx_configuration_key` (`configuration_key`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=latin1 COLLATE=latin1_german1_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `shop_configuration`
--

LOCK TABLES `shop_configuration` WRITE;
/*!40000 ALTER TABLE `shop_configuration` DISABLE KEYS */;
INSERT INTO `shop_configuration` VALUES (1,'SHOP_OFFLINE',''),(2,'SHOP_OFFLINE_MSG','<p style=\"text-align: center;\"><span style=\"font-size: large;\"><font face=\"Arial\">Unser Shop ist aufgrund von Wartungsarbeiten im Moment nicht erreichbar.<br /></font><font face=\"Arial\">Bitte besuchen Sie uns zu einem sp&auml;teren Zeitpunkt noch einmal.<br /><br /><br /><br /></font></span><font><font><a href=\"login_admin.php\"><font color=\"#808080\">Login</font></a></font></font><span style=\"font-size: large;\"><font face=\"Arial\"><br /></font></span></p>');
/*!40000 ALTER TABLE `shop_configuration` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `specials`
--

DROP TABLE IF EXISTS `specials`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `specials` (
  `specials_id` int(11) NOT NULL AUTO_INCREMENT,
  `products_id` int(11) NOT NULL,
  `specials_quantity` int(4) NOT NULL,
  `specials_new_products_price` decimal(15,4) NOT NULL,
  `specials_date_added` datetime DEFAULT NULL,
  `specials_last_modified` datetime DEFAULT NULL,
  `start_date` datetime DEFAULT NULL,
  `expires_date` datetime DEFAULT NULL,
  `date_status_change` datetime DEFAULT NULL,
  `status` int(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`specials_id`),
  KEY `idx_products_id` (`products_id`),
  KEY `idx_status` (`status`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_german1_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `specials`
--

LOCK TABLES `specials` WRITE;
/*!40000 ALTER TABLE `specials` DISABLE KEYS */;
/*!40000 ALTER TABLE `specials` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tax_class`
--

DROP TABLE IF EXISTS `tax_class`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tax_class` (
  `tax_class_id` int(11) NOT NULL AUTO_INCREMENT,
  `tax_class_title` varchar(32) COLLATE latin1_german1_ci NOT NULL,
  `tax_class_description` varchar(255) COLLATE latin1_german1_ci NOT NULL,
  `last_modified` datetime DEFAULT NULL,
  `date_added` datetime NOT NULL,
  PRIMARY KEY (`tax_class_id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=latin1 COLLATE=latin1_german1_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tax_class`
--

LOCK TABLES `tax_class` WRITE;
/*!40000 ALTER TABLE `tax_class` DISABLE KEYS */;
INSERT INTO `tax_class` VALUES (1,'Standardsatz','',NULL,'2019-02-05 19:45:22'),(2,'ermäßigter Steuersatz','',NULL,'2019-02-05 19:45:22');
/*!40000 ALTER TABLE `tax_class` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tax_rates`
--

DROP TABLE IF EXISTS `tax_rates`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tax_rates` (
  `tax_rates_id` int(11) NOT NULL AUTO_INCREMENT,
  `tax_zone_id` int(11) NOT NULL,
  `tax_class_id` int(11) NOT NULL,
  `tax_priority` int(5) DEFAULT '1',
  `tax_rate` decimal(7,4) NOT NULL,
  `tax_description` varchar(255) COLLATE latin1_german1_ci NOT NULL,
  `last_modified` datetime DEFAULT NULL,
  `date_added` datetime NOT NULL,
  PRIMARY KEY (`tax_rates_id`),
  KEY `idx_tax_zone_id` (`tax_zone_id`),
  KEY `idx_tax_class_id` (`tax_class_id`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=latin1 COLLATE=latin1_german1_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tax_rates`
--

LOCK TABLES `tax_rates` WRITE;
/*!40000 ALTER TABLE `tax_rates` DISABLE KEYS */;
INSERT INTO `tax_rates` VALUES (3,6,1,1,0.0000,'EU-AUS-UST 0%',NULL,'2019-02-05 19:45:22'),(4,6,2,1,0.0000,'EU-AUS-UST 0%',NULL,'2019-02-05 19:45:22'),(1,5,1,1,19.0000,'MwSt. 19%',NULL,'2019-02-05 19:45:22'),(2,5,2,1,7.0000,'MwSt. 7%',NULL,'2019-02-05 19:45:22');
/*!40000 ALTER TABLE `tax_rates` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `whos_online`
--

DROP TABLE IF EXISTS `whos_online`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `whos_online` (
  `customer_id` int(11) DEFAULT NULL,
  `full_name` varchar(64) COLLATE latin1_german1_ci NOT NULL,
  `session_id` varchar(32) COLLATE latin1_german1_ci NOT NULL,
  `ip_address` varchar(50) COLLATE latin1_german1_ci NOT NULL,
  `time_entry` varchar(14) COLLATE latin1_german1_ci NOT NULL,
  `time_last_click` varchar(14) COLLATE latin1_german1_ci NOT NULL,
  `last_page_url` varchar(255) COLLATE latin1_german1_ci NOT NULL,
  `http_referer` varchar(255) COLLATE latin1_german1_ci NOT NULL,
  PRIMARY KEY (`session_id`),
  KEY `idx_time_last_click` (`time_last_click`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_german1_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `whos_online`
--

LOCK TABLES `whos_online` WRITE;
/*!40000 ALTER TABLE `whos_online` DISABLE KEYS */;
INSERT INTO `whos_online` VALUES (0,' Gast','1hnd373av7t42gapapkh9es7m4','','1549706851','1549706873','/favicon.ico','---'),(0,' Gast','ujhjj4sq306un9l68hrmkc77ns','','1549707463','1549707463','/favicon.ico','---'),(0,' Gast','42uoq0o3et4lgtqqadp6tonco1','','1549707463','1549707463','/favicon.ico','---');
/*!40000 ALTER TABLE `whos_online` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `zones`
--

DROP TABLE IF EXISTS `zones`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `zones` (
  `zone_id` int(11) NOT NULL AUTO_INCREMENT,
  `zone_country_id` int(11) NOT NULL,
  `zone_code` varchar(32) COLLATE latin1_german1_ci NOT NULL,
  `zone_name` varchar(64) COLLATE latin1_german1_ci NOT NULL,
  PRIMARY KEY (`zone_id`),
  UNIQUE KEY `idx_country_code` (`zone_country_id`,`zone_code`),
  KEY `idx_zone_country_id` (`zone_country_id`)
) ENGINE=MyISAM AUTO_INCREMENT=1066 DEFAULT CHARSET=latin1 COLLATE=latin1_german1_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `zones`
--

LOCK TABLES `zones` WRITE;
/*!40000 ALTER TABLE `zones` DISABLE KEYS */;
INSERT INTO `zones` VALUES (1,223,'AL','Alabama'),(2,223,'AK','Alaska'),(3,223,'AS','American Samoa'),(4,223,'AZ','Arizona'),(5,223,'AR','Arkansas'),(6,223,'AF','Armed Forces Africa'),(7,223,'AA','Armed Forces Americas'),(8,223,'AC','Armed Forces Canada'),(9,223,'AE','Armed Forces Europe'),(10,223,'AM','Armed Forces Middle East'),(11,223,'AP','Armed Forces Pacific'),(12,223,'CA','California'),(13,223,'CO','Colorado'),(14,223,'CT','Connecticut'),(15,223,'DE','Delaware'),(16,223,'DC','District of Columbia'),(17,223,'FM','Federated States Of Micronesia'),(18,223,'FL','Florida'),(19,223,'GA','Georgia'),(20,223,'GU','Guam'),(21,223,'HI','Hawaii'),(22,223,'ID','Idaho'),(23,223,'IL','Illinois'),(24,223,'IN','Indiana'),(25,223,'IA','Iowa'),(26,223,'KS','Kansas'),(27,223,'KY','Kentucky'),(28,223,'LA','Louisiana'),(29,223,'ME','Maine'),(30,223,'MH','Marshall Islands'),(31,223,'MD','Maryland'),(32,223,'MA','Massachusetts'),(33,223,'MI','Michigan'),(34,223,'MN','Minnesota'),(35,223,'MS','Mississippi'),(36,223,'MO','Missouri'),(37,223,'MT','Montana'),(38,223,'NE','Nebraska'),(39,223,'NV','Nevada'),(40,223,'NH','New Hampshire'),(41,223,'NJ','New Jersey'),(42,223,'NM','New Mexico'),(43,223,'NY','New York'),(44,223,'NC','North Carolina'),(45,223,'ND','North Dakota'),(46,223,'MP','Northern Mariana Islands'),(47,223,'OH','Ohio'),(48,223,'OK','Oklahoma'),(49,223,'OR','Oregon'),(50,223,'PW','Palau'),(51,223,'PA','Pennsylvania'),(52,223,'PR','Puerto Rico'),(53,223,'RI','Rhode Island'),(54,223,'SC','South Carolina'),(55,223,'SD','South Dakota'),(56,223,'TN','Tennessee'),(57,223,'TX','Texas'),(58,223,'UT','Utah'),(59,223,'VT','Vermont'),(60,223,'VI','Virgin Islands'),(61,223,'VA','Virginia'),(62,223,'WA','Washington'),(63,223,'WV','West Virginia'),(64,223,'WI','Wisconsin'),(65,223,'WY','Wyoming'),(66,38,'AB','Alberta'),(67,38,'BC','British Columbia'),(68,38,'MB','Manitoba'),(69,38,'NF','Newfoundland'),(70,38,'NB','New Brunswick'),(71,38,'NS','Nova Scotia'),(72,38,'NT','Northwest Territories'),(73,38,'NU','Nunavut'),(74,38,'ON','Ontario'),(75,38,'PE','Prince Edward Island'),(76,38,'QC','Quebec'),(77,38,'SK','Saskatchewan'),(78,38,'YT','Yukon Territory'),(79,81,'NI','Niedersachsen'),(80,81,'BW','Baden-Württemberg'),(81,81,'BY','Bayern'),(82,81,'BE','Berlin'),(83,81,'BR','Brandenburg'),(84,81,'HB','Bremen'),(85,81,'HH','Hamburg'),(86,81,'HE','Hessen'),(87,81,'MV','Mecklenburg-Vorpommern'),(88,81,'NW','Nordrhein-Westfalen'),(89,81,'RP','Rheinland-Pfalz'),(90,81,'SL','Saarland'),(91,81,'SN','Sachsen'),(92,81,'ST','Sachsen-Anhalt'),(93,81,'SH','Schleswig-Holstein'),(94,81,'TH','Thüringen'),(95,14,'WI','Wien'),(96,14,'NO','Niederösterreich'),(97,14,'OO','Oberösterreich'),(98,14,'SB','Salzburg'),(99,14,'KN','Kärnten'),(100,14,'ST','Steiermark'),(101,14,'TI','Tirol'),(102,14,'BL','Burgenland'),(103,14,'VB','Voralberg'),(104,204,'AG','Aargau'),(105,204,'AI','Appenzell Innerrhoden'),(106,204,'AR','Appenzell Ausserrhoden'),(107,204,'BE','Bern'),(108,204,'BL','Basel-Landschaft'),(109,204,'BS','Basel-Stadt'),(110,204,'FR','Freiburg'),(111,204,'GE','Genf'),(112,204,'GL','Glarus'),(113,204,'GR','Graubünden'),(114,204,'JU','Jura'),(115,204,'LU','Luzern'),(116,204,'NE','Neuenburg'),(117,204,'NW','Nidwalden'),(118,204,'OW','Obwalden'),(119,204,'SG','St. Gallen'),(120,204,'SH','Schaffhausen'),(121,204,'SO','Solothurn'),(122,204,'SZ','Schwyz'),(123,204,'TG','Thurgau'),(124,204,'TI','Tessin'),(125,204,'UR','Uri'),(126,204,'VD','Waadt'),(127,204,'VS','Wallis'),(128,204,'ZG','Zug'),(129,204,'ZH','Zürich'),(130,195,'ES-C','A Coruña'),(131,195,'ES-VI','Álava'),(132,195,'ES-AB','Albacete'),(133,195,'ES-A','Alicante'),(134,195,'ES-AL','Almería'),(135,195,'ES-O','Asturias'),(136,195,'ES-AV','Ávila'),(137,195,'ES-BA','Badajoz'),(138,195,'ES-PM','Balears'),(139,195,'ES-B','Barcelona'),(140,195,'ES-BU','Burgos'),(141,195,'ES-CC','Cáceres'),(142,195,'ES-CA','Cádiz'),(143,195,'ES-S','Cantabria'),(144,195,'ES-CS','Castellón'),(145,195,'ES-CE','Ceuta'),(146,195,'ES-CR','Ciudad Real'),(147,195,'ES-CO','Córdoba'),(148,195,'ES-CU','Cuenca'),(149,195,'ES-GI','Girona'),(150,195,'ES-GR','Granada'),(151,195,'ES-GU','Guadalajara'),(152,195,'ES-SS','Guipúzcoa'),(153,195,'ES-H','Huelva'),(154,195,'ES-HU','Huesca'),(155,195,'ES-J','Jaén'),(156,195,'ES-LO','La Rioja'),(157,195,'ES-GC','Las Palmas'),(158,195,'ES-LE','León'),(159,195,'ES-L','Lleida'),(160,195,'ES-LU','Lugo'),(161,195,'ES-M','Madrid'),(162,195,'ES-MA','Malaga'),(163,195,'ES-ML','Melilla'),(164,195,'ES-MU','Murcia'),(165,195,'ES-NA','Navarra'),(166,195,'ES-OR','Ourense'),(167,195,'ES-P','Palencia'),(168,195,'ES-PO','Pontevedra'),(169,195,'ES-SA','Salamanca'),(170,195,'ES-TF','Santa Cruz de Tenerife'),(171,195,'ES-SG','Segovia'),(172,195,'ES-SE','Sevilla'),(173,195,'ES-SO','Soria'),(174,195,'ES-T','Tarragona'),(175,195,'ES-TE','Teruel'),(176,195,'ES-TO','Toledo'),(177,195,'ES-V','Valencia'),(178,195,'ES-VA','Valladolid'),(179,195,'ES-BI','Vizcaya'),(180,195,'ES-ZA','Zamora'),(181,195,'ES-Z','Zaragoza'),(182,13,'NSW','New South Wales'),(183,13,'VIC','Victoria'),(184,13,'QLD','Queensland'),(185,13,'NT','Northern Territory'),(186,13,'WA','Western Australia'),(187,13,'SA','South Australia'),(188,13,'TAS','Tasmania'),(189,13,'ACT','Australian Capital Territory'),(190,153,'Northland','Northland'),(191,153,'Auckland','Auckland'),(192,153,'Waikato','Waikato'),(193,153,'Bay of Plenty','Bay of Plenty'),(194,153,'Gisborne','Gisborne'),(195,153,'Hawkes Bay','Hawkes Bay'),(196,153,'Taranaki','Taranaki'),(197,153,'Manawatu-Wanganui','Manawatu-Wanganui'),(198,153,'Wellington','Wellington'),(199,153,'West Coast','West Coast'),(200,153,'Canterbury','Canterbury'),(201,153,'Otago','Otago'),(202,153,'Southland','Southland'),(203,153,'Tasman','Tasman'),(204,153,'Nelson','Nelson'),(205,153,'Marlborough','Marlborough'),(206,30,'SP','São Paulo'),(207,30,'RJ','Rio de Janeiro'),(208,30,'PE','Pernanbuco'),(209,30,'BA','Bahia'),(210,30,'AM','Amazonas'),(211,30,'MG','Minas Gerais'),(212,30,'ES','Espirito Santo'),(213,30,'RS','Rio Grande do Sul'),(214,30,'PR','Paraná'),(215,30,'SC','Santa Catarina'),(216,30,'RG','Rio Grande do Norte'),(217,30,'MS','Mato Grosso do Sul'),(218,30,'MT','Mato Grosso'),(219,30,'GO','Goias'),(220,30,'TO','Tocantins'),(221,30,'DF','Distrito Federal'),(222,30,'RO','Rondonia'),(223,30,'AC','Acre'),(224,30,'AP','Amapa'),(225,30,'RR','Roraima'),(226,30,'AL','Alagoas'),(227,30,'CE','Ceará'),(228,30,'MA','Maranhão'),(229,30,'PA','Pará'),(230,30,'PB','Paraíba'),(231,30,'PI','Piauí'),(232,30,'SE','Sergipe'),(233,43,'I','I Región de Tarapacá'),(234,43,'II','II Región de Antofagasta'),(235,43,'III','III Región de Atacama'),(236,43,'IV','IV Región de Coquimbo'),(237,43,'V','V Región de Valaparaíso'),(238,43,'RM','Región Metropolitana'),(239,43,'VI','VI Región de L. B. O´higgins'),(240,43,'VII','VII Región del Maule'),(241,43,'VIII','VIII Región del Bío Bío'),(242,43,'IX','IX Región de la Araucanía'),(243,43,'X','X Región de los Lagos'),(244,43,'XI','XI Región de Aysén'),(245,43,'XII','XII Región de Magallanes'),(246,47,'AMA','Amazonas'),(247,47,'ANT','Antioquia'),(248,47,'ARA','Arauca'),(249,47,'ATL','Atlantico'),(250,47,'BOL','Bolivar'),(251,47,'BOY','Boyaca'),(252,47,'CAL','Caldas'),(253,47,'CAQ','Caqueta'),(254,47,'CAS','Casanare'),(255,47,'CAU','Cauca'),(256,47,'CES','Cesar'),(257,47,'CHO','Choco'),(258,47,'COR','Cordoba'),(259,47,'CUN','Cundinamarca'),(260,47,'HUI','Huila'),(261,47,'GUA','Guainia'),(262,47,'LAG','Guajira'),(263,47,'GUV','Guaviare'),(264,47,'MAG','Magdalena'),(265,47,'MET','Meta'),(266,47,'NAR','Narino'),(267,47,'NDS','Norte de Santander'),(268,47,'PUT','Putumayo'),(269,47,'QUI','Quindio'),(270,47,'RIS','Risaralda'),(271,47,'SAI','San Andres Islas'),(272,47,'SAN','Santander'),(273,47,'SUC','Sucre'),(274,47,'TOL','Tolima'),(275,47,'VAL','Valle'),(276,47,'VAU','Vaupes'),(277,47,'VIC','Vichada'),(278,73,'Et','Etranger'),(279,73,'01','Ain'),(280,73,'02','Aisne'),(281,73,'03','Allier'),(282,73,'04','Alpes de Haute Provence'),(283,73,'05','Hautes-Alpes'),(284,73,'06','Alpes Maritimes'),(285,73,'07','Ardèche'),(286,73,'08','Ardennes'),(287,73,'09','Ariège'),(288,73,'10','Aube'),(289,73,'11','Aude'),(290,73,'12','Aveyron'),(291,73,'13','Bouches-du-Rhône'),(292,73,'14','Calvados'),(293,73,'15','Cantal'),(294,73,'16','Charente'),(295,73,'17','Charente Maritime'),(296,73,'18','Cher'),(297,73,'19','Corrèze'),(298,73,'2A','Corse du Sud'),(299,73,'2B','Haute Corse'),(300,73,'21','Côte-d\'Or'),(301,73,'22','Côtes-d\'Armor'),(302,73,'23','Creuse'),(303,73,'24','Dordogne'),(304,73,'25','Doubs'),(305,73,'26','Drôme'),(306,73,'27','Eure'),(307,73,'28','Eure et Loir'),(308,73,'29','Finistère'),(309,73,'30','Gard'),(310,73,'31','Haute Garonne'),(311,73,'32','Gers'),(312,73,'33','Gironde'),(313,73,'34','Hérault'),(314,73,'35','Ille et Vilaine'),(315,73,'36','Indre'),(316,73,'37','Indre et Loire'),(317,73,'38','Isère'),(318,73,'39','Jura'),(319,73,'40','Landes'),(320,73,'41','Loir et Cher'),(321,73,'42','Loire'),(322,73,'43','Haute Loire'),(323,73,'44','Loire Atlantique'),(324,73,'45','Loiret'),(325,73,'46','Lot'),(326,73,'47','Lot et Garonne'),(327,73,'48','Lozère'),(328,73,'49','Maine et Loire'),(329,73,'50','Manche'),(330,73,'51','Marne'),(331,73,'52','Haute Marne'),(332,73,'53','Mayenne'),(333,73,'54','Meurthe et Moselle'),(334,73,'55','Meuse'),(335,73,'56','Morbihan'),(336,73,'57','Moselle'),(337,73,'58','Nièvre'),(338,73,'59','Nord'),(339,73,'60','Oise'),(340,73,'61','Orne'),(341,73,'62','Pas de Calais'),(342,73,'63','Puy-de-Dôme'),(343,73,'64','Pyrénées-Atlantiques'),(344,73,'65','Hautes-Pyrénées'),(345,73,'66','Pyrénées-Orientales'),(346,73,'67','Bas Rhin'),(347,73,'68','Haut Rhin'),(348,73,'69','Rhône'),(349,73,'70','Haute-Saône'),(350,73,'71','Saône-et-Loire'),(351,73,'72','Sarthe'),(352,73,'73','Savoie'),(353,73,'74','Haute Savoie'),(354,73,'75','Paris'),(355,73,'76','Seine Maritime'),(356,73,'77','Seine et Marne'),(357,73,'78','Yvelines'),(358,73,'79','Deux-Sèvres'),(359,73,'80','Somme'),(360,73,'81','Tarn'),(361,73,'82','Tarn et Garonne'),(362,73,'83','Var'),(363,73,'84','Vaucluse'),(364,73,'85','Vendée'),(365,73,'86','Vienne'),(366,73,'87','Haute Vienne'),(367,73,'88','Vosges'),(368,73,'89','Yonne'),(369,73,'90','Territoire de Belfort'),(370,73,'91','Essonne'),(371,73,'92','Hauts de Seine'),(372,73,'93','Seine St-Denis'),(373,73,'94','Val de Marne'),(374,73,'95','Val d\'Oise'),(375,73,'971 (DOM)','Guadeloupe'),(376,73,'972 (DOM)','Martinique'),(377,73,'973 (DOM)','Guyane'),(378,73,'974 (DOM)','Saint Denis'),(379,73,'975 (DOM)','St-Pierre de Miquelon'),(380,73,'976 (TOM)','Mayotte'),(381,73,'984 (TOM)','Terres australes et Antartiques françaises'),(382,73,'985 (TOM)','Nouvelle Calédonie'),(383,73,'986 (TOM)','Wallis et Futuna'),(384,73,'987 (TOM)','Polynésie française'),(385,99,'DL','Delhi'),(386,99,'MH','Maharashtra'),(387,99,'TN','Tamil Nadu'),(388,99,'KL','Kerala'),(389,99,'AP','Andhra Pradesh'),(390,99,'KA','Karnataka'),(391,99,'GA','Goa'),(392,99,'MP','Madhya Pradesh'),(393,99,'PY','Pondicherry'),(394,99,'GJ','Gujarat'),(395,99,'OR','Orrisa'),(396,99,'CA','Chhatisgarh'),(397,99,'JH','Jharkhand'),(398,99,'BR','Bihar'),(399,99,'WB','West Bengal'),(400,99,'UP','Uttar Pradesh'),(401,99,'RJ','Rajasthan'),(402,99,'PB','Punjab'),(403,99,'HR','Haryana'),(404,99,'CH','Chandigarh'),(405,99,'JK','Jammu & Kashmir'),(406,99,'HP','Himachal Pradesh'),(407,99,'UA','Uttaranchal'),(408,99,'LK','Lakshadweep'),(409,99,'AN','Andaman & Nicobar'),(410,99,'MG','Meghalaya'),(411,99,'AS','Assam'),(412,99,'DR','Dadra & Nagar Haveli'),(413,99,'DN','Daman & Diu'),(414,99,'SK','Sikkim'),(415,99,'TR','Tripura'),(416,99,'MZ','Mizoram'),(417,99,'MN','Manipur'),(418,99,'NL','Nagaland'),(419,99,'AR','Arunachal Pradesh'),(420,105,'AG','Agrigento'),(421,105,'AL','Alessandria'),(422,105,'AN','Ancona'),(423,105,'AO','Aosta'),(424,105,'AR','Arezzo'),(425,105,'AP','Ascoli Piceno'),(426,105,'AT','Asti'),(427,105,'AV','Avellino'),(428,105,'BA','Bari'),(429,105,'BT','Barletta-Andria-Trani'),(430,105,'BL','Belluno'),(431,105,'BN','Benevento'),(432,105,'BG','Bergamo'),(433,105,'BI','Biella'),(434,105,'BO','Bologna'),(435,105,'BZ','Bolzano'),(436,105,'BS','Brescia'),(437,105,'BR','Brindisi'),(438,105,'CA','Cagliari'),(439,105,'CL','Caltanissetta'),(440,105,'CB','Campobasso'),(441,105,'CI','Carbonia-Iglesias'),(442,105,'CE','Caserta'),(443,105,'CT','Catania'),(444,105,'CZ','Catanzaro'),(445,105,'CH','Chieti'),(446,105,'CO','Como'),(447,105,'CS','Cosenza'),(448,105,'CR','Cremona'),(449,105,'KR','Crotone'),(450,105,'CN','Cuneo'),(451,105,'EN','Enna'),(452,105,'FM','Fermo'),(453,105,'FE','Ferrara'),(454,105,'FI','Firenze'),(455,105,'FG','Foggia'),(456,105,'FC','Forlì-Cesena'),(457,105,'FR','Frosinone'),(458,105,'GE','Genova'),(459,105,'GO','Gorizia'),(460,105,'GR','Grosseto'),(461,105,'IM','Imperia'),(462,105,'IS','Isernia'),(463,105,'SP','La Spezia'),(464,105,'AQ','Aquila'),(465,105,'LT','Latina'),(466,105,'LE','Lecce'),(467,105,'LC','Lecco'),(468,105,'LI','Livorno'),(469,105,'LO','Lodi'),(470,105,'LU','Lucca'),(471,105,'MC','Macerata'),(472,105,'MN','Mantova'),(473,105,'MS','Massa-Carrara'),(474,105,'MT','Matera'),(475,105,'ME','Messina'),(476,105,'MI','Milano'),(477,105,'MO','Modena'),(478,105,'MB','Monza e della Brianza'),(479,105,'NA','Napoli'),(480,105,'NO','Novara'),(481,105,'NU','Nuoro'),(482,105,'OT','Olbia-Tempio'),(483,105,'OR','Oristano'),(484,105,'PD','Padova'),(485,105,'PA','Palermo'),(486,105,'PR','Parma'),(487,105,'PV','Pavia'),(488,105,'PG','Perugia'),(489,105,'PU','Pesaro e Urbino'),(490,105,'PE','Pescara'),(491,105,'PC','Piacenza'),(492,105,'PI','Pisa'),(493,105,'PT','Pistoia'),(494,105,'PN','Pordenone'),(495,105,'PZ','Potenza'),(496,105,'PO','Prato'),(497,105,'RG','Ragusa'),(498,105,'RA','Ravenna'),(499,105,'RC','Reggio di Calabria'),(500,105,'RE','Reggio Emilia'),(501,105,'RI','Rieti'),(502,105,'RN','Rimini'),(503,105,'RM','Roma'),(504,105,'RO','Rovigo'),(505,105,'SA','Salerno'),(506,105,'VS','Medio Campidano'),(507,105,'SS','Sassari'),(508,105,'SV','Savona'),(509,105,'SI','Siena'),(510,105,'SR','Siracusa'),(511,105,'SO','Sondrio'),(512,105,'TA','Taranto'),(513,105,'TE','Teramo'),(514,105,'TR','Terni'),(515,105,'TO','Torino'),(516,105,'OG','Ogliastra'),(517,105,'TP','Trapani'),(518,105,'TN','Trento'),(519,105,'TV','Treviso'),(520,105,'TS','Trieste'),(521,105,'UD','Udine'),(522,105,'VA','Varese'),(523,105,'VE','Venezia'),(524,105,'VB','Verbania'),(525,105,'VC','Vercelli'),(526,105,'VR','Verona'),(527,105,'VV','Vibo Valentia'),(528,105,'VI','Vicenza'),(529,105,'VT','Viterbo'),(530,107,'Niigata','Niigata'),(531,107,'Toyama','Toyama'),(532,107,'Ishikawa','Ishikawa'),(533,107,'Fukui','Fukui'),(534,107,'Yamanashi','Yamanashi'),(535,107,'Nagano','Nagano'),(536,107,'Gifu','Gifu'),(537,107,'Shizuoka','Shizuoka'),(538,107,'Aichi','Aichi'),(539,107,'Mie','Mie'),(540,107,'Shiga','Shiga'),(541,107,'Kyoto','Kyoto'),(542,107,'Osaka','Osaka'),(543,107,'Hyogo','Hyogo'),(544,107,'Nara','Nara'),(545,107,'Wakayama','Wakayama'),(546,107,'Tottori','Tottori'),(547,107,'Shimane','Shimane'),(548,107,'Okayama','Okayama'),(549,107,'Hiroshima','Hiroshima'),(550,107,'Yamaguchi','Yamaguchi'),(551,107,'Tokushima','Tokushima'),(552,107,'Kagawa','Kagawa'),(553,107,'Ehime','Ehime'),(554,107,'Kochi','Kochi'),(555,107,'Fukuoka','Fukuoka'),(556,107,'Saga','Saga'),(557,107,'Nagasaki','Nagasaki'),(558,107,'Kumamoto','Kumamoto'),(559,107,'Oita','Oita'),(560,107,'Miyazaki','Miyazaki'),(561,107,'Kagoshima','Kagoshima'),(562,129,'JOH','Johor'),(563,129,'KDH','Kedah'),(564,129,'KEL','Kelantan'),(565,129,'KL','Kuala Lumpur'),(566,129,'MEL','Melaka'),(567,129,'NS','Negeri Sembilan'),(568,129,'PAH','Pahang'),(569,129,'PRK','Perak'),(570,129,'PER','Perlis'),(571,129,'PP','Pulau Pinang'),(572,129,'SAB','Sabah'),(573,129,'SWK','Sarawak'),(574,129,'SEL','Selangor'),(575,129,'TER','Terengganu'),(576,129,'LAB','W.P.Labuan'),(577,138,'AGS','Aguascalientes'),(578,138,'BC','Baja California'),(579,138,'BCS','Baja California Sur'),(580,138,'CAM','Campeche'),(581,138,'COA','Coahuila'),(582,138,'COL','Colima'),(583,138,'CHI','Chiapas'),(584,138,'CHIH','Chihuahua'),(585,138,'DF','Distrito Federal'),(586,138,'DGO','Durango'),(587,138,'MEX','Estado de Mexico'),(588,138,'GTO','Guanajuato'),(589,138,'GRO','Guerrero'),(590,138,'HGO','Hidalgo'),(591,138,'JAL','Jalisco'),(592,138,'MCH','Michoacan'),(593,138,'MOR','Morelos'),(594,138,'NAY','Nayarit'),(595,138,'NL','Nuevo Leon'),(596,138,'OAX','Oaxaca'),(597,138,'PUE','Puebla'),(598,138,'QRO','Queretaro'),(599,138,'QR','Quintana Roo'),(600,138,'SLP','San Luis Potosi'),(601,138,'SIN','Sinaloa'),(602,138,'SON','Sonora'),(603,138,'TAB','Tabasco'),(604,138,'TMPS','Tamaulipas'),(605,138,'TLAX','Tlaxcala'),(606,138,'VER','Veracruz'),(607,138,'YUC','Yucatan'),(608,138,'ZAC','Zacatecas'),(609,160,'OSL','Oslo'),(610,160,'AKE','Akershus'),(611,160,'AUA','Aust-Agder'),(612,160,'BUS','Buskerud'),(613,160,'FIN','Finnmark'),(614,160,'HED','Hedmark'),(615,160,'HOR','Hordaland'),(616,160,'MOR','Møre og Romsdal'),(617,160,'NOR','Nordland'),(618,160,'NTR','Nord-Trøndelag'),(619,160,'OPP','Oppland'),(620,160,'ROG','Rogaland'),(621,160,'SOF','Sogn og Fjordane'),(622,160,'STR','Sør-Trøndelag'),(623,160,'TEL','Telemark'),(624,160,'TRO','Troms'),(625,160,'VEA','Vest-Agder'),(626,160,'OST','Østfold'),(627,160,'SVA','Svalbard'),(628,162,'KHI','Karachi'),(629,162,'LH','Lahore'),(630,162,'ISB','Islamabad'),(631,162,'QUE','Quetta'),(632,162,'PSH','Peshawar'),(633,162,'GUJ','Gujrat'),(634,162,'SAH','Sahiwal'),(635,162,'FSB','Faisalabad'),(636,162,'RIP','Rawal Pindi'),(637,175,'AB','Alba'),(638,175,'AR','Arad'),(639,175,'AG','Arges'),(640,175,'BC','Bacau'),(641,175,'BH','Bihor'),(642,175,'BN','Bistrita-Nasaud'),(643,175,'BT','Botosani'),(644,175,'BV','Brasov'),(645,175,'BR','Braila'),(646,175,'B','Bucuresti'),(647,175,'BZ','Buzau'),(648,175,'CS','Caras-Severin'),(649,175,'CL','Calarasi'),(650,175,'CJ','Cluj'),(651,175,'CT','Constanta'),(652,175,'CV','Covasna'),(653,175,'DB','Dimbovita'),(654,175,'DJ','Dolj'),(655,175,'GL','Galati'),(656,175,'GR','Giurgiu'),(657,175,'GJ','Gorj'),(658,175,'HR','Harghita'),(659,175,'HD','Hunedoara'),(660,175,'IL','Ialomita'),(661,175,'IS','Iasi'),(662,175,'IF','Ilfov'),(663,175,'MM','Maramures'),(664,175,'MH','Mehedint'),(665,175,'MS','Mures'),(666,175,'NT','Neamt'),(667,175,'OT','Olt'),(668,175,'PH','Prahova'),(669,175,'SM','Satu-Mare'),(670,175,'SJ','Salaj'),(671,175,'SB','Sibiu'),(672,175,'SV','Suceava'),(673,175,'TR','Teleorman'),(674,175,'TM','Timis'),(675,175,'TL','Tulcea'),(676,175,'VS','Vaslui'),(677,175,'VL','Valcea'),(678,175,'VN','Vrancea'),(679,193,'WP','Western Cape'),(680,193,'GP','Gauteng'),(681,193,'KZN','Kwazulu-Natal'),(682,193,'NC','Northern-Cape'),(683,193,'EC','Eastern-Cape'),(684,193,'MP','Mpumalanga'),(685,193,'NW','North-West'),(686,193,'FS','Free State'),(687,193,'NP','Northern Province'),(688,203,'K','Blekinge'),(689,203,'W','Dalarna'),(690,203,'I','Gotland'),(691,203,'X','Gävleborg'),(692,203,'N','Halland'),(693,203,'Z','Jämtland'),(694,203,'F','Jönköping'),(695,203,'H','Kalmar'),(696,203,'G','Kronoberg'),(697,203,'BD','Norrbotten'),(698,203,'T','Örebro'),(699,203,'E','Östergötland'),(700,203,'M','Skåne'),(701,203,'AB','Stockholm'),(702,203,'D','Södermanland'),(703,203,'C','Uppsala'),(704,203,'S','Värmland'),(705,203,'AC','Västerbotten'),(706,203,'Y','Västernorrland'),(707,203,'U','Västmanland'),(708,203,'O','Västra Götaland'),(709,215,'AA','Adana'),(710,215,'AD','Adiyaman'),(711,215,'AF','Afyonkarahisar'),(712,215,'AG','Agri'),(713,215,'AK','Aksaray'),(714,215,'AM','Amasya'),(715,215,'AN','Ankara'),(716,215,'AL','Antalya'),(717,215,'AR','Ardahan'),(718,215,'AV','Artvin'),(719,215,'AY','Aydin'),(720,215,'BK','Balikesir'),(721,215,'BR','Bartin'),(722,215,'BM','Batman'),(723,215,'BB','Bayburt'),(724,215,'BC','Bilecik'),(725,215,'BG','Bingöl'),(726,215,'BT','Bitlis'),(727,215,'BL','Bolu'),(728,215,'BD','Burdur'),(729,215,'BU','Bursa'),(730,215,'CK','Çanakkale'),(731,215,'CI','Çankiri'),(732,215,'CM','Çorum'),(733,215,'DN','Denizli'),(734,215,'DY','Diyarbakir'),(735,215,'DU','Düzce'),(736,215,'ED','Edirne'),(737,215,'EG','Elazig'),(738,215,'EN','Erzincan'),(739,215,'EM','Erzurum'),(740,215,'ES','Eskisehir'),(741,215,'GA','Gaziantep'),(742,215,'GI','Giresun'),(743,215,'GU','Gümüshane'),(744,215,'HK','Hakkari'),(745,215,'HT','Hatay'),(746,215,'IG','Igdir'),(747,215,'IP','Isparta'),(748,215,'IB','Istanbul'),(749,215,'IZ','Izmir'),(750,215,'KM','Kahramanmaras'),(751,215,'KB','Karabük'),(752,215,'KR','Karaman'),(753,215,'KA','Kars'),(754,215,'KS','Kastamonu'),(755,215,'KY','Kayseri'),(756,215,'KI','Kilis'),(757,215,'KK','Kirikkale'),(758,215,'KL','Kirklareli'),(759,215,'KH','Kirsehir'),(760,215,'KC','Kocaeli'),(761,215,'KO','Konya'),(762,215,'KU','Kütahya'),(763,215,'ML','Malatya'),(764,215,'MN','Manisa'),(765,215,'MR','Mardin'),(766,215,'IC','Mersin'),(767,215,'MG','Mugla'),(768,215,'MS','Mus'),(769,215,'NV','Nevsehir'),(770,215,'NG','Nigde'),(771,215,'OR','Ordu'),(772,215,'OS','Osmaniye'),(773,215,'RI','Rize'),(774,215,'SK','Sakarya'),(775,215,'SS','Samsun'),(776,215,'SU','Sanliurfa'),(777,215,'SI','Siirt'),(778,215,'SP','Sinop'),(779,215,'SR','Sirnak'),(780,215,'SV','Sivas'),(781,215,'TG','Tekirdag'),(782,215,'TT','Tokat'),(783,215,'TB','Trabzon'),(784,215,'TC','Tunceli'),(785,215,'US','Usak'),(786,215,'VA','Van'),(787,215,'YL','Yalova'),(788,215,'YZ','Yozgat'),(789,215,'ZO','Zonguldak'),(790,229,'AM','Amazonas'),(791,229,'AN','Anzoátegui'),(792,229,'AR','Aragua'),(793,229,'AP','Apure'),(794,229,'BA','Barinas'),(795,229,'BO','Bolívar'),(796,229,'CA','Carabobo'),(797,229,'CO','Cojedes'),(798,229,'DA','Delta Amacuro'),(799,229,'DC','Distrito Capital'),(800,229,'FA','Falcón'),(801,229,'GA','Guárico'),(802,229,'GU','Guayana'),(803,229,'LA','Lara'),(804,229,'ME','Mérida'),(805,229,'MI','Miranda'),(806,229,'MO','Monagas'),(807,229,'NE','Nueva Esparta'),(808,229,'PO','Portuguesa'),(809,229,'SU','Sucre'),(810,229,'TA','Táchira'),(811,229,'TU','Trujillo'),(812,229,'VA','Vargas'),(813,229,'YA','Yaracuy'),(814,229,'ZU','Zulia'),(815,222,'BAS','Bath and North East Somerset'),(816,222,'BDF','Bedfordshire'),(817,222,'WBK','Berkshire'),(818,222,'BBD','Blackburn with Darwen'),(819,222,'BPL','Blackpool'),(820,222,'BMH','Bournemouth'),(821,222,'BNH','Brighton and Hove'),(822,222,'BST','Bristol'),(823,222,'BKM','Buckinghamshire'),(824,222,'CAM','Cambridgeshire'),(825,222,'CHS','Cheshire'),(826,222,'CON','Cornwall'),(827,222,'DUR','County Durham'),(828,222,'CMA','Cumbria'),(829,222,'DAL','Darlington'),(830,222,'DER','Derby'),(831,222,'DBY','Derbyshire'),(832,222,'DEV','Devon'),(833,222,'DOR','Dorset'),(834,222,'ERY','East Riding of Yorkshire'),(835,222,'ESX','East Sussex'),(836,222,'ESS','Essex'),(837,222,'GLS','Gloucestershire'),(838,222,'LND','Greater London'),(839,222,'MAN','Greater Manchester'),(840,222,'HAL','Halton'),(841,222,'HAM','Hampshire'),(842,222,'HPL','Hartlepool'),(843,222,'HEF','Herefordshire'),(844,222,'HRT','Hertfordshire'),(845,222,'KHL','Hull'),(846,222,'IOW','Isle of Wight'),(847,222,'KEN','Kent'),(848,222,'LAN','Lancashire'),(849,222,'LCE','Leicester'),(850,222,'LEC','Leicestershire'),(851,222,'LIN','Lincolnshire'),(852,222,'LUT','Luton'),(853,222,'MDW','Medway'),(854,222,'MER','Merseyside'),(855,222,'MDB','Middlesbrough'),(856,222,'MIK','Milton Keynes'),(857,222,'NFK','Norfolk'),(858,222,'NTH','Northamptonshire'),(859,222,'NEL','North East Lincolnshire'),(860,222,'NLN','North Lincolnshire'),(861,222,'NSM','North Somerset'),(862,222,'NBL','Northumberland'),(863,222,'NYK','North Yorkshire'),(864,222,'NGM','Nottingham'),(865,222,'NTT','Nottinghamshire'),(866,222,'OXF','Oxfordshire'),(867,222,'PTE','Peterborough'),(868,222,'PLY','Plymouth'),(869,222,'POL','Poole'),(870,222,'POR','Portsmouth'),(871,222,'RCC','Redcar and Cleveland'),(872,222,'RUT','Rutland'),(873,222,'SHR','Shropshire'),(874,222,'SOM','Somerset'),(875,222,'STH','Southampton'),(876,222,'SOS','Southend-on-Sea'),(877,222,'SGC','South Gloucestershire'),(878,222,'SYK','South Yorkshire'),(879,222,'STS','Staffordshire'),(880,222,'STT','Stockton-on-Tees'),(881,222,'STE','Stoke-on-Trent'),(882,222,'SFK','Suffolk'),(883,222,'SRY','Surrey'),(884,222,'SWD','Swindon'),(885,222,'TFW','Telford and Wrekin'),(886,222,'THR','Thurrock'),(887,222,'TOB','Torbay'),(888,222,'TYW','Tyne and Wear'),(889,222,'WRT','Warrington'),(890,222,'WAR','Warwickshire'),(891,222,'WMI','West Midlands'),(892,222,'WSX','West Sussex'),(893,222,'WYK','West Yorkshire'),(894,222,'WIL','Wiltshire'),(895,222,'WOR','Worcestershire'),(896,222,'YOR','York'),(897,44,'BJ','Beijing Municipality'),(898,44,'TJ','Tianjin Municipality'),(899,44,'HE','Hebei Province'),(900,44,'SX','Shanxi Province'),(901,44,'NM','Inner Mongolia Autonomous Region'),(902,44,'LN','Liaoning Province'),(903,44,'JL','Jilin Province'),(904,44,'HL','Heilongjiang Province'),(905,44,'SH','Shanghai Municipality'),(906,44,'JS','Jiangsu Province'),(907,44,'ZJ','Zhejiang Province'),(908,44,'AH','Anhui Province'),(909,44,'FJ','Fujian Province'),(910,44,'JX','Jiangxi Province'),(911,44,'SD','Shandong Province'),(912,44,'HA','Henan Province'),(913,44,'HB','Hubei Province'),(914,44,'HN','Hunan Province'),(915,44,'GD','Guangdong Province'),(916,44,'GX','Guangxi Zhuang Autonomous Region'),(917,44,'HI','Hainan Province'),(918,44,'CQ','Chongqing Municipality'),(919,44,'SC','Sichuan Province'),(920,44,'GZ','Guizhou Province'),(921,44,'YN','Yunnan Province'),(922,44,'XZ','Tibet Autonomous Region'),(923,44,'SN','Shaanxi Province'),(924,44,'GS','Gansu Province'),(925,44,'QH','Qinghai Province'),(926,44,'NX','Ningxia Hui Autonomous Region'),(927,44,'XJ','Xinjiang Uyghur Autonomous Region'),(928,44,'HK','Hong Kong Special Administrative Region'),(929,44,'MC','Macau Special Administrative Region'),(930,44,'TW','Taiwan Province'),(931,10,'CF','Ciudad de Buenos Aires (Distrito Federal)'),(932,10,'BA','Buenos Aires'),(933,10,'CT','Catamarca'),(934,10,'CC','Chaco'),(935,10,'CH','Chubut'),(936,10,'CD','Córdoba'),(937,10,'CR','Corrientes'),(938,10,'ER','Entre Ríos'),(939,10,'FO','Formosa'),(940,10,'JY','Jujuy'),(941,10,'LP','La Pampa'),(942,10,'LR','La Rioja'),(943,10,'MZ','Mendoza'),(944,10,'MN','Misiones'),(945,10,'NQ','Neuquén'),(946,10,'RN','Río Negro'),(947,10,'SA','Salta'),(948,10,'SJ','San Juan'),(949,10,'SL','San Luis'),(950,10,'SC','Santa Cruz'),(951,10,'SF','Santa Fe'),(952,10,'SE','Santiago del Estero'),(953,10,'TF','Tierra del Fuego'),(954,10,'TM','Tucumán'),(955,100,'AC','Aceh'),(956,100,'BA','Bali'),(957,100,'BB','Babel'),(958,100,'BT','Banten'),(959,100,'BE','Bengkulu'),(960,100,'JT','Jateng'),(961,100,'KT','Kalteng'),(962,100,'ST','Sulteng'),(963,100,'JI','Jatim'),(964,100,'KI','Kaltim'),(965,100,'NT','NTT'),(966,100,'GO','Gorontalo'),(967,100,'JK','DKI'),(968,100,'JA','Jambi'),(969,100,'LA','Lampung'),(970,100,'MA','Maluku'),(971,100,'KU','Kaltara'),(972,100,'MU','Malut'),(973,100,'SA','Sulut'),(974,100,'SU','Sumut'),(975,100,'PA','Papua'),(976,100,'RI','Riau'),(977,100,'KR','Kepri'),(978,100,'SG','Sultra'),(979,100,'KS','Kalsel'),(980,100,'SN','Sulsel'),(981,100,'SS','Sumsel'),(982,100,'JB','Jabar'),(983,100,'KB','Kalbar'),(984,100,'NB','NTB'),(985,100,'PB','Papuabarat'),(986,100,'SR','Sulbar'),(987,100,'SB','Sumbar'),(988,100,'YO','DIY'),(989,209,'10','Bangkok'),(990,209,'37','Amnat Charoen'),(991,209,'15','Ang Thong'),(992,209,'38','Bueng Kan'),(993,209,'31','Buriram'),(994,209,'24','Chachoengsao'),(995,209,'18','Chai Nat'),(996,209,'36','Chaiyaphum'),(997,209,'22','Chanthaburi'),(998,209,'50','Chiang Mai'),(999,209,'57','Chiang Rai'),(1000,209,'20','Chonburi'),(1001,209,'86','Chumphon'),(1002,209,'46','Kalasin'),(1003,209,'62','Kamphaeng Phet'),(1004,209,'71','Kanchanaburi'),(1005,209,'40','Khon Kaen'),(1006,209,'81','Krabi'),(1007,209,'52','Lampang'),(1008,209,'51','Lamphun'),(1009,209,'42','Loei Province'),(1010,209,'16','Lopburi Province'),(1011,209,'58','Mae Hong Son'),(1012,209,'44','Maha Sarakham'),(1013,209,'49','Mukdahan'),(1014,209,'26','Nakhon Nayok'),(1015,209,'73','Nakhon Pathom'),(1016,209,'48','Nakhon Phanom'),(1017,209,'30','Nakhon Ratchasima'),(1018,209,'60','Nakhon Sawan'),(1019,209,'80','Nakhon Si Thammarat'),(1020,209,'55','Nan'),(1021,209,'96','Narathiwat'),(1022,209,'39','Nong Bua Lam Phu'),(1023,209,'43','Nong Khai'),(1024,209,'12','Nonthaburi'),(1025,209,'13','Pathum Thani'),(1026,209,'94','Pattani'),(1027,209,'82','Phang Nga'),(1028,209,'93','Phatthalung'),(1029,209,'56','Phayao'),(1030,209,'67','Phetchabun'),(1031,209,'76','Phetchaburi'),(1032,209,'66','Phichit'),(1033,209,'65','Phitsanulok'),(1034,209,'14','Phra Nakhon Si Ayutthaya'),(1035,209,'54','Phrae'),(1036,209,'83','Phuket'),(1037,209,'25','Prachinburi'),(1038,209,'77','Prachuap Khiri Khan'),(1039,209,'85','Ranong'),(1040,209,'70','Ratchaburi'),(1041,209,'21','Rayong'),(1042,209,'45','Roi Et'),(1043,209,'27','Sa Kaeo'),(1044,209,'47','Sakon Nakhon'),(1045,209,'11','Samut Prakan'),(1046,209,'74','Samut Sakhon'),(1047,209,'75','Samut Songkhram'),(1048,209,'19','Saraburi'),(1049,209,'91','Satun'),(1050,209,'17','Sing Buri'),(1051,209,'33','Sisaket'),(1052,209,'90','Songkhla'),(1053,209,'64','Sukhothai'),(1054,209,'72','Suphan Buri'),(1055,209,'84','Surat Thani'),(1056,209,'32','Surin'),(1057,209,'63','Tak'),(1058,209,'92','Trang'),(1059,209,'23','Trat'),(1060,209,'34','Ubon Ratchathani'),(1061,209,'41','Udon Thani'),(1062,209,'61','Uthai Thani'),(1063,209,'53','Uttaradit'),(1064,209,'95','Yala'),(1065,209,'35','Yasothon');
/*!40000 ALTER TABLE `zones` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `zones_to_geo_zones`
--

DROP TABLE IF EXISTS `zones_to_geo_zones`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `zones_to_geo_zones` (
  `association_id` int(11) NOT NULL AUTO_INCREMENT,
  `zone_country_id` int(11) NOT NULL,
  `zone_id` int(11) DEFAULT NULL,
  `geo_zone_id` int(11) DEFAULT NULL,
  `last_modified` datetime DEFAULT NULL,
  `date_added` datetime NOT NULL,
  PRIMARY KEY (`association_id`),
  KEY `idx_geo_zone_id` (`geo_zone_id`)
) ENGINE=MyISAM AUTO_INCREMENT=242 DEFAULT CHARSET=latin1 COLLATE=latin1_german1_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `zones_to_geo_zones`
--

LOCK TABLES `zones_to_geo_zones` WRITE;
/*!40000 ALTER TABLE `zones_to_geo_zones` DISABLE KEYS */;
INSERT INTO `zones_to_geo_zones` VALUES (14,14,0,5,NULL,'2019-02-05 19:45:22'),(21,21,0,5,NULL,'2019-02-05 19:45:22'),(33,33,0,5,NULL,'2019-02-05 19:45:22'),(55,55,0,5,NULL,'2019-02-05 19:45:22'),(56,56,0,5,NULL,'2019-02-05 19:45:22'),(57,57,0,5,NULL,'2019-02-05 19:45:22'),(67,67,0,5,NULL,'2019-02-05 19:45:22'),(72,72,0,5,NULL,'2019-02-05 19:45:22'),(73,73,0,5,NULL,'2019-02-05 19:45:22'),(81,81,0,5,NULL,'2019-02-05 19:45:22'),(84,84,0,5,NULL,'2019-02-05 19:45:22'),(97,97,0,5,NULL,'2019-02-05 19:45:22'),(103,103,0,5,NULL,'2019-02-05 19:45:22'),(105,105,0,5,NULL,'2019-02-05 19:45:22'),(117,117,0,5,NULL,'2019-02-05 19:45:22'),(123,123,0,5,NULL,'2019-02-05 19:45:22'),(124,124,0,5,NULL,'2019-02-05 19:45:22'),(132,132,0,5,NULL,'2019-02-05 19:45:22'),(150,150,0,5,NULL,'2019-02-05 19:45:22'),(170,170,0,5,NULL,'2019-02-05 19:45:22'),(171,171,0,5,NULL,'2019-02-05 19:45:22'),(175,175,0,5,NULL,'2019-02-05 19:45:22'),(189,189,0,5,NULL,'2019-02-05 19:45:22'),(190,190,0,5,NULL,'2019-02-05 19:45:22'),(195,195,0,5,NULL,'2019-02-05 19:45:23'),(203,203,0,5,NULL,'2019-02-05 19:45:23'),(222,222,0,5,NULL,'2019-02-05 19:45:23'),(1,1,0,6,NULL,'2019-02-05 19:45:23'),(2,2,0,6,NULL,'2019-02-05 19:45:23'),(3,3,0,6,NULL,'2019-02-05 19:45:23'),(4,4,0,6,NULL,'2019-02-05 19:45:23'),(5,5,0,6,NULL,'2019-02-05 19:45:23'),(6,6,0,6,NULL,'2019-02-05 19:45:23'),(7,7,0,6,NULL,'2019-02-05 19:45:23'),(8,8,0,6,NULL,'2019-02-05 19:45:23'),(9,9,0,6,NULL,'2019-02-05 19:45:23'),(10,10,0,6,NULL,'2019-02-05 19:45:23'),(11,11,0,6,NULL,'2019-02-05 19:45:23'),(12,12,0,6,NULL,'2019-02-05 19:45:23'),(13,13,0,6,NULL,'2019-02-05 19:45:23'),(15,15,0,6,NULL,'2019-02-05 19:45:23'),(16,16,0,6,NULL,'2019-02-05 19:45:23'),(17,17,0,6,NULL,'2019-02-05 19:45:23'),(18,18,0,6,NULL,'2019-02-05 19:45:23'),(19,19,0,6,NULL,'2019-02-05 19:45:23'),(20,20,0,6,NULL,'2019-02-05 19:45:23'),(22,22,0,6,NULL,'2019-02-05 19:45:23'),(23,23,0,6,NULL,'2019-02-05 19:45:23'),(24,24,0,6,NULL,'2019-02-05 19:45:23'),(25,25,0,6,NULL,'2019-02-05 19:45:23'),(26,26,0,6,NULL,'2019-02-05 19:45:23'),(27,27,0,6,NULL,'2019-02-05 19:45:23'),(28,28,0,6,NULL,'2019-02-05 19:45:23'),(29,29,0,6,NULL,'2019-02-05 19:45:23'),(30,30,0,6,NULL,'2019-02-05 19:45:23'),(31,31,0,6,NULL,'2019-02-05 19:45:23'),(32,32,0,6,NULL,'2019-02-05 19:45:23'),(34,34,0,6,NULL,'2019-02-05 19:45:23'),(35,35,0,6,NULL,'2019-02-05 19:45:23'),(36,36,0,6,NULL,'2019-02-05 19:45:23'),(37,37,0,6,NULL,'2019-02-05 19:45:23'),(38,38,0,6,NULL,'2019-02-05 19:45:23'),(39,39,0,6,NULL,'2019-02-05 19:45:23'),(40,40,0,6,NULL,'2019-02-05 19:45:23'),(41,41,0,6,NULL,'2019-02-05 19:45:23'),(42,42,0,6,NULL,'2019-02-05 19:45:23'),(43,43,0,6,NULL,'2019-02-05 19:45:23'),(44,44,0,6,NULL,'2019-02-05 19:45:23'),(45,45,0,6,NULL,'2019-02-05 19:45:24'),(46,46,0,6,NULL,'2019-02-05 19:45:24'),(47,47,0,6,NULL,'2019-02-05 19:45:24'),(48,48,0,6,NULL,'2019-02-05 19:45:24'),(49,49,0,6,NULL,'2019-02-05 19:45:24'),(50,50,0,6,NULL,'2019-02-05 19:45:24'),(51,51,0,6,NULL,'2019-02-05 19:45:24'),(52,52,0,6,NULL,'2019-02-05 19:45:24'),(53,53,0,5,NULL,'2019-02-05 19:45:24'),(54,54,0,6,NULL,'2019-02-05 19:45:24'),(58,58,0,6,NULL,'2019-02-05 19:45:24'),(59,59,0,6,NULL,'2019-02-05 19:45:24'),(60,60,0,6,NULL,'2019-02-05 19:45:24'),(61,61,0,6,NULL,'2019-02-05 19:45:24'),(62,62,0,6,NULL,'2019-02-05 19:45:24'),(63,63,0,6,NULL,'2019-02-05 19:45:24'),(64,64,0,6,NULL,'2019-02-05 19:45:24'),(65,65,0,6,NULL,'2019-02-05 19:45:24'),(66,66,0,6,NULL,'2019-02-05 19:45:24'),(68,68,0,6,NULL,'2019-02-05 19:45:24'),(69,69,0,6,NULL,'2019-02-05 19:45:24'),(70,70,0,6,NULL,'2019-02-05 19:45:24'),(71,71,0,6,NULL,'2019-02-05 19:45:24'),(74,74,0,6,NULL,'2019-02-05 19:45:24'),(75,75,0,6,NULL,'2019-02-05 19:45:24'),(76,76,0,6,NULL,'2019-02-05 19:45:24'),(77,77,0,6,NULL,'2019-02-05 19:45:24'),(78,78,0,6,NULL,'2019-02-05 19:45:24'),(79,79,0,6,NULL,'2019-02-05 19:45:24'),(80,80,0,6,NULL,'2019-02-05 19:45:24'),(82,82,0,6,NULL,'2019-02-05 19:45:24'),(83,83,0,6,NULL,'2019-02-05 19:45:24'),(85,85,0,6,NULL,'2019-02-05 19:45:24'),(86,86,0,6,NULL,'2019-02-05 19:45:24'),(87,87,0,6,NULL,'2019-02-05 19:45:24'),(88,88,0,6,NULL,'2019-02-05 19:45:24'),(89,89,0,6,NULL,'2019-02-05 19:45:24'),(90,90,0,6,NULL,'2019-02-05 19:45:24'),(91,91,0,6,NULL,'2019-02-05 19:45:24'),(92,92,0,6,NULL,'2019-02-05 19:45:24'),(93,93,0,6,NULL,'2019-02-05 19:45:24'),(94,94,0,6,NULL,'2019-02-05 19:45:24'),(95,95,0,6,NULL,'2019-02-05 19:45:24'),(96,96,0,6,NULL,'2019-02-05 19:45:25'),(98,98,0,6,NULL,'2019-02-05 19:45:25'),(99,99,0,6,NULL,'2019-02-05 19:45:25'),(100,100,0,6,NULL,'2019-02-05 19:45:25'),(101,101,0,6,NULL,'2019-02-05 19:45:25'),(102,102,0,6,NULL,'2019-02-05 19:45:25'),(104,104,0,6,NULL,'2019-02-05 19:45:25'),(106,106,0,6,NULL,'2019-02-05 19:45:25'),(107,107,0,6,NULL,'2019-02-05 19:45:25'),(108,108,0,6,NULL,'2019-02-05 19:45:25'),(109,109,0,6,NULL,'2019-02-05 19:45:25'),(110,110,0,6,NULL,'2019-02-05 19:45:25'),(111,111,0,6,NULL,'2019-02-05 19:45:25'),(112,112,0,6,NULL,'2019-02-05 19:45:25'),(113,113,0,6,NULL,'2019-02-05 19:45:25'),(114,114,0,6,NULL,'2019-02-05 19:45:25'),(115,115,0,6,NULL,'2019-02-05 19:45:25'),(116,116,0,6,NULL,'2019-02-05 19:45:25'),(118,118,0,6,NULL,'2019-02-05 19:45:25'),(119,119,0,6,NULL,'2019-02-05 19:45:25'),(120,120,0,6,NULL,'2019-02-05 19:45:25'),(121,121,0,6,NULL,'2019-02-05 19:45:25'),(122,122,0,6,NULL,'2019-02-05 19:45:25'),(125,125,0,6,NULL,'2019-02-05 19:45:25'),(126,126,0,6,NULL,'2019-02-05 19:45:25'),(127,127,0,6,NULL,'2019-02-05 19:45:25'),(128,128,0,6,NULL,'2019-02-05 19:45:25'),(129,129,0,6,NULL,'2019-02-05 19:45:25'),(130,130,0,6,NULL,'2019-02-05 19:45:25'),(131,131,0,6,NULL,'2019-02-05 19:45:25'),(133,133,0,6,NULL,'2019-02-05 19:45:25'),(134,134,0,6,NULL,'2019-02-05 19:45:25'),(135,135,0,6,NULL,'2019-02-05 19:45:25'),(136,136,0,6,NULL,'2019-02-05 19:45:25'),(137,137,0,6,NULL,'2019-02-05 19:45:25'),(138,138,0,6,NULL,'2019-02-05 19:45:25'),(139,139,0,6,NULL,'2019-02-05 19:45:25'),(140,140,0,6,NULL,'2019-02-05 19:45:25'),(141,141,0,6,NULL,'2019-02-05 19:45:25'),(142,142,0,6,NULL,'2019-02-05 19:45:25'),(143,143,0,6,NULL,'2019-02-05 19:45:25'),(144,144,0,6,NULL,'2019-02-05 19:45:25'),(145,145,0,6,NULL,'2019-02-05 19:45:25'),(146,146,0,6,NULL,'2019-02-05 19:45:25'),(147,147,0,6,NULL,'2019-02-05 19:45:26'),(148,148,0,6,NULL,'2019-02-05 19:45:26'),(149,149,0,6,NULL,'2019-02-05 19:45:26'),(151,151,0,6,NULL,'2019-02-05 19:45:26'),(152,152,0,6,NULL,'2019-02-05 19:45:26'),(153,153,0,6,NULL,'2019-02-05 19:45:26'),(154,154,0,6,NULL,'2019-02-05 19:45:26'),(155,155,0,6,NULL,'2019-02-05 19:45:26'),(156,156,0,6,NULL,'2019-02-05 19:45:26'),(157,157,0,6,NULL,'2019-02-05 19:45:26'),(158,158,0,6,NULL,'2019-02-05 19:45:26'),(159,159,0,6,NULL,'2019-02-05 19:45:26'),(160,160,0,6,NULL,'2019-02-05 19:45:26'),(161,161,0,6,NULL,'2019-02-05 19:45:26'),(162,162,0,6,NULL,'2019-02-05 19:45:26'),(163,163,0,6,NULL,'2019-02-05 19:45:26'),(164,164,0,6,NULL,'2019-02-05 19:45:26'),(165,165,0,6,NULL,'2019-02-05 19:45:26'),(166,166,0,6,NULL,'2019-02-05 19:45:26'),(167,167,0,6,NULL,'2019-02-05 19:45:26'),(168,168,0,6,NULL,'2019-02-05 19:45:26'),(169,169,0,6,NULL,'2019-02-05 19:45:26'),(172,172,0,6,NULL,'2019-02-05 19:45:26'),(173,173,0,6,NULL,'2019-02-05 19:45:26'),(174,174,0,6,NULL,'2019-02-05 19:45:26'),(176,176,0,6,NULL,'2019-02-05 19:45:26'),(177,177,0,6,NULL,'2019-02-05 19:45:26'),(178,178,0,6,NULL,'2019-02-05 19:45:26'),(179,179,0,6,NULL,'2019-02-05 19:45:26'),(180,180,0,6,NULL,'2019-02-05 19:45:26'),(181,181,0,6,NULL,'2019-02-05 19:45:26'),(182,182,0,6,NULL,'2019-02-05 19:45:26'),(183,183,0,6,NULL,'2019-02-05 19:45:26'),(184,184,0,6,NULL,'2019-02-05 19:45:26'),(185,185,0,6,NULL,'2019-02-05 19:45:26'),(186,186,0,6,NULL,'2019-02-05 19:45:26'),(187,187,0,6,NULL,'2019-02-05 19:45:26'),(188,188,0,6,NULL,'2019-02-05 19:45:26'),(191,191,0,6,NULL,'2019-02-05 19:45:26'),(192,192,0,6,NULL,'2019-02-05 19:45:26'),(193,193,0,6,NULL,'2019-02-05 19:45:26'),(194,194,0,6,NULL,'2019-02-05 19:45:26'),(196,196,0,6,NULL,'2019-02-05 19:45:26'),(197,197,0,6,NULL,'2019-02-05 19:45:26'),(198,198,0,6,NULL,'2019-02-05 19:45:27'),(199,199,0,6,NULL,'2019-02-05 19:45:27'),(200,200,0,6,NULL,'2019-02-05 19:45:27'),(201,201,0,6,NULL,'2019-02-05 19:45:27'),(202,202,0,6,NULL,'2019-02-05 19:45:27'),(204,204,0,6,NULL,'2019-02-05 19:45:27'),(205,205,0,6,NULL,'2019-02-05 19:45:27'),(206,206,0,6,NULL,'2019-02-05 19:45:27'),(207,207,0,6,NULL,'2019-02-05 19:45:27'),(208,208,0,6,NULL,'2019-02-05 19:45:27'),(209,209,0,6,NULL,'2019-02-05 19:45:27'),(210,210,0,6,NULL,'2019-02-05 19:45:27'),(211,211,0,6,NULL,'2019-02-05 19:45:27'),(212,212,0,6,NULL,'2019-02-05 19:45:27'),(213,213,0,6,NULL,'2019-02-05 19:45:27'),(214,214,0,6,NULL,'2019-02-05 19:45:27'),(215,215,0,6,NULL,'2019-02-05 19:45:27'),(216,216,0,6,NULL,'2019-02-05 19:45:27'),(217,217,0,6,NULL,'2019-02-05 19:45:27'),(218,218,0,6,NULL,'2019-02-05 19:45:27'),(219,219,0,6,NULL,'2019-02-05 19:45:27'),(220,220,0,6,NULL,'2019-02-05 19:45:27'),(221,221,0,6,NULL,'2019-02-05 19:45:27'),(223,223,0,6,NULL,'2019-02-05 19:45:27'),(224,224,0,6,NULL,'2019-02-05 19:45:27'),(225,225,0,6,NULL,'2019-02-05 19:45:27'),(226,226,0,6,NULL,'2019-02-05 19:45:27'),(227,227,0,6,NULL,'2019-02-05 19:45:27'),(228,228,0,6,NULL,'2019-02-05 19:45:27'),(229,229,0,6,NULL,'2019-02-05 19:45:27'),(230,230,0,6,NULL,'2019-02-05 19:45:27'),(231,231,0,6,NULL,'2019-02-05 19:45:27'),(232,232,0,6,NULL,'2019-02-05 19:45:27'),(233,233,0,6,NULL,'2019-02-05 19:45:27'),(234,234,0,6,NULL,'2019-02-05 19:45:27'),(235,235,0,6,NULL,'2019-02-05 19:45:27'),(236,236,0,6,NULL,'2019-02-05 19:45:27'),(237,237,0,6,NULL,'2019-02-05 19:45:27'),(238,238,0,6,NULL,'2019-02-05 19:45:27'),(239,239,0,6,NULL,'2019-02-05 19:45:27'),(240,240,0,6,NULL,'2019-02-05 19:45:27'),(241,241,0,6,NULL,'2019-02-05 19:45:27');
/*!40000 ALTER TABLE `zones_to_geo_zones` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2019-02-13 15:43:06

